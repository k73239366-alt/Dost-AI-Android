package com.dost.ai.device

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Legitimate Android timer tool using AlarmClock.ACTION_SET_TIMER intent.
 *
 * Requirements:
 * - "10 minute ka timer lagao."
 * - "Set a timer for 5 minutes."
 * - "Timer cancel karo."
 * - Show actual scheduled duration, never fake execution.
 */
class TimerTool : BaseTool {
    override val name: String = "SET_TIMER"
    override val description: String = "Sets an Android countdown timer using platform clock APIs."

    override fun validateParams(params: Map<String, Any?>): String? {
        val seconds = (params["seconds"] as? Number)?.toInt() ?: 0
        if (seconds <= 0) {
            return "Timer duration must be greater than 0 seconds."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val seconds = (params["seconds"] as? Number)?.toInt() ?: 300
        val label = (params["message"] as? String) ?: "DOST Timer"
        val skipUi = (params["skipUi"] as? Boolean) ?: false

        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, skipUi)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                val minutes = seconds / 60
                val remainingSec = seconds % 60
                val durationText = if (minutes > 0 && remainingSec > 0) {
                    "$minutes minute $remainingSec second"
                } else if (minutes > 0) {
                    "$minutes minute"
                } else {
                    "$seconds second"
                }

                ToolResult.success(
                    name,
                    "$durationText ka timer set kar diya gaya hai.",
                    mapOf("seconds" to seconds, "label" to label)
                )
            } else {
                ToolResult.failure(name, "Device clock application is not available for setting timers.")
            }
        } catch (e: Exception) {
            ToolResult.failure(name, "Timer set karne me samasya aayi: ${e.message}", e.message)
        }
    }
}
