package com.dost.ai.speech

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Wake Word and Follow-up Mode Manager for DOST.
 *
 * Supported Wake Phrases:
 * - "Dost"
 * - "Hey Dost"
 * - "Hello Dost"
 *
 * Follow-up Mode:
 * Keeps listening for 3-8 seconds after speech completes, allowing the user
 * to speak naturally without repeating "Dost".
 *
 * Immediate Cancellation:
 * "Dost ruko", "Stop", "Cancel", "Chup", "Quiet".
 */
class WakeWordManager(
    private val scope: CoroutineScope
) {
    val wakePhrases = listOf("dost", "hey dost", "hello dost", "arey dost", "oye dost")
    val interruptPhrases = listOf("ruko", "stop", "cancel", "chup", "quiet", "bas", "band karo")

    private val _isFollowUpActive = MutableStateFlow(false)
    val isFollowUpActive: StateFlow<Boolean> = _isFollowUpActive.asStateFlow()

    private var followUpJob: Job? = null
    var followUpWindowMs: Long = 5000L // Configurable 3-8s

    fun containsWakeWord(input: String): Boolean {
        val lower = input.trim().lowercase()
        return wakePhrases.any { lower.startsWith(it) || lower.contains(it) }
    }

    fun isInterruptCommand(input: String): Boolean {
        val lower = input.trim().lowercase()
        return interruptPhrases.any { lower.contains(it) }
    }

    fun startFollowUpWindow(onTimeout: () -> Unit) {
        followUpJob?.cancel()
        _isFollowUpActive.value = true
        followUpJob = scope.launch {
            delay(followUpWindowMs)
            _isFollowUpActive.value = false
            onTimeout()
        }
    }

    fun cancelFollowUp() {
        followUpJob?.cancel()
        _isFollowUpActive.value = false
    }
}
