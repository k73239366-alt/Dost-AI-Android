package com.dost.ai.voice

import java.util.Locale

enum class DetectedLanguage {
    HINDI,
    HINGLISH,
    ENGLISH
}

/**
 * LanguageDetector: Determines whether an input or output text is
 * pure Hindi (Devanagari or Romanized), Hinglish (mixed conversational Hindi + English terms),
 * or English.
 */
object LanguageDetector {

    // Devanagari Unicode Block: \u0900 to \u097F
    private val DEVANAGARI_REGEX = Regex("[\\u0900-\\u097F]")

    // Frequent Hindi Romanized tokens used in conversations and explanations
    private val HINDI_ROMAN_STOPWORDS = hashSetOf(
        "namaste", "dost", "aap", "aapka", "aapki", "aapke", "aapko", "aapne",
        "tum", "tumhara", "tumhari", "tumhare", "tumhe", "tujhe",
        "main", "mera", "meri", "mere", "mujhe", "mujhse", "mujhpe",
        "hum", "hamara", "hamari", "hamare", "humein", "humse",
        "hai", "hain", "tha", "thi", "the", "hoga", "hogi", "honge", "hote", "hoti", "hota", "hona",
        "kya", "kyun", "kyu", "kaise", "kaisa", "kaisi", "kaise", "kahan", "kaha", "kab", "kaun",
        "kitna", "kitne", "kitni",
        "karo", "karna", "karein", "kijiye", "kar", "karte", "karti", "karta", "kiya", "kiye", "karenge",
        "nahi", "nahin", "na", "mat", "haan", "accha", "achha", "achhi", "theek", "shukriya", "dhanyawad",
        "madad", "sahayata", "sawal", "prashna", "jawab", "uttar", "baat", "cheet",
        "batao", "bataiye", "batata", "batate", "batati", "suno", "suniye",
        "samjho", "samajh", "samjhenge", "samajhte", "samajhna", "samjhaye", "samjhao",
        "dekho", "dekhiye", "dekhte", "dekh",
        "chalo", "chalte", "chalate", "chaliye", "aao",
        "pehle", "pehla", "pehli", "baad", "mein", "me", "ko", "se", "ka", "ki", "ke", "liye",
        "bhi", "toh", "to", "aur", "ya", "athwa", "par", "lekin", "magar", "phir", "fir",
        "ab", "abhi", "tab", "tabhi", "jab", "jabki",
        "yeh", "ye", "woh", "wo", "is", "us", "in", "un", "inka", "unka", "jiska", "jisme", "isme", "usme",
        "kuch", "sab", "sabka", "sabko", "sabse",
        "apna", "apni", "apne", "zaroor", "aasan", "mushkil", "kathin", "bahut", "thoda", "thodi", "zyada",
        "raha", "rahi", "rahe", "sakta", "sakti", "sakte", "sakoge", "chahiye", "paas", "sirf", "matlab",
        "taiyar", "hoon", "dobara", "punah", "ekdum", "bilkul", "sahi", "galat"
    )

    /**
     * Detects the language of the given text.
     * @param text The text to evaluate.
     * @param userPreference The user's explicit preference ("Auto", "Hindi", "English").
     */
    fun detect(text: String, userPreference: String = "Auto"): DetectedLanguage {
        // If user set an explicit language override (not Auto), prioritize that choice
        when (userPreference.lowercase()) {
            "hindi" -> return DetectedLanguage.HINDI
            "english" -> return DetectedLanguage.ENGLISH
        }

        val trimmed = text.trim()
        if (trimmed.isEmpty()) return DetectedLanguage.HINDI

        // 1. If text contains Devanagari script, it is unambiguously Hindi
        if (DEVANAGARI_REGEX.containsMatchIn(trimmed)) {
            return DetectedLanguage.HINDI
        }

        // 2. Tokenize words for Romanized Hindi / Hinglish analysis
        val tokens = trimmed.lowercase(Locale.ROOT)
            .replace(Regex("[^a-zA-Z0-9\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it.length > 1 }

        if (tokens.isEmpty()) return DetectedLanguage.HINDI

        var hindiMatches = 0
        var nonHindiMatches = 0

        for (token in tokens) {
            if (HINDI_ROMAN_STOPWORDS.contains(token)) {
                hindiMatches++
            } else {
                nonHindiMatches++
            }
        }

        val total = tokens.size
        val hindiRatio = hindiMatches.toFloat() / total

        return when {
            // Predominantly Hindi grammar in Roman script
            // e.g. "Namaste dost main tumhari madad ke liye taiyar hoon"
            hindiRatio >= 0.35f -> {
                // If there are also technical English words present, treat as Hinglish
                if (nonHindiMatches >= 2 && hindiMatches >= 2) {
                    DetectedLanguage.HINGLISH
                } else {
                    DetectedLanguage.HINDI
                }
            }
            // Mixed Hindi structure with English technical phrases
            // e.g. "Dost Python ke loops samajhte hain" or "Code step by step debug karte hain"
            hindiMatches >= 1 -> DetectedLanguage.HINGLISH
            // Pure English with no Hindi conversational markers
            else -> DetectedLanguage.ENGLISH
        }
    }
}
