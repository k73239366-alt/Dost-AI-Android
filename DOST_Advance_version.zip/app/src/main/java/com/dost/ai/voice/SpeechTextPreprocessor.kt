package com.dost.ai.voice

import java.util.Locale

/**
 * SpeechTextPreprocessor: Prepares text specifically for natural Text-To-Speech audio synthesis.
 * Does NOT alter the visual chat UI text.
 *
 * Responsibilities:
 * - Clean markdown, code fences, inline code, and URLs
 * - Convert excessive symbols/punctuation into natural pauses
 * - Expand abbreviations (e.g. AI -> A I, UI -> U I, e.g. -> jaise ki)
 * - Format technical terminology so TTS doesn't stumble on raw symbols
 * - Segment long responses into sentence-sized chunks with natural pauses
 */
object SpeechTextPreprocessor {

    private const val TARGET_MAX_CHUNK_LENGTH = 140
    private const val ABSOLUTE_MAX_CHUNK_LENGTH = 180

    /**
     * Cleans raw message text for spoken delivery.
     */
    fun cleanForSpeech(rawText: String, detectedLang: DetectedLanguage = DetectedLanguage.HINDI): String {
        var text = rawText

        // 1. Remove hidden or internal tool action annotations
        text = text.replace(Regex("\\[TOOL_ACTION:[^\\]]*\\]"), "")

        // 2. Replace multi-line code blocks with a brief spoken phrase
        text = text.replace(Regex("```[a-zA-Z]*[\\s\\S]*?```")) {
            if (detectedLang == DetectedLanguage.ENGLISH) {
                " Here is the code. "
            } else {
                " Yahan code diya gaya hai. "
            }
        }

        // 3. Remove inline code backticks while preserving the inner technical terms
        text = text.replace(Regex("`([^`]+)`"), " $1 ")

        // 4. Clean web URLs and links
        text = text.replace(Regex("https?://\\S+"), " link ")

        // 5. Expand common technical and linguistic abbreviations
        text = text.replace(Regex("(?i)\\bAI\\b"), "A I")
            .replace(Regex("(?i)\\bUI\\b"), "U I")
            .replace(Regex("(?i)\\bAPI\\b"), "A P I")
            .replace(Regex("(?i)\\bSDK\\b"), "S D K")
            .replace(Regex("(?i)\\bURL\\b"), "U R L")
            .replace(Regex("(?i)\\bHTTP\\b"), "H T T P")
            .replace(Regex("(?i)\\bHTML\\b"), "H T M L")
            .replace(Regex("(?i)\\bCSS\\b"), "C S S")
            .replace(Regex("(?i)\\bSQL\\b"), "S Q L")

        // 6. Expand Latin/English conversational shorthands
        if (detectedLang == DetectedLanguage.ENGLISH) {
            text = text.replace(Regex("(?i)\\be\\.g\\.\\s*"), "for example, ")
                .replace(Regex("(?i)\\bi\\.e\\.\\s*"), "that is, ")
                .replace(Regex("(?i)\\bvs\\.?\\s*"), "versus ")
                .replace(Regex("(?i)\\betc\\.?\\s*"), "and so on. ")
                .replace(Regex("(?i)\\bapprox\\.?\\s*"), "approximately ")
        } else {
            text = text.replace(Regex("(?i)\\be\\.g\\.\\s*"), "jaise ki, ")
                .replace(Regex("(?i)\\bi\\.e\\.\\s*"), "yani, ")
                .replace(Regex("(?i)\\bvs\\.?\\s*"), "versus ")
                .replace(Regex("(?i)\\betc\\.?\\s*"), "ityadi. ")
                .replace(Regex("(?i)\\bapprox\\.?\\s*"), "lagbhag ")
        }

        // 7. Expand currency and numerical units cleanly
        text = text.replace(Regex("[₹]"), " rupaye ")
            .replace(Regex("(?i)\\bRs\\.?\\s*(\\d+)"), "$1 rupaye")
            .replace(Regex("[$]"), " dollars ")
            .replace(Regex("[%]"), " percent ")

        // 8. Clean Markdown headers and list item markers
        // E.g. "### Python Loops:" -> "Python loops."
        text = text.replace(Regex("^[#]+\\s*", RegexOption.MULTILINE), "")
            .replace(Regex("^[\\*\\-\\•]\\s*", RegexOption.MULTILINE), ", ")
            .replace(Regex("^\\d+\\.\\s*", RegexOption.MULTILINE), ", ")

        // 9. Avoid reading colon after title/heading as a raw symbol: "Loops:" -> "Loops."
        text = text.replace(Regex("([a-zA-Z0-9\u0900-\u097F]+):\\s+"), "$1. ")

        // 10. Strip remaining markdown formatting symbols
        text = text.replace(Regex("[\\*\\_~>#|]"), "")
            .replace(Regex("[\\{\\}\\[\\]\\(\\)<>]"), " ")
            .replace(Regex("[\\\\\\^]"), " ")

        // 11. Normalize excessive punctuation into natural speech pauses
        text = text.replace(Regex("[\\.\\!\\?]{2,}"), ". ")
            .replace(Regex("[\\-—_]{2,}"), ", ")
            .replace(Regex("[,]{2,}"), ", ")
            .replace(Regex("\\s+"), " ")
            .trim()

        return text
    }

    /**
     * Splits normalized speech text into natural, sentence-sized chunks to prevent
     * Android TTS buffering latency and unnatural monotone paragraph delivery.
     */
    fun splitIntoChunks(
        text: String,
        overallLanguage: DetectedLanguage
    ): List<SpeechChunk> {
        val cleaned = cleanForSpeech(text, overallLanguage)
        if (cleaned.isBlank()) return emptyList()

        // 1. Initial split on major sentence boundaries (Devanagari danda, period, question, exclamation, newline)
        val rawSentences = cleaned.split(Regex("(?<=[\\.?!।\\n])\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val finalizedChunks = mutableListOf<String>()

        for (sentence in rawSentences) {
            if (sentence.length <= TARGET_MAX_CHUNK_LENGTH) {
                finalizedChunks.add(sentence)
            } else {
                // Sentence is long; break at natural clause separators (, ; aur lekin and but)
                val subPhrases = splitLongSentenceAtClauses(sentence)
                finalizedChunks.addAll(subPhrases)
            }
        }

        // 2. Wrap into SpeechChunk objects with accurate chunk indices and per-chunk language detection
        val total = finalizedChunks.size
        return finalizedChunks.mapIndexed { index, chunkText ->
            val chunkLang = if (overallLanguage == DetectedLanguage.HINGLISH) {
                LanguageDetector.detect(chunkText)
            } else {
                overallLanguage
            }
            SpeechChunk(
                index = index,
                totalChunks = total,
                text = chunkText,
                language = chunkLang
            )
        }
    }

    private fun splitLongSentenceAtClauses(sentence: String): List<String> {
        val chunks = mutableListOf<String>()
        // Split on clause punctuation or conjunctions while preserving words
        val parts = sentence.split(Regex("(?<=,)|(?<=;)|(?=\\b(?:aur|lekin|magar|phir|and|but|so|because|which)\\b)"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        var currentBuffer = StringBuilder()

        for (part in parts) {
            if (currentBuffer.length + part.length + 1 > ABSOLUTE_MAX_CHUNK_LENGTH && currentBuffer.isNotEmpty()) {
                chunks.add(currentBuffer.toString().trim())
                currentBuffer = StringBuilder(part)
            } else {
                if (currentBuffer.isNotEmpty()) {
                    currentBuffer.append(" ")
                }
                currentBuffer.append(part)
            }
        }

        if (currentBuffer.isNotEmpty()) {
            chunks.add(currentBuffer.toString().trim())
        }

        // If even clause splitting didn't break down an extraordinarily long run-on without punctuation:
        if (chunks.size == 1 && chunks[0].length > ABSOLUTE_MAX_CHUNK_LENGTH) {
            return splitAtWordBoundaries(chunks[0], TARGET_MAX_CHUNK_LENGTH)
        }

        return chunks
    }

    private fun splitAtWordBoundaries(text: String, targetLength: Int): List<String> {
        val words = text.split(Regex("\\s+"))
        val result = mutableListOf<String>()
        var buffer = StringBuilder()

        for (word in words) {
            if (buffer.length + word.length + 1 > targetLength && buffer.isNotEmpty()) {
                result.add(buffer.toString().trim())
                buffer = StringBuilder(word)
            } else {
                if (buffer.isNotEmpty()) buffer.append(" ")
                buffer.append(word)
            }
        }
        if (buffer.isNotEmpty()) {
            result.add(buffer.toString().trim())
        }
        return result
    }
}
