package com.dost.ai.apps

import kotlin.math.max

/**
 * Result returned by AppMatcher.
 */
sealed class AppMatchResult {
    data class Definite(
        val app: InstalledApp,
        val confidence: Float,
        val matchType: String
    ) : AppMatchResult()

    data class Ambiguous(
        val query: String,
        val candidates: List<InstalledApp>,
        val confidence: Float
    ) : AppMatchResult()

    data class NotFound(
        val query: String
    ) : AppMatchResult()
}

/**
 * AppMatcher searches installed launchable applications using the priority hierarchy specified in Section 5:
 * 1. Exact app label match.
 * 2. Case-insensitive match.
 * 3. Normalized match (stripped whitespace and punctuation).
 * 4. Known alias match (using AppAliases).
 * 5. Strong partial match.
 * 6. Package name match.
 * 7. Fuzzy match only when confidence is high.
 *
 * Adheres to Section 6 & 7:
 * - Never randomly launches when ambiguous; flags multiple candidates.
 * - Rejects low confidence matches to prevent launching the wrong app.
 */
object AppMatcher {

    private const val MIN_FUZZY_CONFIDENCE = 0.75f

    fun match(targetName: String, installedApps: List<InstalledApp>): AppMatchResult {
        val query = targetName.trim()
        if (query.isBlank() || installedApps.isEmpty()) {
            return AppMatchResult.NotFound(query)
        }

        val lowerQuery = query.lowercase()
        val strippedQuery = stripSpacesAndPunctuation(lowerQuery)
        val aliasTarget = AppAliases.resolveAlias(lowerQuery)
        val strippedAliasTarget = stripSpacesAndPunctuation(aliasTarget)
        val allAliases = AppAliases.getAliasesFor(lowerQuery)

        // 1. Exact app label match
        val exactMatches = installedApps.filter { it.appLabel == query }
        if (exactMatches.size == 1) {
            return AppMatchResult.Definite(exactMatches.first(), 1.0f, "EXACT_LABEL")
        } else if (exactMatches.size > 1) {
            return AppMatchResult.Ambiguous(query, exactMatches, 1.0f)
        }

        // 2. Case-insensitive match
        val caseInsensitiveMatches = installedApps.filter { it.appLabel.equals(query, ignoreCase = true) }
        if (caseInsensitiveMatches.size == 1) {
            return AppMatchResult.Definite(caseInsensitiveMatches.first(), 0.98f, "CASE_INSENSITIVE")
        } else if (caseInsensitiveMatches.size > 1) {
            return AppMatchResult.Ambiguous(query, caseInsensitiveMatches, 0.98f)
        }

        // 3. Normalized match (spaces and punctuation stripped)
        // e.g. "whats app" matches "WhatsApp", "google chrome" matches "Google Chrome"
        val normalizedMatches = installedApps.filter {
            stripSpacesAndPunctuation(it.appLabel.lowercase()) == strippedQuery
        }
        if (normalizedMatches.size == 1) {
            return AppMatchResult.Definite(normalizedMatches.first(), 0.95f, "NORMALIZED")
        } else if (normalizedMatches.size > 1) {
            return AppMatchResult.Ambiguous(query, normalizedMatches, 0.95f)
        }

        // 4. Known alias match
        // e.g. "yt" -> "youtube", "cam" -> "camera"
        val aliasMatches = installedApps.filter { app ->
            val appLower = app.appLabel.lowercase()
            val appStripped = stripSpacesAndPunctuation(appLower)
            appLower == aliasTarget ||
            appStripped == strippedAliasTarget ||
            allAliases.any { alias -> appLower == alias || appStripped == stripSpacesAndPunctuation(alias) }
        }
        if (aliasMatches.size == 1) {
            return AppMatchResult.Definite(aliasMatches.first(), 0.92f, "ALIAS_MATCH")
        } else if (aliasMatches.size > 1) {
            return AppMatchResult.Ambiguous(query, aliasMatches, 0.92f)
        }

        // 5. Strong partial match (Word boundary match or app label contains query as a distinct word)
        // e.g., "chrome" matches "Google Chrome", "music" matches "YouTube Music", "Music Player", "Samsung Music"
        val wordMatches = installedApps.filter { app ->
            val words = app.appLabel.lowercase().split(" ", "-", "_", ".")
            words.contains(lowerQuery) || words.contains(aliasTarget)
        }
        if (wordMatches.size == 1) {
            return AppMatchResult.Definite(wordMatches.first(), 0.88f, "STRONG_PARTIAL")
        } else if (wordMatches.size > 1) {
            // Ambiguity check: user says "music" and 3 music apps are installed
            return AppMatchResult.Ambiguous(query, wordMatches, 0.88f)
        }

        // Substring match (query is substring of app label or vice versa, but word length >= 3)
        if (strippedQuery.length >= 3) {
            val substringMatches = installedApps.filter { app ->
                val appStripped = stripSpacesAndPunctuation(app.appLabel.lowercase())
                appStripped.contains(strippedQuery) || strippedQuery.contains(appStripped)
            }
            if (substringMatches.size == 1) {
                return AppMatchResult.Definite(substringMatches.first(), 0.82f, "SUBSTRING")
            } else if (substringMatches.size > 1) {
                return AppMatchResult.Ambiguous(query, substringMatches, 0.82f)
            }
        }

        // 6. Package name match
        // e.g. "com.google.android.youtube" contains "youtube"
        val packageMatches = installedApps.filter { app ->
            val pkg = app.packageName.lowercase()
            pkg.endsWith(".$lowerQuery") ||
            pkg.endsWith(".$aliasTarget") ||
            pkg.contains(".$lowerQuery.") ||
            pkg.contains(".$aliasTarget.")
        }
        if (packageMatches.size == 1) {
            return AppMatchResult.Definite(packageMatches.first(), 0.80f, "PACKAGE_NAME")
        } else if (packageMatches.size > 1) {
            return AppMatchResult.Ambiguous(query, packageMatches, 0.80f)
        }

        // 7. Fuzzy match only when confidence is reasonable (Levenshtein distance)
        // Do NOT match aggressively when confidence is low.
        val scoredCandidates = installedApps.map { app ->
            val score1 = calculateSimilarity(lowerQuery, app.appLabel.lowercase())
            val score2 = calculateSimilarity(strippedQuery, stripSpacesAndPunctuation(app.appLabel.lowercase()))
            val score3 = calculateSimilarity(aliasTarget, app.appLabel.lowercase())
            val maxScore = max(score1, max(score2, score3))
            Pair(app, maxScore)
        }.filter { it.second >= MIN_FUZZY_CONFIDENCE }
         .sortedByDescending { it.second }

        if (scoredCandidates.isNotEmpty()) {
            val topScore = scoredCandidates.first().second
            val topCandidates = scoredCandidates.filter { (topScore - it.second) < 0.05f }
            if (topCandidates.size == 1) {
                return AppMatchResult.Definite(topCandidates.first().first, topScore, "FUZZY_CONFIDENT")
            } else {
                return AppMatchResult.Ambiguous(query, topCandidates.map { it.first }, topScore)
            }
        }

        // Not found
        return AppMatchResult.NotFound(query)
    }

    private fun stripSpacesAndPunctuation(input: String): String {
        return input.replace(Regex("""[\s.,!?;:'"()_\-]+"""), "")
    }

    /**
     * Normalized Levenshtein similarity calculation (1.0 = identical, 0.0 = completely distinct).
     */
    private fun calculateSimilarity(s1: String, s2: String): Float {
        if (s1 == s2) return 1.0f
        if (s1.isEmpty() || s2.isEmpty()) return 0.0f

        val len1 = s1.length
        val len2 = s2.length
        val dp = Array(len1 + 1) { IntArray(len2 + 1) }

        for (i in 0..len1) dp[i][0] = i
        for (j in 0..len2) dp[0][j] = j

        for (i in 1..len1) {
            for (j in 1..len2) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,      // deletion
                    dp[i][j - 1] + 1,      // insertion
                    dp[i - 1][j - 1] + cost // substitution
                )
            }
        }

        val distance = dp[len1][len2]
        val maxLen = max(len1, len2)
        return 1.0f - (distance.toFloat() / maxLen.toFloat())
    }
}
