package com.dost.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.background.BackgroundCapabilityChecker
import com.dost.ai.settings.DostSettings
import com.dost.ai.ui.theme.DostBorder
import com.dost.ai.ui.theme.DostDarkBackground
import com.dost.ai.ui.theme.DostDarkSurface
import com.dost.ai.ui.theme.DostPrimary
import com.dost.ai.ui.theme.DostTextSecondary
import com.dost.ai.voice.TTSVoiceInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentSettings: DostSettings,
    availableVoices: List<TTSVoiceInfo> = emptyList(),
    isHindiAvailable: Boolean = true,
    isVoiceSpeaking: Boolean = false,
    capabilityReport: BackgroundCapabilityChecker.DeviceCapabilityReport? = null,
    onPreviewVoice: (String) -> Unit = {},
    onStopVoice: () -> Unit = {},
    onSaveSettings: (DostSettings) -> Unit,
    onToggleWakeListening: (Boolean) -> Unit = {},
    onToggleBackgroundAssistant: (Boolean) -> Unit = {},
    onOpenBatterySettings: () -> Unit = {},
    onStopDost: () -> Unit = {},
    onBack: () -> Unit
) {
    var voiceResponsesEnabled by remember { mutableStateOf(currentSettings.voiceResponsesEnabled) }
    var speechRate by remember { mutableFloatStateOf(currentSettings.speechRate) }
    var pitch by remember { mutableFloatStateOf(currentSettings.pitch) }
    var speedPreset by remember { mutableStateOf(currentSettings.speedPreset) }
    var pitchPreset by remember { mutableStateOf(currentSettings.pitchPreset) }
    var selectedLanguage by remember { mutableStateOf(currentSettings.language) }
    var selectedVoiceId by remember { mutableStateOf(currentSettings.selectedVoiceId) }
    var debugModeEnabled by remember { mutableStateOf(currentSettings.debugModeEnabled) }
    var selectedTheme by remember { mutableStateOf(currentSettings.theme) }
    var wakeListeningEnabled by remember { mutableStateOf(currentSettings.wakeListeningEnabled) }
    var backgroundAssistantEnabled by remember { mutableStateOf(currentSettings.backgroundAssistantEnabled) }
    var followUpModeEnabled by remember { mutableStateOf(currentSettings.followUpModeEnabled) }
    var followUpDurationSeconds by remember { mutableIntStateOf(currentSettings.followUpDurationSeconds) }
    var wakeAcknowledgementEnabled by remember { mutableStateOf(currentSettings.wakeAcknowledgementEnabled) }
    var wakeAcknowledgementPhrase by remember { mutableStateOf(currentSettings.wakeAcknowledgementPhrase) }

    fun buildCurrentSettings(): DostSettings {
        return currentSettings.copy(
            voiceResponsesEnabled = voiceResponsesEnabled,
            speechRate = speechRate,
            pitch = pitch,
            language = selectedLanguage,
            selectedVoiceId = selectedVoiceId,
            speedPreset = speedPreset,
            pitchPreset = pitchPreset,
            debugModeEnabled = debugModeEnabled,
            theme = selectedTheme,
            wakeListeningEnabled = wakeListeningEnabled,
            backgroundAssistantEnabled = backgroundAssistantEnabled,
            followUpModeEnabled = followUpModeEnabled,
            followUpDurationSeconds = followUpDurationSeconds,
            wakeAcknowledgementEnabled = wakeAcknowledgementEnabled,
            wakeAcknowledgementPhrase = wakeAcknowledgementPhrase
        )
    }

    var previewSampleType by remember { mutableStateOf("Hindi") }

    val sampleTexts = mapOf(
        "Hindi" to "Namaste. Main DOST hoon. Main aapki madad ke liye taiyar hoon.",
        "Hinglish" to "Dost, aaj hum ek interesting problem ko step by step solve karte hain.",
        "English" to "Hello, I am DOST. Let's solve this problem step by step."
    )

    Scaffold(
        containerColor = DostDarkBackground,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DostDarkBackground,
                    titleContentColor = Color.White
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                title = {
                    Text(
                        text = "DOST Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DostDarkBackground)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Section 1: Voice Responses Master Switch
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Voice Responses",
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Speak DOST answers aloud automatically",
                                color = DostTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Switch(
                            checked = voiceResponsesEnabled,
                            onCheckedChange = {
                                voiceResponsesEnabled = it
                                onSaveSettings(
                                    currentSettings.copy(
                                        voiceResponsesEnabled = it,
                                        speechRate = speechRate,
                                        pitch = pitch,
                                        language = selectedLanguage,
                                        selectedVoiceId = selectedVoiceId,
                                        speedPreset = speedPreset,
                                        pitchPreset = pitchPreset,
                                        debugModeEnabled = debugModeEnabled,
                                        theme = selectedTheme
                                    )
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = DostPrimary
                            )
                        )
                    }
                }
            }

            if (voiceResponsesEnabled) {
                // Section 2: Speech Speed & Pitch Controls
                Card(
                    colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Voice Speed & Pitch",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )

                        // Speech Speed Presets
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Speech Speed",
                                    fontSize = 13.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                                Text(
                                    text = "${"%.2f".format(speechRate)}x ($speedPreset)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = DostPrimary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Slow" to 0.85f, "Normal" to 1.0f, "Fast" to 1.15f).forEach { (label, rate) ->
                                    val isSelected = speedPreset == label
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            speedPreset = label
                                            speechRate = rate
                                            onSaveSettings(
                                                currentSettings.copy(
                                                    speechRate = rate,
                                                    speedPreset = label,
                                                    pitch = pitch,
                                                    pitchPreset = pitchPreset,
                                                    voiceResponsesEnabled = voiceResponsesEnabled,
                                                    language = selectedLanguage,
                                                    selectedVoiceId = selectedVoiceId
                                                )
                                            )
                                        },
                                        label = { Text(label) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DostPrimary.copy(alpha = 0.25f),
                                            selectedLabelColor = Color.White,
                                            containerColor = Color.Transparent,
                                            labelColor = DostTextSecondary
                                        )
                                    )
                                }
                            }

                            Slider(
                                value = speechRate,
                                onValueChange = {
                                    speechRate = it
                                    speedPreset = when {
                                        it < 0.92f -> "Slow"
                                        it > 1.08f -> "Fast"
                                        else -> "Normal"
                                    }
                                },
                                onValueChangeFinished = {
                                    onSaveSettings(
                                        currentSettings.copy(
                                            speechRate = speechRate,
                                            speedPreset = speedPreset,
                                            pitch = pitch,
                                            pitchPreset = pitchPreset,
                                            voiceResponsesEnabled = voiceResponsesEnabled,
                                            language = selectedLanguage,
                                            selectedVoiceId = selectedVoiceId
                                        )
                                    )
                                },
                                valueRange = 0.5f..1.6f,
                                steps = 10,
                                colors = SliderDefaults.colors(
                                    thumbColor = DostPrimary,
                                    activeTrackColor = DostPrimary
                                )
                            )
                        }

                        Divider(color = DostBorder)

                        // Pitch Presets
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Voice Pitch",
                                    fontSize = 13.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                                Text(
                                    text = "${"%.2f".format(pitch)} ($pitchPreset)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = DostPrimary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Low" to 0.90f, "Normal" to 1.0f, "High" to 1.10f).forEach { (label, pVal) ->
                                    val isSelected = pitchPreset == label
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            pitchPreset = label
                                            pitch = pVal
                                            onSaveSettings(
                                                currentSettings.copy(
                                                    pitch = pVal,
                                                    pitchPreset = label,
                                                    speechRate = speechRate,
                                                    speedPreset = speedPreset,
                                                    voiceResponsesEnabled = voiceResponsesEnabled,
                                                    language = selectedLanguage,
                                                    selectedVoiceId = selectedVoiceId
                                                )
                                            )
                                        },
                                        label = { Text(label) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DostPrimary.copy(alpha = 0.25f),
                                            selectedLabelColor = Color.White,
                                            containerColor = Color.Transparent,
                                            labelColor = DostTextSecondary
                                        )
                                    )
                                }
                            }

                            Slider(
                                value = pitch,
                                onValueChange = {
                                    pitch = it
                                    pitchPreset = when {
                                        it < 0.95f -> "Low"
                                        it > 1.05f -> "High"
                                        else -> "Normal"
                                    }
                                },
                                onValueChangeFinished = {
                                    onSaveSettings(
                                        currentSettings.copy(
                                            pitch = pitch,
                                            pitchPreset = pitchPreset,
                                            speechRate = speechRate,
                                            speedPreset = speedPreset,
                                            voiceResponsesEnabled = voiceResponsesEnabled,
                                            language = selectedLanguage,
                                            selectedVoiceId = selectedVoiceId
                                        )
                                    )
                                },
                                valueRange = 0.6f..1.4f,
                                steps = 8,
                                colors = SliderDefaults.colors(
                                    thumbColor = DostPrimary,
                                    activeTrackColor = DostPrimary
                                )
                            )
                        }
                    }
                }

                // Section 3: Voice Preview
                Card(
                    colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Voice Preview",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Hear how DOST sounds with your current speed and pitch",
                            color = DostTextSecondary,
                            fontSize = 12.sp
                        )

                        // Sample selector chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Hindi", "Hinglish", "English").forEach { sample ->
                                val isSelected = previewSampleType == sample
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { previewSampleType = sample },
                                    label = { Text(sample) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = DostPrimary.copy(alpha = 0.25f),
                                        selectedLabelColor = Color.White,
                                        containerColor = Color.Transparent,
                                        labelColor = DostTextSecondary
                                    )
                                )
                            }
                        }

                        // Sample Text Preview Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "\"${sampleTexts[previewSampleType] ?: ""}\"",
                                color = Color(0xFF93C5FD),
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }

                        // Play / Stop preview button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (isVoiceSpeaking) {
                                Button(
                                    onClick = onStopVoice,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Stop,
                                        contentDescription = "Stop",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Stop Preview", fontSize = 13.sp, color = Color.White)
                                }
                            } else {
                                Button(
                                    onClick = { onPreviewVoice(previewSampleType) },
                                    colors = ButtonDefaults.buttonColors(containerColor = DostPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Play Preview", fontSize = 13.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }

                // Section 4: Available Voices Selection
                Card(
                    colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Installed Voices",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Choose a specific device voice or let DOST automatically select the highest quality",
                            color = DostTextSecondary,
                            fontSize = 12.sp
                        )

                        // Hindi missing warning card if needed
                        if (!isHindiAvailable) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "Hindi Warning",
                                        tint = Color(0xFFF59E0B),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Notice: Native Hindi voice data was not found in your device's TTS engine. For natural Hindi pronunciation, install Hindi voice data in Android Settings > Accessibility > Text-to-Speech output.",
                                        fontSize = 11.sp,
                                        color = Color(0xFFFDE68A),
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }

                        // Auto Voice Option
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedVoiceId = null
                                    onSaveSettings(
                                        currentSettings.copy(
                                            selectedVoiceId = null,
                                            speechRate = speechRate,
                                            pitch = pitch,
                                            speedPreset = speedPreset,
                                            pitchPreset = pitchPreset,
                                            language = selectedLanguage
                                        )
                                    )
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedVoiceId == null || selectedVoiceId == "auto",
                                onClick = {
                                    selectedVoiceId = null
                                    onSaveSettings(
                                        currentSettings.copy(
                                            selectedVoiceId = null,
                                            speechRate = speechRate,
                                            pitch = pitch,
                                            speedPreset = speedPreset,
                                            pitchPreset = pitchPreset,
                                            language = selectedLanguage
                                        )
                                    )
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = DostPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Automatic (Recommended)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                                Text(
                                    text = "Selects highest quality installed Hindi or English voice dynamically",
                                    fontSize = 11.sp,
                                    color = DostTextSecondary
                                )
                            }
                        }

                        // Specific voices list (if available)
                        availableVoices.take(6).forEach { voice ->
                            val isSelected = selectedVoiceId == voice.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedVoiceId = voice.id
                                        onSaveSettings(
                                            currentSettings.copy(
                                                selectedVoiceId = voice.id,
                                                speechRate = speechRate,
                                                pitch = pitch,
                                                speedPreset = speedPreset,
                                                pitchPreset = pitchPreset,
                                                language = selectedLanguage
                                            )
                                        )
                                    }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        selectedVoiceId = voice.id
                                        onSaveSettings(
                                            currentSettings.copy(
                                                selectedVoiceId = voice.id,
                                                speechRate = speechRate,
                                                pitch = pitch,
                                                speedPreset = speedPreset,
                                                pitchPreset = pitchPreset,
                                                language = selectedLanguage
                                            )
                                        )
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = DostPrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = voice.displayName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Normal,
                                        color = Color(0xFFE2E8F0)
                                    )
                                    Text(
                                        text = "${voice.locale} • ${if (voice.isNetworkRequired) "Online network" else "Offline on-device"}",
                                        fontSize = 10.sp,
                                        color = DostTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Section 5: Language Preference
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Preferred Language",
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Preferred conversational style for DOST",
                        color = DostTextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Auto", "Hindi", "English").forEach { lang ->
                            val isSelected = selectedLanguage == lang
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedLanguage = lang
                                    onSaveSettings(
                                        currentSettings.copy(
                                            voiceResponsesEnabled = voiceResponsesEnabled,
                                            speechRate = speechRate,
                                            pitch = pitch,
                                            language = lang,
                                            selectedVoiceId = selectedVoiceId,
                                            speedPreset = speedPreset,
                                            pitchPreset = pitchPreset,
                                            debugModeEnabled = debugModeEnabled,
                                            theme = selectedTheme
                                        )
                                    )
                                },
                                label = { Text(lang) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DostPrimary.copy(alpha = 0.25f),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.Transparent,
                                    labelColor = DostTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            // Section 6: Debug Mode
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Debug Mode",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Show speech recognition & voice telemetry details",
                            color = DostTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = debugModeEnabled,
                        onCheckedChange = {
                            debugModeEnabled = it
                            onSaveSettings(
                                currentSettings.copy(
                                    voiceResponsesEnabled = voiceResponsesEnabled,
                                    speechRate = speechRate,
                                    pitch = pitch,
                                    language = selectedLanguage,
                                    selectedVoiceId = selectedVoiceId,
                                    speedPreset = speedPreset,
                                    pitchPreset = pitchPreset,
                                    debugModeEnabled = it,
                                    theme = selectedTheme
                                )
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF10B981)
                        )
                    )
                }
            }

            // Section 7: Theme
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Theme",
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        fontSize = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Dark", "System").forEach { t ->
                            val isSelected = selectedTheme == t
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedTheme = t
                                    onSaveSettings(
                                        currentSettings.copy(
                                            voiceResponsesEnabled = voiceResponsesEnabled,
                                            speechRate = speechRate,
                                            pitch = pitch,
                                            language = selectedLanguage,
                                            selectedVoiceId = selectedVoiceId,
                                            speedPreset = speedPreset,
                                            pitchPreset = pitchPreset,
                                            debugModeEnabled = debugModeEnabled,
                                            theme = t
                                        )
                                    )
                                },
                                label = { Text(t) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DostPrimary.copy(alpha = 0.25f),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.Transparent,
                                    labelColor = DostTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            // ====================================================
            // SECTION 8: WAKE PHRASE & ACTIVATION
            // ====================================================
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sensors,
                                    contentDescription = null,
                                    tint = Color(0xFF818CF8),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Wake Phrase Activation",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = "Say \"Dost\", \"Hey Dost\", or \"Hello Dost\" to wake the assistant",
                                color = DostTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        Switch(
                            checked = wakeListeningEnabled,
                            onCheckedChange = {
                                wakeListeningEnabled = it
                                onToggleWakeListening(it)
                                onSaveSettings(buildCurrentSettings().copy(wakeListeningEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF818CF8)
                            )
                        )
                    }

                    if (wakeListeningEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Wake Acknowledgement",
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Spoken response when wake phrase is detected before command",
                            color = DostTextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        val ackOptions = listOf("Ha, bolo.", "Yes?", "I'm listening.", "None")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ackOptions.forEach { opt ->
                                val phraseValue = if (opt == "None") "" else opt
                                val isSelected = (wakeAcknowledgementPhrase == phraseValue) ||
                                        (!wakeAcknowledgementEnabled && opt == "None")
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (opt == "None") {
                                            wakeAcknowledgementEnabled = false
                                            wakeAcknowledgementPhrase = ""
                                        } else {
                                            wakeAcknowledgementEnabled = true
                                            wakeAcknowledgementPhrase = opt
                                        }
                                        onSaveSettings(
                                            buildCurrentSettings().copy(
                                                wakeAcknowledgementEnabled = wakeAcknowledgementEnabled,
                                                wakeAcknowledgementPhrase = wakeAcknowledgementPhrase
                                            )
                                        )
                                    },
                                    label = { Text(opt, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF818CF8).copy(alpha = 0.25f),
                                        selectedLabelColor = Color.White,
                                        containerColor = Color.Transparent,
                                        labelColor = DostTextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // ====================================================
            // SECTION 9: BACKGROUND ASSISTANT
            // ====================================================
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = Color(0xFF60A5FA),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Background Assistant",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = "Keeps DOST available via foreground service with persistent notification",
                                color = DostTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        Switch(
                            checked = backgroundAssistantEnabled,
                            onCheckedChange = {
                                backgroundAssistantEnabled = it
                                onToggleBackgroundAssistant(it)
                                onSaveSettings(buildCurrentSettings().copy(backgroundAssistantEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF60A5FA)
                            )
                        )
                    }
                }
            }

            // ====================================================
            // SECTION 10: FOLLOW-UP MODE
            // ====================================================
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QuestionAnswer,
                                    contentDescription = null,
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Follow-up Mode",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = "Keep listening after DOST speaks so you can ask more without saying 'Dost' again",
                                color = DostTextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        Switch(
                            checked = followUpModeEnabled,
                            onCheckedChange = {
                                followUpModeEnabled = it
                                onSaveSettings(buildCurrentSettings().copy(followUpModeEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF34D399)
                            )
                        )
                    }

                    if (followUpModeEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Listening Window Duration",
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "How long DOST waits for a follow-up question (say 'stop' to cancel)",
                            color = DostTextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        val durationOptions = listOf(5, 10, 15, 30)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            durationOptions.forEach { dur ->
                                val isSelected = followUpDurationSeconds == dur
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        followUpDurationSeconds = dur
                                        onSaveSettings(
                                            buildCurrentSettings().copy(followUpDurationSeconds = dur)
                                        )
                                    },
                                    label = { Text("${dur}s", fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF34D399).copy(alpha = 0.25f),
                                        selectedLabelColor = Color.White,
                                        containerColor = Color.Transparent,
                                        labelColor = DostTextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // ====================================================
            // SECTION 11: DEVICE CAPABILITY & BATTERY OPTIMIZATION
            // ====================================================
            Card(
                colors = CardDefaults.cardColors(containerColor = DostDarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryAlert,
                            contentDescription = null,
                            tint = Color(0xFFFACC15),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Background Readiness & Battery",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val capabilityLevel = capabilityReport?.capabilityLevel?.name ?: "SUPPORTED"
                    val isOptimized = capabilityReport?.isBatteryOptimizationIgnored == false

                    Text(
                        text = "Device Level: $capabilityLevel (Android ${android.os.Build.VERSION.RELEASE}, ${android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() }})",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    if (capabilityReport?.manufacturerNote != null) {
                        Text(
                            text = capabilityReport.manufacturerNote,
                            color = Color(0xFFFBBF24),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onOpenBatterySettings,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFACC15)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (isOptimized) "Disable Battery Saver for DOST" else "Manage Battery Settings",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // ====================================================
            // SECTION 12: EMERGENCY IMMEDIATE HALT (STOP DOST)
            // ====================================================
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Immediate Halt",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }

                    Text(
                        text = "Stops all background services, wake phrase listeners, audio sessions, and text-to-speech immediately.",
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    Button(
                        onClick = {
                            wakeListeningEnabled = false
                            backgroundAssistantEnabled = false
                            onStopDost()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "STOP DOST NOW",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
