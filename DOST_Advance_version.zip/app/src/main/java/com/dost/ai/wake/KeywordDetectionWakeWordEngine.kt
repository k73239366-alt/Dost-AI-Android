package com.dost.ai.wake

import android.content.Context
import android.util.Log

/**
 * Optional / Future Local Keyword Detection Wake Word Engine (e.g., Picovoice Porcupine or TFLite).
 *
 * This implementation acts as a modular placeholder and integration-ready bridge for dedicated
 * low-power on-device hotword models.
 *
 * Implementation Status: REQUIRES OPTIONAL PROVIDER / REQUIRES REAL DEVICE TEST.
 */
class KeywordDetectionWakeWordEngine(
    private val accessKey: String? = null
) : WakeWordEngine {

    override val engineName: String = "Local Keyword Detector (On-Device DSP)"
    override var isListening: Boolean = false
        private set

    override val implementationStatus: WakeEngineStatus =
        WakeEngineStatus.REQUIRES_OPTIONAL_PROVIDER

    private var context: Context? = null
    private var onWakeDetectedCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    override fun initialize(
        context: Context,
        onWakeDetected: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        this.context = context
        this.onWakeDetectedCallback = onWakeDetected
        this.onErrorCallback = onError

        Log.d(TAG, "KeywordDetectionWakeWordEngine initialized in modular bridge mode.")
    }

    override fun startListening() {
        if (accessKey.isNullOrBlank()) {
            Log.i(TAG, "No external keyword provider key configured. Falling back to system wake engine.")
            onErrorCallback?.invoke("Optional on-device keyword model requires an external provider key.")
            return
        }
        isListening = true
    }

    override fun stopListening() {
        isListening = false
    }

    override fun pause() {
        isListening = false
    }

    override fun resume() {
        if (!accessKey.isNullOrBlank()) {
            isListening = true
        }
    }

    override fun release() {
        stopListening()
        context = null
        onWakeDetectedCallback = null
        onErrorCallback = null
    }

    companion object {
        private const val TAG = "KeywordWakeEngine"
    }
}
