package com.dost.ai.data.model

/**
 * Assistant Lifecycle States for DOST 2.0.
 *
 * IDLE: Calm, ready state with subtle slow eye core animation.
 * LISTENING: Active state when microphone input is receiving speech.
 * THINKING: Processing state when command normalization/AI reasoning is executing.
 * PROCESSING: Direct command execution state (e.g. searching/launching app).
 * SUCCESS: Confirmed success state before smoothly returning to IDLE/SPEAKING.
 * SPEAKING: Vocal response output via TextToSpeech with gentle pulsing.
 * ERROR: Transient error state that safely recovers to IDLE.
 */
enum class AssistantState {
    IDLE,
    BACKGROUND_READY,
    WAKE_LISTENING,
    WAKE_DETECTED,
    LISTENING,              // Base speech listening
    LISTENING_COMMAND,      // Active listening for command after wake word
    THINKING,
    EXECUTING,
    PROCESSING,             // Backward-compatible alias for EXECUTING
    SUCCESS,
    SPEAKING,
    FOLLOW_UP,
    PAUSED,
    STOPPED,
    ERROR
}
