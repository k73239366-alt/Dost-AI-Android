package com.dost.ai.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * DeviceTTSProvider: Manages synthesis using the native Android TextToSpeech engine.
 * Supports smooth sentence chunking, quality voice ranking, and immediate interruption.
 */
class DeviceTTSProvider(
    context: Context,
    private val onInitComplete: (Boolean) -> Unit = {}
) : TTSProvider, TextToSpeech.OnInitListener {

    override val name: String
        get() = "Android Native TTS (${tts?.defaultEngine ?: "Default"})"

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private val _isReady = AtomicBoolean(false)
    override val isReady: Boolean
        get() = _isReady.get()

    private var currentChunks: List<SpeechChunk> = emptyList()
    private var onChunkStartCallback: ((SpeechChunk) -> Unit)? = null
    private var onChunkDoneCallback: ((SpeechChunk) -> Unit)? = null
    private var onAllDoneCallback: (() -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    private var currentSelection: VoiceSelector.SelectionResult? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            _isReady.set(true)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    val index = utteranceId?.substringAfter("chunk_")?.substringBefore("_")?.toIntOrNull()
                    if (index != null && index in currentChunks.indices) {
                        onChunkStartCallback?.invoke(currentChunks[index])
                    }
                }

                override fun onDone(utteranceId: String?) {
                    val index = utteranceId?.substringAfter("chunk_")?.substringBefore("_")?.toIntOrNull()
                    if (index != null && index in currentChunks.indices) {
                        onChunkDoneCallback?.invoke(currentChunks[index])

                        // If this was the last chunk in the sequence, trigger final completion
                        if (index == currentChunks.size - 1) {
                            onAllDoneCallback?.invoke()
                            clearActiveCallbacks()
                        }
                    } else if (utteranceId?.startsWith("dost_single") == true) {
                        onAllDoneCallback?.invoke()
                        clearActiveCallbacks()
                    }
                }

                override fun onError(utteranceId: String?) {
                    onError(utteranceId, TextToSpeech.ERROR)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    val errorMsg = "TTS playback error code: $errorCode for utterance $utteranceId"
                    Log.w("DOST_VOICE", errorMsg)
                    onErrorCallback?.invoke(errorMsg)
                    onAllDoneCallback?.invoke()
                    clearActiveCallbacks()
                }
            })

            // Initial voice configuration: check if Hindi is available
            val selection = VoiceSelector.selectVoice(DetectedLanguage.HINDI, tts)
            currentSelection = selection
            applySelectionToEngine(selection)

            onInitComplete(true)
        } else {
            _isReady.set(false)
            Log.e("DOST_VOICE", "Failed to initialize Android TextToSpeech with status: $status")
            onInitComplete(false)
        }
    }

    override fun getAvailableVoices(): List<TTSVoiceInfo> {
        return VoiceSelector.extractVoiceInfos(tts)
    }

    override fun isLanguageAvailable(locale: Locale): Boolean {
        if (!isReady || tts == null) return false
        return try {
            tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED >= TextToSpeech.LANG_AVAILABLE
        } catch (e: Exception) {
            false
        }
    }

    override fun speak(
        chunks: List<SpeechChunk>,
        params: TTSPlaybackParams,
        onStart: (SpeechChunk) -> Unit,
        onChunkComplete: (SpeechChunk) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isReady || tts == null) {
            onError("TTS engine is not ready")
            onDone()
            return
        }

        if (chunks.isEmpty()) {
            onDone()
            return
        }

        // Stop any previous speech immediately
        stop()

        currentChunks = chunks
        onChunkStartCallback = onStart
        onChunkDoneCallback = onChunkComplete
        onAllDoneCallback = onDone
        onErrorCallback = onError

        val effectiveRate = params.speechRate.coerceIn(0.5f, 2.0f)
        val effectivePitch = params.pitch.coerceIn(0.5f, 2.0f)

        tts?.setSpeechRate(effectiveRate)
        tts?.setPitch(effectivePitch)

        val sessionTimestamp = System.currentTimeMillis()

        // Queue chunks sequentially: first chunk flushes, remaining chunks append to queue smoothly
        for (i in chunks.indices) {
            val chunk = chunks[i]
            val queueMode = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val utteranceId = "chunk_${i}_$sessionTimestamp"

            // Set voice/language appropriate for the chunk
            val selection = VoiceSelector.selectVoice(
                targetLanguage = chunk.language,
                tts = tts,
                userVoiceId = params.voiceId
            )
            currentSelection = selection
            applySelectionToEngine(selection)

            val bundle = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            val result = tts?.speak(chunk.text, queueMode, bundle, utteranceId)
            if (result == TextToSpeech.ERROR) {
                Log.w("DOST_VOICE", "tts.speak returned ERROR for chunk $i: ${chunk.text}")
                // Fallback attempt with default locale if customized voice caused failure
                tts?.language = Locale.getDefault()
                tts?.speak(chunk.text, queueMode, bundle, utteranceId)
            }
        }
    }

    override fun stop() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (e: Exception) {
            Log.w("DOST_VOICE", "Error stopping TTS: ${e.message}")
        } finally {
            clearActiveCallbacks()
        }
    }

    override fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        _isReady.set(false)
    }

    fun getCurrentVoiceSelection(): VoiceSelector.SelectionResult? {
        return currentSelection
    }

    fun getEngineName(): String {
        return tts?.defaultEngine ?: "Android Default TTS"
    }

    private fun applySelectionToEngine(selection: VoiceSelector.SelectionResult) {
        val engine = tts ?: return
        try {
            if (selection.voice != null) {
                engine.voice = selection.voice
            } else {
                engine.language = selection.fallbackLocale
            }
        } catch (e: Exception) {
            Log.w("DOST_VOICE", "Error applying voice to engine: ${e.message}")
            try {
                engine.language = selection.fallbackLocale
            } catch (_: Exception) {}
        }
    }

    private fun clearActiveCallbacks() {
        currentChunks = emptyList()
        onChunkStartCallback = null
        onChunkDoneCallback = null
        onAllDoneCallback = null
        onErrorCallback = null
    }
}
