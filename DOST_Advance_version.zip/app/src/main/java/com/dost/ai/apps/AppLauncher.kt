package com.dost.ai.apps

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.dost.ai.commands.CommandResult
import com.dost.ai.commands.CommandStatus

/**
 * AppLauncher: Safely and legitimately launches installed applications and system intents.
 *
 * Adheres strictly to Section 8, 9, 15, 16:
 * - Proper FLAG_ACTIVITY_NEW_TASK flag handling.
 * - Handles camera, settings, browser system intents safely.
 * - Never claims success unless the Android intent was successfully dispatched without exception.
 * - Graceful failure handling without crashing.
 */
class AppLauncher(private val context: Context) {

    companion object {
        private const val TAG = "AppLauncher"
    }

    /**
     * Launches an installed application represented by [InstalledApp].
     */
    fun launchApp(app: InstalledApp): CommandResult {
        return launchPackage(app.packageName, app.appLabel)
    }

    /**
     * Launches an application given its package name and friendly display label.
     */
    fun launchPackage(packageName: String, appLabel: String? = null): CommandResult {
        val label = appLabel ?: packageName

        try {
            val pm = context.packageManager
            var launchIntent = pm.getLaunchIntentForPackage(packageName)

            if (launchIntent == null) {
                // If standard launcher intent is not returned, attempt explicit MAIN/LAUNCHER intent
                launchIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(packageName)
                }
                val resolveInfos = pm.queryIntentActivities(launchIntent, 0)
                if (resolveInfos.isNotEmpty()) {
                    val activityInfo = resolveInfos.first().activityInfo
                    launchIntent.setClassName(activityInfo.packageName, activityInfo.name)
                } else {
                    launchIntent = null
                }
            }

            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(launchIntent)
                Log.d(TAG, "Successfully launched app: $label ($packageName)")
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Opening $label.",
                    targetApp = label,
                    launchedPackage = packageName,
                    launchedAppName = label
                )
            } else {
                Log.w(TAG, "No launch activity found for package: $packageName")
                return CommandResult(
                    status = CommandStatus.FAILED,
                    message = "Could not find launch activity for $label.",
                    targetApp = label,
                    launchedPackage = packageName,
                    error = "No launchable activity found"
                )
            }
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "ActivityNotFoundException launching $packageName: ${e.message}")
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Could not open $label. Activity not found.",
                targetApp = label,
                launchedPackage = packageName,
                error = e.localizedMessage
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException launching $packageName: ${e.message}")
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Permission denied while attempting to launch $label.",
                targetApp = label,
                launchedPackage = packageName,
                error = e.localizedMessage
            )
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected exception launching $packageName: ${e.message}", e)
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Failed to open $label: ${e.localizedMessage}",
                targetApp = label,
                launchedPackage = packageName,
                error = e.localizedMessage
            )
        }
    }

    /**
     * Dedicated Camera intent launcher (Section 16).
     * Attempts to open the default camera app using standard Android MediaStore camera action.
     */
    fun launchCamera(): CommandResult {
        try {
            // First try STILL_IMAGE_CAMERA
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (cameraIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(cameraIntent)
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Opening Camera.",
                    targetApp = "Camera",
                    launchedAppName = "Camera"
                )
            }

            // Fallback to ACTION_IMAGE_CAPTURE
            val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (captureIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(captureIntent)
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Opening Camera.",
                    targetApp = "Camera",
                    launchedAppName = "Camera"
                )
            }

            return CommandResult(
                status = CommandStatus.FAILED,
                message = "No camera application was found on this device.",
                targetApp = "Camera",
                error = "Camera activity not resolved"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch camera: ${e.message}", e)
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Could not open camera: ${e.localizedMessage}",
                targetApp = "Camera",
                error = e.localizedMessage
            )
        }
    }

    /**
     * Dedicated Settings intent launcher (Section 15).
     */
    fun launchSettings(): CommandResult {
        try {
            val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(settingsIntent)
            return CommandResult(
                status = CommandStatus.SUCCESS,
                message = "Opening Settings.",
                targetApp = "Settings",
                launchedAppName = "Settings"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch Settings: ${e.message}", e)
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Could not open Settings.",
                targetApp = "Settings",
                error = e.localizedMessage
            )
        }
    }
}
