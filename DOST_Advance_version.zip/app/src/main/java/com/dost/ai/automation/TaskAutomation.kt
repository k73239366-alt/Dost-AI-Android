package com.dost.ai.automation

import android.content.Context
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolExecutor
import com.dost.ai.tools.ToolResult

data class PlannedTaskStep(
    val stepIndex: Int,
    val toolName: String,
    val description: String,
    val parameters: Map<String, Any?>,
    val isCompleted: Boolean = false,
    val result: ToolResult? = null
)

data class TaskPlan(
    val id: String,
    val originalPrompt: String,
    val steps: List<PlannedTaskStep>,
    val currentStepIndex: Int = 0,
    val isCancelled: Boolean = false
)

/**
 * Breaks multi-intent user requests into ordered steps with loop protection and retry limits.
 *
 * Example:
 * "Remind me to study in 1 hour and open Chrome."
 * Plan:
 * 1. Schedule reminder.
 * 2. Launch Chrome.
 */
class TaskPlanner {
    fun planTask(prompt: String): TaskPlan? {
        val lower = prompt.lowercase()
        val hasAnd = lower.contains(" and ") || lower.contains(" aur ") || lower.contains(" then ") || lower.contains(" fir ")

        if (!hasAnd) return null

        val parts = if (lower.contains(" and ")) {
            prompt.split(Regex("(?i)\\band\\b"))
        } else if (lower.contains(" aur ")) {
            prompt.split(Regex("(?i)\\baur\\b"))
        } else if (lower.contains(" then ")) {
            prompt.split(Regex("(?i)\\bthen\\b"))
        } else {
            prompt.split(Regex("(?i)\\bfir\\b"))
        }

        if (parts.size < 2) return null

        val steps = parts.mapIndexed { index, part ->
            val cleanPart = part.trim()
            PlannedTaskStep(
                stepIndex = index + 1,
                toolName = if (cleanPart.contains("remind", ignoreCase = true) || cleanPart.contains("yaad", ignoreCase = true)) {
                    "CREATE_REMINDER"
                } else if (cleanPart.contains("open", ignoreCase = true) || cleanPart.contains("kholo", ignoreCase = true)) {
                    "OPEN_APP"
                } else {
                    "NORMAL_CONVERSATION"
                },
                description = cleanPart,
                parameters = mapOf("rawText" to cleanPart)
            )
        }

        return TaskPlan(
            id = "plan_${System.currentTimeMillis()}",
            originalPrompt = prompt,
            steps = steps
        )
    }
}

/**
 * Manages execution of planned steps with loop protection, max retries, and cancellation.
 */
class TaskExecutionManager(
    private val toolExecutor: ToolExecutor
) {
    private val maxRetries = 2
    private var isCancelled = false

    fun cancelActivePlan() {
        isCancelled = true
    }

    suspend fun executePlan(
        context: Context,
        plan: TaskPlan,
        onStepProgress: (PlannedTaskStep) -> Unit
    ): List<ToolResult> {
        isCancelled = false
        val results = mutableListOf<ToolResult>()

        for (step in plan.steps) {
            if (isCancelled) {
                results.add(ToolResult.failure(step.toolName, "Task was cancelled by user."))
                break
            }

            var attempts = 0
            var stepResult: ToolResult? = null

            while (attempts <= maxRetries && (stepResult == null || stepResult.status == com.dost.ai.commands.CommandStatus.FAILED)) {
                attempts++
                stepResult = toolExecutor.executeTool(context, step.toolName, step.parameters)
                if (stepResult.status == com.dost.ai.commands.CommandStatus.SUCCESS) break
            }

            val finalResult = stepResult ?: ToolResult.failure(step.toolName, "Execution failed after retries.")
            results.add(finalResult)
            onStepProgress(step.copy(isCompleted = true, result = finalResult))

            // Loop protection: stop if a prerequisite step fails
            if (finalResult.status != com.dost.ai.commands.CommandStatus.SUCCESS) {
                break
            }
        }

        return results
    }
}

/**
 * Architecture for Foreground Service and Background Assistant management.
 */
class BackgroundAssistantManager(private val context: Context) {
    fun isBackgroundExecutionPermitted(): Boolean {
        return true
    }
}

/**
 * Manages proactive checks (reminders, study schedules) without spam.
 */
class ProactiveAssistantManager {
    fun shouldTriggerProactiveReminder(lastInteractionTime: Long): Boolean {
        val now = System.currentTimeMillis()
        // Minimum 4 hours between unsolicited proactive suggestions
        return (now - lastInteractionTime) > (4 * 3600 * 1000)
    }
}
