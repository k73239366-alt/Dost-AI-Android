package com.dost.ai.debug

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DebugRecord(
    val timestamp: Long = System.currentTimeMillis(),
    val finalTranscript: String,
    val normalizedCommand: String,
    val detectedIntent: String,
    val selectedTool: String?,
    val validatedParameters: Map<String, Any?>,
    val executionResult: String,
    val executionDurationMs: Long,
    val aiProviderLatencyMs: Long,
    val errorTrace: String? = null
)

/**
 * Debug Telemetry collector for DOST:
 * Records transparent pipeline information visible ONLY when Debug Mode is enabled.
 */
class DebugTelemetry {
    private val _records = MutableStateFlow<List<DebugRecord>>(emptyList())
    val records: StateFlow<List<DebugRecord>> = _records.asStateFlow()

    fun log(record: DebugRecord) {
        val current = _records.value.toMutableList()
        current.add(0, record)
        if (current.size > 50) {
            _records.value = current.take(50)
        } else {
            _records.value = current
        }
    }

    fun clear() {
        _records.value = emptyList()
    }
}
