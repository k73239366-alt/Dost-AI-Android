package com.dost.ai.core

import android.util.Log
import com.dost.ai.data.model.AssistantState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Centralized State Machine for DOST 2.0 Assistant.
 *
 * Enforces valid state transitions and single microphone ownership:
 * IDLE -> WAKE_LISTENING / BACKGROUND_READY / LISTENING_COMMAND
 * WAKE_LISTENING -> WAKE_DETECTED -> LISTENING_COMMAND
 * LISTENING_COMMAND -> THINKING -> EXECUTING -> SPEAKING -> FOLLOW_UP -> WAKE_LISTENING / IDLE
 * Any State -> STOPPED / PAUSED / ERROR -> IDLE
 */
class AssistantStateManager {

    private val _currentState = MutableStateFlow(AssistantState.IDLE)
    val currentState: StateFlow<AssistantState> = _currentState.asStateFlow()

    private val _statusDescription = MutableStateFlow("Ready")
    val statusDescription: StateFlow<String> = _statusDescription.asStateFlow()

    @Synchronized
    fun transitionTo(newState: AssistantState, customMessage: String? = null): Boolean {
        val oldState = _currentState.value
        if (oldState == newState && customMessage == null) return false

        Log.d(TAG, "State transition: $oldState -> $newState (${customMessage ?: ""})")
        _currentState.value = newState

        _statusDescription.value = customMessage ?: when (newState) {
            AssistantState.IDLE -> "Ready"
            AssistantState.BACKGROUND_READY -> "Background Assistant Active"
            AssistantState.WAKE_LISTENING -> "Wake Listening Active · Say 'Dost'"
            AssistantState.WAKE_DETECTED -> "Wake phrase detected!"
            AssistantState.LISTENING -> "Listening..."
            AssistantState.LISTENING_COMMAND -> "Listening for your command..."
            AssistantState.THINKING -> "Thinking..."
            AssistantState.EXECUTING, AssistantState.PROCESSING -> "Executing action..."
            AssistantState.SUCCESS -> "Action completed"
            AssistantState.SPEAKING -> "Speaking..."
            AssistantState.FOLLOW_UP -> "Listening for follow-up..."
            AssistantState.PAUSED -> "DOST is paused"
            AssistantState.STOPPED -> "DOST has stopped"
            AssistantState.ERROR -> "Something went wrong"
        }
        return true
    }

    fun isListeningActive(): Boolean {
        val s = _currentState.value
        return s == AssistantState.LISTENING ||
                s == AssistantState.LISTENING_COMMAND ||
                s == AssistantState.WAKE_LISTENING ||
                s == AssistantState.FOLLOW_UP
    }

    companion object {
        private const val TAG = "AssistantStateManager"
    }
}
