package com.dost.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.ui.theme.DostBorderSubtle
import com.dost.ai.ui.theme.DostDarkSurface
import com.dost.ai.ui.theme.DostTextPrimary
import com.dost.ai.ui.theme.DostTextSecondary

data class QuickActionItem(
    val label: String,
    val icon: ImageVector,
    val query: String
)

@Composable
fun QuickActionChips(
    onActionSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        QuickActionItem("Ask", Icons.Default.QuestionAnswer, "Dost, explain in simple words: "),
        QuickActionItem("Learn", Icons.Default.Lightbulb, "Dost, teach me something new about "),
        QuickActionItem("Open App", Icons.Default.Apps, "Dost, open "),
        QuickActionItem("Help", Icons.Default.HelpOutline, "Dost, what all can you do?")
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(DostDarkSurface)
                    .border(1.dp, DostBorderSubtle, RoundedCornerShape(16.dp))
                    .clickable { onActionSelected(item.query) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = DostTextSecondary,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = item.label,
                    fontSize = 12.sp,
                    color = DostTextPrimary
                )
            }
        }
    }
}
