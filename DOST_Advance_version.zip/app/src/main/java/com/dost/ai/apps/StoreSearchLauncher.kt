package com.dost.ai.apps

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.dost.ai.commands.CommandResult
import com.dost.ai.commands.CommandStatus

/**
 * StoreSearchLauncher: Launches Google Play Store search or falls back to web Play Store.
 *
 * Adheres strictly to Section 11:
 * - Uses legitimate Android market:// URI or web fallback.
 * - Graceful failure handling.
 * - Never claims success if intent dispatch fails.
 */
class StoreSearchLauncher(private val context: Context) {

    companion object {
        private const val TAG = "StoreSearchLauncher"
    }

    fun searchPlayStore(appName: String): CommandResult {
        val query = appName.trim()
        if (query.isBlank()) {
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Search query cannot be empty.",
                error = "Empty query"
            )
        }

        try {
            val encodedQuery = Uri.encode(query)
            // Primary intent: Play Store client URI
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$encodedQuery")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (marketIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(marketIntent)
                Log.d(TAG, "Opened Play Store market search for: $query")
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Searching Play Store for \"$query\".",
                    targetApp = query,
                    fallbackQuery = query
                )
            }

            // Fallback: Browser Play Store search
            val webStoreIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/search?q=$encodedQuery&c=apps")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (webStoreIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(webStoreIntent)
                Log.d(TAG, "Opened web Play Store search for: $query")
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Searching Play Store for \"$query\".",
                    targetApp = query,
                    fallbackQuery = query
                )
            }

            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Neither Google Play Store nor a web browser is available to search for $query.",
                targetApp = query,
                error = "Play Store and browser unavailable"
            )
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "ActivityNotFoundException searching Play Store: ${e.message}")
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Play Store is not installed or available on this device.",
                targetApp = query,
                error = e.localizedMessage
            )
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error searching Play Store: ${e.message}", e)
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Could not open Play Store search for $query: ${e.localizedMessage}",
                targetApp = query,
                error = e.localizedMessage
            )
        }
    }
}
