package com.dost.ai.tools

import android.content.Context

/**
 * Interface contract for every tool in the DOST Tool Registry.
 *
 * Requirements:
 * - Typed parameters
 * - Parameter validation
 * - Permission requirements check
 * - Confirmation requirements check
 * - Single execution
 * - Typed ToolResult
 */
interface BaseTool {
    val name: String
    val description: String
    val requiredPermission: String? get() = null
    val requiresConfirmation: Boolean get() = false

    /**
     * Validates input parameters before execution.
     * Returns null if valid, or a descriptive error message if invalid.
     */
    fun validateParams(params: Map<String, Any?>): String?

    /**
     * Checks whether the tool requires runtime permission that is not yet granted.
     */
    fun hasRequiredPermission(context: Context): Boolean {
        val perm = requiredPermission ?: return true
        return androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            perm
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /**
     * Executes the legitimate native action once.
     */
    suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult
}
