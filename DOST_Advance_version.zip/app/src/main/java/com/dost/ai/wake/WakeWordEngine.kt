package com.dost.ai.wake

import android.content.Context

/**
 * Pluggable Wake Word Engine abstraction for DOST 2.0.
 *
 * Provides a unified lifecycle contract for any wake word provider:
 * - System-supported recognition (Android SpeechRecognizer keyword continuous loop)
 * - Local on-device keyword detector (e.g. Porcupine / Snowboy / TensorFlow Lite)
 * - Future external provider
 *
 * Guarantees safe microphone ownership and lifecycle transitions.
 */
interface WakeWordEngine {
    val engineName: String
    val isListening: Boolean
    val implementationStatus: WakeEngineStatus

    fun initialize(
        context: Context,
        onWakeDetected: (wakePhrase: String) -> Unit,
        onError: (errorMessage: String) -> Unit
    )

    fun startListening()
    fun stopListening()
    fun pause()
    fun resume()
    fun release()
}

/**
 * Implementation readiness status for wake word engines.
 */
enum class WakeEngineStatus {
    IMPLEMENTED,
    ARCHITECTURE_READY,
    REQUIRES_OPTIONAL_PROVIDER,
    REQUIRES_REAL_DEVICE_TEST,
    RESTRICTED_BY_DEVICE_ANDROID
}
