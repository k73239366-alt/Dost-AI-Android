package com.dost.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.data.model.AssistantState
import com.dost.ai.ui.theme.DostDarkBackground
import com.dost.ai.ui.theme.DostPrimary
import com.dost.ai.ui.theme.DostTextSecondary
import com.dost.ai.ui.theme.DostTextTertiary

@Composable
fun DostTopBar(
    assistantState: AssistantState,
    isDebugModeEnabled: Boolean,
    onToggleDebugMode: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val indicatorColor by animateColorAsState(
        targetValue = when (assistantState) {
            AssistantState.IDLE -> Color(0xFF10B981)
            AssistantState.BACKGROUND_READY -> Color(0xFF60A5FA)
            AssistantState.WAKE_LISTENING -> Color(0xFF818CF8)
            AssistantState.WAKE_DETECTED -> Color(0xFFF43F5E)
            AssistantState.LISTENING, AssistantState.LISTENING_COMMAND -> Color(0xFF38BDF8)
            AssistantState.FOLLOW_UP -> Color(0xFF34D399)
            AssistantState.THINKING -> Color(0xFFFACC15)
            AssistantState.PROCESSING, AssistantState.EXECUTING -> Color(0xFFFB923C)
            AssistantState.SPEAKING -> DostPrimary
            AssistantState.SUCCESS -> Color(0xFF10B981)
            AssistantState.PAUSED, AssistantState.STOPPED -> Color(0xFF94A3B8)
            AssistantState.ERROR -> Color(0xFFEF4444)
            else -> Color(0xFF10B981)
        },
        animationSpec = tween(durationMillis = 300),
        label = "IndicatorColor"
    )

    val statusLabel = when (assistantState) {
        AssistantState.IDLE -> "Ready"
        AssistantState.BACKGROUND_READY -> "Background"
        AssistantState.WAKE_LISTENING -> "Wake Active"
        AssistantState.WAKE_DETECTED -> "Wake Alert"
        AssistantState.LISTENING, AssistantState.LISTENING_COMMAND -> "Listening"
        AssistantState.FOLLOW_UP -> "Follow-up"
        AssistantState.THINKING -> "Thinking"
        AssistantState.PROCESSING, AssistantState.EXECUTING -> "Executing"
        AssistantState.SPEAKING -> "Speaking"
        AssistantState.SUCCESS -> "Done"
        AssistantState.PAUSED -> "Paused"
        AssistantState.STOPPED -> "Stopped"
        AssistantState.ERROR -> "Attention"
        else -> "Ready"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(DostDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: DOST Identity & Subtitle
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "DOST",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                // Subtle live status indicator: ● Ready / Listening / Thinking
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 1.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(indicatorColor)
                    )
                    Text(
                        text = statusLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = indicatorColor
                    )
                }
            }

            Text(
                text = "Your AI Assistant",
                fontSize = 11.sp,
                fontWeight = FontWeight.Normal,
                color = DostTextSecondary
            )
        }

        // Right: Settings & Optional Debug Toggle
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Subtle debug button if enabled
            if (isDebugModeEnabled) {
                IconButton(
                    onClick = onToggleDebugMode,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Toggle Debug Mode",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Neatly placed Settings button
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = DostTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
