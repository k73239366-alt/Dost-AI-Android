package com.dost.ai.device

import android.content.Context
import android.content.SharedPreferences
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class DostNote(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Tool for creating, reading, searching, and managing local notes.
 */
class NotesTool(private val context: Context) : BaseTool {
    override val name: String = "CREATE_NOTE"
    override val description: String = "Creates, reads, and searches user notes securely on the device."

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_notes_prefs", Context.MODE_PRIVATE)

    override fun validateParams(params: Map<String, Any?>): String? {
        val action = (params["action"] as? String)?.lowercase() ?: "create"
        if (action == "create") {
            val content = (params["content"] as? String)?.trim()
            if (content.isNullOrBlank()) return "Note content cannot be empty."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val action = (params["action"] as? String)?.lowercase() ?: "create"
        return when (action) {
            "create" -> {
                val title = (params["title"] as? String)?.trim() ?: "Quick Note"
                val content = (params["content"] as? String)?.trim() ?: ""
                val note = DostNote(title = title, content = content)
                saveNote(note)
                ToolResult.success(name, "Note note kar liya gaya hai: \"$title\"", mapOf("noteId" to note.id))
            }
            "search" -> {
                val query = (params["query"] as? String)?.trim()?.lowercase() ?: ""
                val notes = getAllNotes().filter {
                    it.title.lowercase().contains(query) || it.content.lowercase().contains(query)
                }
                if (notes.isEmpty()) {
                    ToolResult.notFound(name, "\"$query\" se related koi note nahi mila.")
                } else {
                    val summary = notes.joinToString("\n• ") { "${it.title}: ${it.content}" }
                    ToolResult.success(name, "Aapke notes:\n• $summary", mapOf("count" to notes.size))
                }
            }
            "list" -> {
                val notes = getAllNotes()
                if (notes.isEmpty()) {
                    ToolResult.success(name, "Aapke paas abhi koi saved notes nahi hain.", mapOf("count" to 0))
                } else {
                    val summary = notes.take(5).joinToString("\n• ") { "${it.title}: ${it.content}" }
                    ToolResult.success(name, "Aapke haal ke notes:\n• $summary", mapOf("count" to notes.size))
                }
            }
            "delete" -> {
                val noteId = params["noteId"] as? String
                if (noteId == null) {
                    ToolResult.failure(name, "Note ID is required for deletion.")
                } else {
                    deleteNote(noteId)
                    ToolResult.success(name, "Note delete kar diya gaya hai.", mapOf("deletedId" to noteId))
                }
            }
            else -> ToolResult.failure(name, "Unsupported note action: $action")
        }
    }

    private fun getAllNotes(): List<DostNote> {
        val raw = prefs.getString("notes_json", "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = mutableListOf<DostNote>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                DostNote(
                    id = obj.getString("id"),
                    title = obj.getString("title"),
                    content = obj.getString("content"),
                    timestamp = obj.getLong("timestamp")
                )
            )
        }
        return list.sortedByDescending { it.timestamp }
    }

    private fun saveNote(note: DostNote) {
        val current = getAllNotes().toMutableList()
        current.add(0, note)
        val array = JSONArray()
        current.forEach { n ->
            val obj = JSONObject().apply {
                put("id", n.id)
                put("title", n.title)
                put("content", n.content)
                put("timestamp", n.timestamp)
            }
            array.put(obj)
        }
        prefs.edit().putString("notes_json", array.toString()).apply()
    }

    private fun deleteNote(noteId: String) {
        val current = getAllNotes().filter { it.id != noteId }
        val array = JSONArray()
        current.forEach { n ->
            val obj = JSONObject().apply {
                put("id", n.id)
                put("title", n.title)
                put("content", n.content)
                put("timestamp", n.timestamp)
            }
            array.put(obj)
        }
        prefs.edit().putString("notes_json", array.toString()).apply()
    }
}
