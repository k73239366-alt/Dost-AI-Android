package com.dost.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DostPrimary,
    secondary = DostSecondary,
    tertiary = DostAccent,
    background = DostDarkBackground,
    surface = DostDarkSurface,
    surfaceVariant = DostDarkSurfaceVariant,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = DostTextPrimary,
    onSurface = DostTextPrimary,
    error = DostError
)

@Composable
fun DostTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
