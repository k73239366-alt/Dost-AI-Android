package com.dost.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.apps.InstalledApp
import com.dost.ai.data.model.ChatMessage
import com.dost.ai.data.model.MessageSender
import com.dost.ai.ui.theme.*

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    onCopyText: (String) -> Unit,
    onLaunchApp: (InstalledApp) -> Unit = {},
    onSearchPlayStore: (String) -> Unit = {},
    onSearchWeb: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isUser = message.sender == MessageSender.USER
    val alignment = if (isUser) Alignment.End else Alignment.Start

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        // Sender Label & Subtle Timestamp
        Row(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(DostPrimary)
                )
            }

            Text(
                text = if (isUser) "You" else "DOST",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isUser) DostTextSecondary else DostPrimary
            )
        }

        // Clean Modern Message Bubble
        Box(
            modifier = Modifier
                .widthIn(max = 330.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(
                    when {
                        isUser -> Color(0xFF1E2330)
                        message.isError -> Color(0xFF331418)
                        else -> DostDarkSurface
                    }
                )
                .border(
                    width = 1.dp,
                    color = when {
                        isUser -> Color(0x1AFFFFFF)
                        message.isError -> Color(0x40EF4444)
                        else -> DostBorderSubtle
                    },
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .padding(horizontal = 14.dp, vertical = 11.dp)
        ) {
            SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Split message for code block rendering
                    val parts = splitCodeBlocks(message.text)
                    parts.forEach { part ->
                        if (part.isCode) {
                            // Syntax-styled code box with copy button
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF090A0E))
                                    .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = part.language.ifBlank { "code" }.uppercase(),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = DostPrimary
                                    )
                                    IconButton(
                                        onClick = { onCopyText(part.content) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy code",
                                            tint = DostTextSecondary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = part.content,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFF38BDF8),
                                    lineHeight = 16.sp
                                )
                            }
                        } else {
                            Text(
                                text = part.content,
                                color = if (message.isError) Color(0xFFFCA5A5) else DostTextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Ambiguous candidate apps (e.g. Music -> Spotify or YouTube Music)
                    if (message.ambiguousCandidates.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Choose an app to open:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = DostTextSecondary
                        )
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            message.ambiguousCandidates.forEach { candidate ->
                                Surface(
                                    onClick = { onLaunchApp(candidate) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF1B1E28),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(DostPrimarySubtle),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = candidate.appLabel.take(1).uppercase(),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DostPrimary
                                                )
                                            }
                                            Text(
                                                text = candidate.appLabel,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color.White
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.Launch,
                                            contentDescription = null,
                                            tint = Color(0xFF38BDF8),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Fallback search options when app is not installed
                    if (!message.searchFallbackQuery.isNullOrBlank()) {
                        val query = message.searchFallbackQuery
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { onSearchPlayStore(query) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Play Store", fontSize = 11.sp, color = Color.White)
                            }

                            Button(
                                onClick = { onSearchWeb(query) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Web Search", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

data class MessagePart(
    val content: String,
    val isCode: Boolean = false,
    val language: String = ""
)

fun splitCodeBlocks(text: String): List<MessagePart> {
    val result = mutableListOf<MessagePart>()
    val regex = Regex("```([a-zA-Z0-9_-]*)\\n([\\s\\S]*?)```")
    var lastIndex = 0

    regex.findAll(text).forEach { match ->
        if (match.range.first > lastIndex) {
            result.add(
                MessagePart(
                    content = text.substring(lastIndex, match.range.first),
                    isCode = false
                )
            )
        }
        val lang = match.groupValues[1]
        val code = match.groupValues[2]
        result.add(MessagePart(content = code.trim(), isCode = true, language = lang))
        lastIndex = match.range.last + 1
    }

    if (lastIndex < text.length) {
        result.add(MessagePart(content = text.substring(lastIndex), isCode = false))
    }

    return if (result.isEmpty()) listOf(MessagePart(content = text, isCode = false)) else result
}
