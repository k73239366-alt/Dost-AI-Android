package com.dost.ai.settings

import android.content.Context
import android.content.SharedPreferences

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_settings_prefs", Context.MODE_PRIVATE)

    fun getSettings(): DostSettings {
        return DostSettings(
            voiceResponsesEnabled = prefs.getBoolean(KEY_VOICE_ENABLED, true),
            speechRate = prefs.getFloat(KEY_SPEECH_RATE, 1.0f),
            pitch = prefs.getFloat(KEY_PITCH, 1.0f),
            language = prefs.getString(KEY_LANGUAGE, "Auto") ?: "Auto",
            selectedVoiceId = prefs.getString(KEY_SELECTED_VOICE_ID, null),
            speedPreset = prefs.getString(KEY_SPEED_PRESET, "Normal") ?: "Normal",
            pitchPreset = prefs.getString(KEY_PITCH_PRESET, "Normal") ?: "Normal",
            debugModeEnabled = prefs.getBoolean(KEY_DEBUG_MODE, false),
            theme = prefs.getString(KEY_THEME, "Dark") ?: "Dark",
            serverBaseUrl = prefs.getString(KEY_SERVER_URL, "https://ais-dev-iov64pbpvf7fnwhjxokl5q-852504415192.asia-east1.run.app")
                ?: "https://ais-dev-iov64pbpvf7fnwhjxokl5q-852504415192.asia-east1.run.app",
            wakeListeningEnabled = prefs.getBoolean(KEY_WAKE_LISTENING, false),
            backgroundAssistantEnabled = prefs.getBoolean(KEY_BACKGROUND_ASSISTANT, false),
            followUpModeEnabled = prefs.getBoolean(KEY_FOLLOW_UP_ENABLED, true),
            followUpDurationSeconds = prefs.getInt(KEY_FOLLOW_UP_DURATION, 5),
            wakeAcknowledgementEnabled = prefs.getBoolean(KEY_WAKE_ACK_ENABLED, true),
            wakeAcknowledgementPhrase = prefs.getString(KEY_WAKE_ACK_PHRASE, "Ha, bolo.") ?: "Ha, bolo."
        )
    }

    fun saveSettings(settings: DostSettings) {
        prefs.edit()
            .putBoolean(KEY_VOICE_ENABLED, settings.voiceResponsesEnabled)
            .putFloat(KEY_SPEECH_RATE, settings.speechRate)
            .putFloat(KEY_PITCH, settings.pitch)
            .putString(KEY_LANGUAGE, settings.language)
            .putString(KEY_SELECTED_VOICE_ID, settings.selectedVoiceId)
            .putString(KEY_SPEED_PRESET, settings.speedPreset)
            .putString(KEY_PITCH_PRESET, settings.pitchPreset)
            .putBoolean(KEY_DEBUG_MODE, settings.debugModeEnabled)
            .putString(KEY_THEME, settings.theme)
            .putString(KEY_SERVER_URL, settings.serverBaseUrl)
            .putBoolean(KEY_WAKE_LISTENING, settings.wakeListeningEnabled)
            .putBoolean(KEY_BACKGROUND_ASSISTANT, settings.backgroundAssistantEnabled)
            .putBoolean(KEY_FOLLOW_UP_ENABLED, settings.followUpModeEnabled)
            .putInt(KEY_FOLLOW_UP_DURATION, settings.followUpDurationSeconds)
            .putBoolean(KEY_WAKE_ACK_ENABLED, settings.wakeAcknowledgementEnabled)
            .putString(KEY_WAKE_ACK_PHRASE, settings.wakeAcknowledgementPhrase)
            .apply()
    }

    companion object {
        private const val KEY_VOICE_ENABLED = "voice_responses_enabled"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_PITCH = "pitch"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_SELECTED_VOICE_ID = "selected_voice_id"
        private const val KEY_SPEED_PRESET = "speed_preset"
        private const val KEY_PITCH_PRESET = "pitch_preset"
        private const val KEY_DEBUG_MODE = "debug_mode"
        private const val KEY_THEME = "theme"
        private const val KEY_SERVER_URL = "server_base_url"
        private const val KEY_WAKE_LISTENING = "wake_listening_enabled"
        private const val KEY_BACKGROUND_ASSISTANT = "background_assistant_enabled"
        private const val KEY_FOLLOW_UP_ENABLED = "follow_up_enabled"
        private const val KEY_FOLLOW_UP_DURATION = "follow_up_duration"
        private const val KEY_WAKE_ACK_ENABLED = "wake_ack_enabled"
        private const val KEY_WAKE_ACK_PHRASE = "wake_ack_phrase"
    }
}
