package com.dost.ai.apps

/**
 * Supported future interaction modes for UI interaction.
 * Defined as an architectural foundation for future phases.
 */
enum class AppInteractionMode {
    CLICK,
    SCROLL,
    TYPE_TEXT,
    READ_VISIBLE_UI,
    GO_BACK,
    GO_HOME
}

/**
 * AppInteractionController: Architecture foundation for future arbitrary app interactions.
 *
 * Adheres strictly to Section 19, 20, and 21:
 * - In DOST 2.0 Phase 2, this controller remains inactive/disabled.
 * - Does NOT attempt to bypass Android security or simulate hidden control.
 * - Requires explicit user enablement of Android AccessibilityService in future phases.
 * - Accurately reports capability status (App discovery, opening, Play Store & web search are active;
 *   arbitrary internal UI control is disabled).
 */
class AppInteractionController {

    /**
     * Whether arbitrary app UI automation is currently enabled.
     * Guaranteed false in Phase 2.
     */
    val isInteractionEnabled: Boolean = false

    /**
     * Clear and transparent status description explaining why internal app interaction is not active.
     */
    val statusDescription: String =
        "In DOST 2.0 Phase 2, app discovery, launching, Play Store search, and web search are fully active. Arbitrary internal app UI control (clicking, scrolling, typing) is disabled and will be safely integrated in a future phase with explicit user-enabled Android accessibility authorization."

    /**
     * Safe stub that returns an explicit failure explaining the capability boundary.
     */
    fun performAction(mode: AppInteractionMode): Result<Unit> {
        return Result.failure(
            UnsupportedOperationException(
                "UI Interaction ($mode) is not enabled in Phase 2. Android Accessibility Service authorization will be supported in a future phase."
            )
        )
    }

    /**
     * Returns whether the future accessibility service is configured on this device.
     */
    fun isAccessibilityConfigured(): Boolean = false
}
