package com.dost.ai.device

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Controller executing legitimate standard Android device and settings intents.
 *
 * Rule from specification:
 * "Do not hard-code manufacturer-specific packages when a standard Android intent is available."
 */
class DeviceController(private val context: Context) : BaseTool {
    override val name: String = "OPEN_SETTINGS"
    override val description: String = "Opens Android System Settings, Wi-Fi, Bluetooth, or Display."

    override fun validateParams(params: Map<String, Any?>): String? = null

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val target = (params["target"] as? String)?.lowercase() ?: "general"
        return when (target) {
            "wifi", "wi-fi" -> openSetting(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi Settings")
            "bluetooth" -> openSetting(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth Settings")
            "display" -> openSetting(Settings.ACTION_DISPLAY_SETTINGS, "Display Settings")
            "sound", "volume" -> openSetting(Settings.ACTION_SOUND_SETTINGS, "Sound Settings")
            "battery" -> openSetting(Settings.ACTION_BATTERY_SAVER_SETTINGS, "Battery Settings")
            else -> openSetting(Settings.ACTION_SETTINGS, "Settings")
        }
    }

    private fun openSetting(action: String, label: String): ToolResult {
        return try {
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ToolResult.success(name, "Opening $label.", mapOf("action" to action))
        } catch (e: Exception) {
            ToolResult.failure(name, "Unable to open $label: ${e.message}", e.message)
        }
    }
}
