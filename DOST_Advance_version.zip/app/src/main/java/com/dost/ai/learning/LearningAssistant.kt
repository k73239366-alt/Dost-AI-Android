package com.dost.ai.learning

import android.content.Context
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Learning and Study Assistant for DOST:
 *
 * Capabilities:
 * - Explain complex concepts simply (Feynman technique)
 * - Create step-by-step learning roadmaps
 * - Interactive quiz generation
 * - Math, Science, Coding, Exam preparation
 * - Tone: Supportive teacher / intelligent mentor in Hindi/Hinglish/English
 */
class LearningAssistant : BaseTool {
    override val name: String = "LEARNING_HELP"
    override val description: String = "Provides step-by-step explanations, study roadmaps, and quizzes."

    override fun validateParams(params: Map<String, Any?>): String? {
        val topic = params["topic"] as? String
        if (topic.isNullOrBlank()) return "Topic or question is required."
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val topic = (params["topic"] as? String) ?: ""
        val mode = (params["mode"] as? String) ?: "explain" // "explain", "roadmap", "quiz"

        return ToolResult.success(
            name,
            "Learning session started for topic: $topic ($mode)",
            mapOf("topic" to topic, "mode" to mode)
        )
    }
}

/**
 * Study Assistant helper structuring educational responses.
 */
class StudyAssistant {
    fun buildStudyPrompt(subject: String, level: String = "beginner"): String {
        return "You are DOST acting as an intelligent mentor. Break down the concept of '$subject' ($level level) into 3 easy intuitive steps. Use real-world analogies and clear, friendly Hindi/Hinglish."
    }
}
