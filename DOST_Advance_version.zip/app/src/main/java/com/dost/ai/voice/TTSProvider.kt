package com.dost.ai.voice

import java.util.Locale

/**
 * Metadata representation for an available TTS voice on the device or remote provider.
 */
data class TTSVoiceInfo(
    val id: String,
    val displayName: String,
    val locale: Locale,
    val quality: Int, // e.g. Voice.QUALITY_VERY_HIGH, QUALITY_HIGH, QUALITY_NORMAL
    val isNetworkRequired: Boolean,
    val isInstalled: Boolean,
    val latency: Int
)

/**
 * Playback tuning parameters passed to TTS engines.
 */
data class TTSPlaybackParams(
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val voiceId: String? = null,
    val languagePreference: String = "Auto"
)

/**
 * A normalized, sentence-sized speech chunk for smooth sequential audio rendering.
 */
data class SpeechChunk(
    val index: Int,
    val totalChunks: Int,
    val text: String,
    val language: DetectedLanguage
)

/**
 * Live debug telemetry for Voice Engine diagnostics.
 */
data class VoiceDebugState(
    val detectedLanguage: String = "None",
    val selectedTtsLocale: String = "None",
    val selectedVoiceName: String = "Auto",
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val ttsEngineName: String = "Android System TTS",
    val speechChunkCount: Int = 0,
    val currentChunkIndex: Int = 0,
    val ttsError: String? = null,
    val isHighQualityProvider: Boolean = false
)

/**
 * Abstraction for Text-To-Speech providers (device TTS or external neural cloud TTS).
 */
interface TTSProvider {
    val name: String
    val isReady: Boolean

    fun getAvailableVoices(): List<TTSVoiceInfo>

    fun isLanguageAvailable(locale: Locale): Boolean

    fun speak(
        chunks: List<SpeechChunk>,
        params: TTSPlaybackParams,
        onStart: (SpeechChunk) -> Unit = {},
        onChunkComplete: (SpeechChunk) -> Unit = {},
        onDone: () -> Unit = {},
        onError: (String) -> Unit = {}
    )

    fun stop()

    fun shutdown()
}

/**
 * Optional interface for high-fidelity neural cloud TTS services (e.g. Gemini Multimodal / Cloud TTS).
 * Architecture allows seamless swap without exposing API keys or hardcoding credentials.
 */
interface HighQualityTTSProvider : TTSProvider {
    val isConfigured: Boolean
}

/**
 * Selector that transparently routes audio synthesis to an active HighQualityTTSProvider
 * if configured and available, safely falling back to DeviceTTSProvider.
 */
class VoiceProviderSelector(
    private val deviceProvider: TTSProvider,
    private val cloudProvider: HighQualityTTSProvider? = null
) {
    fun getActiveProvider(): TTSProvider {
        return if (cloudProvider != null && cloudProvider.isConfigured && cloudProvider.isReady) {
            cloudProvider
        } else {
            deviceProvider
        }
    }
}
