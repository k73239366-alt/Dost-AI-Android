package com.dost.ai.apps

/**
 * Extensible alias registry for popular applications and common spoken terms in Hindi/Hinglish/English.
 *
 * Adheres to Section 14:
 * - Extensible alias mapping.
 * - Installed app catalog remains the primary source of truth.
 * - Easily accepts additions dynamically or statically.
 */
object AppAliases {

    // Maps aliases/nicknames (lowercase, trimmed) to candidate canonical app names
    private val ALIAS_MAP = mutableMapOf(
        "yt" to "youtube",
        "you tube" to "youtube",
        "whats app" to "whatsapp",
        "wa" to "whatsapp",
        "watsapp" to "whatsapp",
        "google chrome" to "chrome",
        "cam" to "camera",
        "kamera" to "camera" ,
        "phone settings" to "settings",
        "setting" to "settings",
        "system settings" to "settings",
        "insta" to "instagram",
        "ig" to "instagram",
        "fb" to "facebook",
        "face book" to "facebook",
        "gpay" to "google pay",
        "g pay" to "google pay",
        "paytm" to "paytm",
        "calc" to "calculator",
        "hisaab" to "calculator",
        "photos" to "gallery",
        "photo" to "gallery",
        "pics" to "gallery",
        "pictures" to "gallery",
        "tashveerein" to "gallery",
        "tasveer" to "gallery",
        "music" to "music",
        "songs" to "music",
        "gaane" to "music",
        "audio" to "music",
        "browser" to "chrome",
        "internet" to "chrome",
        "web browser" to "chrome",
        "gmail" to "gmail",
        "email" to "gmail",
        "mail" to "gmail",
        "clock" to "clock",
        "alarm" to "clock",
        "ghadi" to "clock",
        "maps" to "google maps",
        "map" to "maps",
        "rasta" to "maps"
    )

    /**
     * Resolves an alias to its target canonical name, or returns the original normalized name.
     */
    fun resolveAlias(inputName: String): String {
        val trimmed = inputName.trim().lowercase()
        return ALIAS_MAP[trimmed] ?: trimmed
    }

    /**
     * Retrieves all potential aliases or equivalent target search terms for a given app name.
     */
    fun getAliasesFor(inputName: String): List<String> {
        val normalized = inputName.trim().lowercase()
        val results = mutableSetOf(normalized)

        ALIAS_MAP[normalized]?.let { results.add(it) }

        // Reverse lookup: if inputName is a canonical target (e.g. "youtube"), include "yt"
        ALIAS_MAP.forEach { (alias, canonical) ->
            if (canonical == normalized) {
                results.add(alias)
            }
        }

        return results.toList()
    }

    /**
     * Allows dynamically registering an alias at runtime.
     */
    fun registerAlias(alias: String, canonicalName: String) {
        ALIAS_MAP[alias.trim().lowercase()] = canonicalName.trim().lowercase()
    }
}
