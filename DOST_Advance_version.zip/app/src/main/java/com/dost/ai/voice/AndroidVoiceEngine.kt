package com.dost.ai.voice

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * AndroidVoiceEngine: Main implementation of VoiceEngine coordinating language detection,
 * text preprocessing, voice selection, chunk sequencing, and playback monitoring.
 */
class AndroidVoiceEngine(
    context: Context,
    private val onStateChange: (Boolean) -> Unit = {}
) : VoiceEngine {

    private val deviceProvider = DeviceTTSProvider(context) { ready ->
        if (ready) {
            updateDebugTelemetry(
                ttsEngine = deviceProvider.getEngineName(),
                selectedVoice = deviceProvider.getCurrentVoiceSelection()?.displayName ?: "Auto"
            )
        }
    }

    private val providerSelector = VoiceProviderSelector(deviceProvider)

    private var _isSpeaking = false
    override val isSpeaking: Boolean
        get() = _isSpeaking

    private val _voiceDebugState = MutableStateFlow(VoiceDebugState())
    override val voiceDebugState: StateFlow<VoiceDebugState> = _voiceDebugState.asStateFlow()

    private var currentConfiguredPitch = 1.0f
    private var currentConfiguredRate = 1.0f
    private var currentConfiguredVoiceId: String? = null

    override fun speak(
        text: String,
        speechRate: Float,
        pitch: Float,
        language: String,
        onDone: () -> Unit,
        onComplete: () -> Unit
    ) {
        val completionHandler = {
            _isSpeaking = false
            onStateChange(false)
            onDone()
            if (onComplete !== onDone) {
                onComplete()
            }
        }

        if (text.isBlank()) {
            completionHandler()
            return
        }

        // 1. Interrupt any current playback immediately
        stop()

        // 2. Detect language: Hindi, Hinglish, or English
        val detectedLanguage = LanguageDetector.detect(text, language)

        // 3. Preprocess text and generate sentence-sized chunks for natural delivery
        val chunks = SpeechTextPreprocessor.splitIntoChunks(text, detectedLanguage)

        if (chunks.isEmpty()) {
            completionHandler()
            return
        }

        _isSpeaking = true
        onStateChange(true)

        val activeProvider = providerSelector.getActiveProvider()

        val params = TTSPlaybackParams(
            speechRate = if (speechRate > 0f) speechRate else currentConfiguredRate,
            pitch = if (pitch > 0f) pitch else currentConfiguredPitch,
            voiceId = currentConfiguredVoiceId,
            languagePreference = language
        )

        // Update telemetry
        val selection = if (deviceProvider.isReady) {
            VoiceSelector.selectVoice(detectedLanguage, null, params.voiceId)
        } else null

        _voiceDebugState.update {
            it.copy(
                detectedLanguage = detectedLanguage.name,
                selectedTtsLocale = selection?.fallbackLocale?.toString() ?: if (detectedLanguage == DetectedLanguage.ENGLISH) "en_IN" else "hi_IN",
                selectedVoiceName = selection?.displayName ?: "Auto Hindi/English",
                speechRate = params.speechRate,
                pitch = params.pitch,
                ttsEngineName = activeProvider.name,
                speechChunkCount = chunks.size,
                currentChunkIndex = 0,
                ttsError = selection?.warningMessage,
                isHighQualityProvider = activeProvider is HighQualityTTSProvider
            )
        }

        activeProvider.speak(
            chunks = chunks,
            params = params,
            onStart = { chunk ->
                _isSpeaking = true
                onStateChange(true)
                _voiceDebugState.update { it.copy(currentChunkIndex = chunk.index + 1) }
            },
            onChunkComplete = { chunk ->
                _voiceDebugState.update { it.copy(currentChunkIndex = chunk.index + 1) }
            },
            onDone = {
                completionHandler()
            },
            onError = { error ->
                Log.w("DOST_VOICE", "VoiceEngine playback error: $error")
                _voiceDebugState.update { it.copy(ttsError = error) }
                completionHandler()
            }
        )
    }

    override fun stop() {
        try {
            providerSelector.getActiveProvider().stop()
        } catch (e: Exception) {
            Log.w("DOST_VOICE", "Error during stop: ${e.message}")
        } finally {
            _isSpeaking = false
            onStateChange(false)
        }
    }

    override fun shutdown() {
        stop()
        providerSelector.getActiveProvider().shutdown()
    }

    override fun setPitch(pitch: Float) {
        currentConfiguredPitch = pitch.coerceIn(0.5f, 2.0f)
        _voiceDebugState.update { it.copy(pitch = currentConfiguredPitch) }
    }

    override fun setSpeechRate(rate: Float) {
        currentConfiguredRate = rate.coerceIn(0.5f, 2.0f)
        _voiceDebugState.update { it.copy(speechRate = currentConfiguredRate) }
    }

    override fun setVoice(voiceId: String?) {
        currentConfiguredVoiceId = voiceId
        _voiceDebugState.update { it.copy(selectedVoiceName = voiceId ?: "Auto") }
    }

    override fun getAvailableVoices(): List<TTSVoiceInfo> {
        return providerSelector.getActiveProvider().getAvailableVoices()
    }

    override fun isHindiVoiceAvailable(): Boolean {
        return providerSelector.getActiveProvider().isLanguageAvailable(VoiceSelector.LOCALE_HINDI_INDIA)
    }

    private fun updateDebugTelemetry(ttsEngine: String, selectedVoice: String) {
        _voiceDebugState.update {
            it.copy(
                ttsEngineName = ttsEngine,
                selectedVoiceName = selectedVoice
            )
        }
    }
}
