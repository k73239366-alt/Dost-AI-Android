package com.dost.ai.wake

/**
 * Factory for instantiating WakeWordEngine instances.
 */
object WakeWordEngineFactory {

    enum class EngineType {
        SYSTEM_SPEECH,
        LOCAL_KEYWORD_MODEL
    }

    fun createEngine(
        type: EngineType = EngineType.SYSTEM_SPEECH,
        providerKey: String? = null
    ): WakeWordEngine {
        return when (type) {
            EngineType.SYSTEM_SPEECH -> SystemSpeechWakeWordEngine()
            EngineType.LOCAL_KEYWORD_MODEL -> KeywordDetectionWakeWordEngine(accessKey = providerKey)
        }
    }

    fun getSupportedEngineTypes(): List<EngineInfo> {
        return listOf(
            EngineInfo(
                type = EngineType.SYSTEM_SPEECH,
                displayName = "System Speech Wake Engine",
                description = "Uses Android native SpeechRecognizer for keyword listening. Standard, no external keys required.",
                status = WakeEngineStatus.IMPLEMENTED
            ),
            EngineInfo(
                type = EngineType.LOCAL_KEYWORD_MODEL,
                displayName = "Low-Power On-Device DSP (Porcupine / TFLite)",
                description = "Dedicated acoustic model for offline wake detection. Requires optional provider SDK key.",
                status = WakeEngineStatus.REQUIRES_OPTIONAL_PROVIDER
            )
        )
    }

    data class EngineInfo(
        val type: EngineType,
        val displayName: String,
        val description: String,
        val status: WakeEngineStatus
    )
}
