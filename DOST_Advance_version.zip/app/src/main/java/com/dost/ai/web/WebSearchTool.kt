package com.dost.ai.web

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult
import java.net.URLEncoder

/**
 * Legitimate web search tool using Android WEB_SEARCH intent or browser URL.
 */
class WebSearchTool : BaseTool {
    override val name: String = "SEARCH_WEB"
    override val description: String = "Searches the web for up-to-date information via the device browser."

    override fun validateParams(params: Map<String, Any?>): String? {
        val query = params["query"] as? String
        if (query.isNullOrBlank()) return "Search query cannot be empty."
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val query = (params["query"] as? String)?.trim() ?: ""
        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                ToolResult.success(name, "\"$query\" ke liye web search open kar diya gaya hai.", mapOf("query" to query))
            } else {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(browserIntent)
                ToolResult.success(name, "\"$query\" ke liye Google search open kar diya gaya hai.", mapOf("query" to query))
            }
        } catch (e: Exception) {
            ToolResult.failure(name, "Web search open nahi ho saka: ${e.message}", e.message)
        }
    }
}

/**
 * Utility for opening verified URLs in default Android browser.
 */
class BrowserLauncher {
    fun openUrl(context: Context, url: String): Boolean {
        return try {
            val validUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
                "https://$url"
            } else {
                url
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
