package com.dost.ai

import android.app.Application
import android.util.Log

class DostApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "DOST Application initialized successfully.")
    }

    companion object {
        const val TAG = "DOST"
    }
}
