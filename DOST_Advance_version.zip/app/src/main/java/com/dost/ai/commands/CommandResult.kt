package com.dost.ai.commands

import com.dost.ai.apps.InstalledApp

/**
 * Possible execution statuses for device and app commands.
 * Adheres strictly to Section 18.
 */
enum class CommandStatus {
    SUCCESS,
    FAILED,
    NOT_FOUND,
    AMBIGUOUS,
    UNSUPPORTED,
    CANCELLED,
    PERMISSION_REQUIRED,
    CONFIRMATION_REQUIRED
}

/**
 * Represents the factual result of executing a command in DOST.
 *
 * Never hallucinates success. The UI and speech responses are strictly derived from this result.
 */
data class CommandResult(
    val status: CommandStatus,
    val message: String,
    val targetApp: String? = null,
    val launchedPackage: String? = null,
    val launchedAppName: String? = null,
    val ambiguousCandidates: List<InstalledApp> = emptyList(),
    val fallbackQuery: String? = null,
    val error: String? = null
)
