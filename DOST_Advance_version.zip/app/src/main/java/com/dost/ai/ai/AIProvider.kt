package com.dost.ai.ai

import com.dost.ai.data.model.ChatMessage
import kotlinx.coroutines.flow.Flow

/**
 * Clean AI Provider interface supporting pluggable backends.
 * Decoupled from specific vendor SDKs to support future model provider replacements.
 */
interface AIProvider {

    /**
     * Sends the user's message along with current session history for contextual memory.
     */
    suspend fun sendMessage(
        userMessage: String,
        sessionHistory: List<ChatMessage>,
        languageStyle: String = "Auto"
    ): Result<String>

    /**
     * Optional streaming response abstraction where supported by the backend provider.
     */
    fun streamResponse(
        userMessage: String,
        sessionHistory: List<ChatMessage>,
        languageStyle: String = "Auto"
    ): Flow<String>? = null

    /**
     * Cancels any active in-flight request.
     */
    suspend fun cancelResponse()
}
