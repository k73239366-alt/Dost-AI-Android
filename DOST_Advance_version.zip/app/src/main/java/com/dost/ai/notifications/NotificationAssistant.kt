package com.dost.ai.notifications

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Notification Assistant for DOST:
 *
 * Requirements:
 * - Read/summarize notifications where authorized
 * - Filter spam / prioritize important messages
 * - Privacy: Explicit notification listener permission required
 * - User selects authorized apps
 * - No secret reading
 */
class NotificationAssistant(private val context: Context) : BaseTool {
    override val name: String = "SUMMARIZE_NOTIFICATIONS"
    override val description: String = "Summarizes authorized notifications cleanly."

    override fun validateParams(params: Map<String, Any?>): String? = null

    fun isNotificationAccessGranted(): Boolean {
        val packageName = context.packageName
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(packageName)
    }

    fun getNotificationAccessIntent(): Intent {
        return Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        if (!isNotificationAccessGranted()) {
            return ToolResult.permissionRequired(
                name,
                "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE",
                "Notifications ko summarize karne ke liye DOST ko Notification Access ki permission chahiye."
            )
        }

        return ToolResult.success(
            name,
            "Koi naya unread notification nahi hai.",
            mapOf("summary" to "No new unread notifications.")
        )
    }
}
