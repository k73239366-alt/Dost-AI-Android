package com.dost.ai.camera

import android.Manifest
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Camera Assistant Manager:
 *
 * Requirements:
 * - Open camera with legitimate intent
 * - Photo capture for analysis
 * - Request CAMERA permission properly
 * - Never record silently
 * - User controls when image is captured
 */
class CameraAssistantManager : BaseTool {
    override val name: String = "OPEN_CAMERA"
    override val description: String = "Opens camera to capture photos for visual assistance and object understanding."
    override val requiredPermission: String = Manifest.permission.CAMERA

    override fun validateParams(params: Map<String, Any?>): String? = null

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        return try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                ToolResult.success(
                    name,
                    "Camera open kar diya gaya hai. Photo click karne ke baad DOST use analyze karega.",
                    mapOf("action" to MediaStore.ACTION_IMAGE_CAPTURE)
                )
            } else {
                val fallbackIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_CAMERA)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
                ToolResult.success(name, "Camera open kar diya gaya hai.")
            }
        } catch (e: Exception) {
            ToolResult.failure(name, "Camera open karne me samasya aayi: ${e.message}", e.message)
        }
    }
}

/**
 * Vision Analyzer for interpreting captured photos (homework, text, error screens, circuit boards).
 */
class VisionAnalyzer {
    data class VisionAnalysisResult(
        val detectedText: String?,
        val explanation: String,
        val suggestedNextSteps: List<String> = emptyList()
    )

    fun createVisionPrompt(userGoal: String?): String {
        return when {
            userGoal?.contains("homework", ignoreCase = true) == true ->
                "Analyze this homework question step by step. Explain the core concepts clearly in Hinglish/Hindi."
            userGoal?.contains("error", ignoreCase = true) == true ->
                "Analyze this error message or dialog. Identify the root cause and provide clear troubleshooting steps."
            userGoal?.contains("circuit", ignoreCase = true) == true || userGoal?.contains("hardware", ignoreCase = true) == true ->
                "Identify the electronic components visible in this image and explain their function."
            else ->
                "Explain the primary contents of this image clearly, highlighting readable text, objects, and relevant details."
        }
    }
}
