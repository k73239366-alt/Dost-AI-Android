package com.dost.ai.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dost.ai.ai.AIProvider
import com.dost.ai.ai.RemoteAIProvider
import com.dost.ai.apps.AppInteractionController
import com.dost.ai.apps.AppLauncher
import com.dost.ai.apps.AppMatchResult
import com.dost.ai.apps.AppMatcher
import com.dost.ai.apps.InstalledApp
import com.dost.ai.apps.InstalledAppRepository
import com.dost.ai.apps.StoreSearchLauncher
import com.dost.ai.apps.WebSearchLauncher
import com.dost.ai.background.BackgroundAssistantManager
import com.dost.ai.background.BackgroundCapabilityChecker
import com.dost.ai.commands.CommandAnalysis
import com.dost.ai.commands.CommandIntent
import com.dost.ai.commands.CommandNormalizer
import com.dost.ai.commands.CommandResult
import com.dost.ai.commands.CommandStatus
import com.dost.ai.commands.IntentRouter
import com.dost.ai.core.AssistantStateManager
import com.dost.ai.data.model.AssistantState
import com.dost.ai.data.model.ChatMessage
import com.dost.ai.data.model.MessageSender
import com.dost.ai.settings.DostSettings
import com.dost.ai.settings.SettingsRepository
import com.dost.ai.speech.FollowUpManager
import com.dost.ai.speech.SpeechRecognizerManager
import com.dost.ai.voice.AndroidVoiceEngine
import com.dost.ai.voice.VoiceEngine
import com.dost.ai.voice.VoiceSessionManager
import com.dost.ai.wake.WakeWordEngine
import com.dost.ai.wake.WakeWordEngineFactory
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Enhanced DebugInfo structure tracking complete Speech Recognition, AI lifecycle,
 * and App Discovery / Launch execution.
 */
data class DebugInfo(
    val recognizedSpeech: String = "",
    val partialText: String = "",
    val finalText: String = "",
    val selectedCandidate: String = "",
    val recognitionEvent: String = "Idle",
    val recognitionState: String = "IDLE",
    val recognitionError: String? = null,
    val normalizedInput: String = "",
    val detectedIntent: String = "None",
    val assistantState: String = "IDLE",
    val aiRequestStatus: String = "Idle",
    val lastError: String? = null,
    // Voice & TTS Debug Telemetry (Section 16)
    val detectedLanguage: String = "None",
    val selectedTtsLocale: String = "None",
    val selectedVoiceName: String = "Auto",
    val ttsSpeechRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val ttsEngineName: String = "Android System TTS",
    val speechChunkCount: Int = 0,
    val ttsError: String? = null,
    // Phase 2 App Discovery & Launch Telemetry
    val discoveredAppCount: Int = 0,
    val lastMatchedApp: String? = null,
    val lastCommandStatus: String = "None"
)

data class MainUiState(
    val assistantState: AssistantState = AssistantState.IDLE,
    val statusMessage: String? = null,
    val messages: List<ChatMessage> = emptyList(),
    val settings: DostSettings = DostSettings(),
    val currentSpeechTranscript: String = "",
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isThinking: Boolean = false,
    val errorMessage: String? = null,
    val debugInfo: DebugInfo = DebugInfo(),
    val isSettingsOpen: Boolean = false,
    val canRetryLast: Boolean = false,
    val lastSearchFallbackQuery: String? = null,
    // Phase 2: Wake & Background Architecture
    val isWakeListening: Boolean = false,
    val isBackgroundAssistantActive: Boolean = false,
    val isFollowUpActive: Boolean = false,
    val followUpSecondsRemaining: Int = 0,
    val capabilityReport: BackgroundCapabilityChecker.DeviceCapabilityReport? = null
)

class MainViewModel(
    application: Application,
    private val settingsRepository: SettingsRepository = SettingsRepository(application),
    private val speechRecognizerManager: SpeechRecognizerManager = SpeechRecognizerManager(application),
    private val voiceEngine: VoiceEngine = AndroidVoiceEngine(application),
    private val aiProvider: AIProvider = RemoteAIProvider {
        SettingsRepository(application).getSettings().serverBaseUrl
    },
    private val installedAppRepository: InstalledAppRepository = InstalledAppRepository(application),
    private val appLauncher: AppLauncher = AppLauncher(application),
    private val storeSearchLauncher: StoreSearchLauncher = StoreSearchLauncher(application),
    private val webSearchLauncher: WebSearchLauncher = WebSearchLauncher(application),
    val appInteractionController: AppInteractionController = AppInteractionController()
) : AndroidViewModel(application) {

    val toolRegistry: com.dost.ai.tools.ToolRegistry = com.dost.ai.tools.ToolRegistry().apply {
        register(com.dost.ai.camera.CameraAssistantManager())
        register(com.dost.ai.device.DeviceController(application))
        register(com.dost.ai.device.TimerTool())
        register(com.dost.ai.device.AlarmTool())
        register(com.dost.ai.reminders.ReminderTool(application))
        register(com.dost.ai.device.NotesTool(application))
        register(com.dost.ai.web.WebSearchTool())
        val contactRepo = com.dost.ai.contacts.ContactRepository(application)
        val contactResolver = com.dost.ai.contacts.ContactResolver(contactRepo)
        register(com.dost.ai.contacts.CallTool(contactResolver))
        register(com.dost.ai.contacts.MessagingTool(contactResolver))
        register(com.dost.ai.screen.ScreenUnderstandingManager(application))
        register(com.dost.ai.coding.CodingAssistantTool())
        register(com.dost.ai.projects.ProjectGenerator())
        register(com.dost.ai.projects.WebProjectGenerator())
        register(com.dost.ai.learning.LearningAssistant())
        register(com.dost.ai.memory.MemoryManager(application))
    }
    val toolExecutor: com.dost.ai.tools.ToolExecutor = com.dost.ai.tools.ToolExecutor(toolRegistry)

    val voiceSessionManager: VoiceSessionManager = VoiceSessionManager(application)
    val capabilityChecker: BackgroundCapabilityChecker = BackgroundCapabilityChecker(application)
    val backgroundAssistantManager: BackgroundAssistantManager = BackgroundAssistantManager(application, capabilityChecker)
    val followUpManager: FollowUpManager = FollowUpManager()
    val assistantStateManager: AssistantStateManager = AssistantStateManager()
    val wakeWordEngine: WakeWordEngine = WakeWordEngineFactory.createEngine()

    private val _uiState = MutableStateFlow(
        MainUiState(
            settings = settingsRepository.getSettings(),
            messages = listOf(
                ChatMessage(
                    sender = MessageSender.DOST,
                    text = "Namaste. Main DOST hoon — aapka personal AI assistant aur dost. Kahiye, aaj main aapki kya madad kar sakta hoon?"
                )
            )
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var activeAiJob: Job? = null
    private var activeCommandJob: Job? = null
    private var lastUserMessage: String? = null
    private var retryCount = 0
    private val MAX_AUTO_RETRIES = 2

    // Duplicate submission protection
    private var lastSubmittedSpeech: String? = null
    private var lastSubmittedTimestamp: Long = 0L

    init {
        observeSpeechRecognition()
        observeVoiceEngineTelemetry()
        observeFollowUpManager()
        // Pre-warm the installed app cache on background dispatcher
        preloadInstalledApps()
        refreshCapabilityReport()
        if (_uiState.value.settings.wakeListeningEnabled) {
            startWakeListening()
        }
        if (_uiState.value.settings.backgroundAssistantEnabled) {
            backgroundAssistantManager.startBackgroundAssistant(enableWakeListening = _uiState.value.settings.wakeListeningEnabled)
        }
    }

    private fun preloadInstalledApps() {
        viewModelScope.launch {
            try {
                val apps = installedAppRepository.getInstalledApps()
                _uiState.update { state ->
                    state.copy(
                        debugInfo = state.debugInfo.copy(discoveredAppCount = apps.size)
                    )
                }
                Log.d("DOST", "Pre-warmed installed app cache with ${apps.size} applications.")
            } catch (e: Exception) {
                Log.e("DOST", "Failed to preload installed apps: ${e.message}")
            }
        }
    }

    private fun observeVoiceEngineTelemetry() {
        viewModelScope.launch {
            voiceEngine.voiceDebugState.collect { voiceDebug ->
                _uiState.update { state ->
                    state.copy(
                        debugInfo = state.debugInfo.copy(
                            detectedLanguage = voiceDebug.detectedLanguage,
                            selectedTtsLocale = voiceDebug.selectedTtsLocale,
                            selectedVoiceName = voiceDebug.selectedVoiceName,
                            ttsSpeechRate = voiceDebug.speechRate,
                            ttsPitch = voiceDebug.pitch,
                            ttsEngineName = voiceDebug.ttsEngineName,
                            speechChunkCount = voiceDebug.speechChunkCount,
                            ttsError = voiceDebug.ttsError
                        )
                    )
                }
            }
        }
    }

    private fun observeSpeechRecognition() {
        // 1. FINAL RESULTS LISTENER:
        // Strictly processes the completed utterance. Partial results NEVER invoke this.
        speechRecognizerManager.onFinalResultListener = { finalText ->
            viewModelScope.launch {
                handleSpeechRecognitionFinalResult(finalText)
            }
        }

        // 2. PARTIAL RESULTS LISTENER:
        // For live UI preview only. NEVER triggers command routing or app launching.
        speechRecognizerManager.onPartialResultListener = { partialText ->
            _uiState.update { state ->
                state.copy(
                    currentSpeechTranscript = partialText,
                    debugInfo = state.debugInfo.copy(
                        partialText = partialText,
                        recognitionEvent = "Partial: $partialText",
                        recognitionState = "LISTENING"
                    )
                )
            }
        }

        // 3. Listening State Flow
        viewModelScope.launch {
            speechRecognizerManager.isListening.collect { listening ->
                _uiState.update { state ->
                    val nextAssistantState = if (listening) {
                        AssistantState.LISTENING
                    } else if (state.assistantState == AssistantState.LISTENING) {
                        if (state.isThinking) AssistantState.THINKING else AssistantState.IDLE
                    } else {
                        state.assistantState
                    }

                    state.copy(
                        isListening = listening,
                        assistantState = nextAssistantState
                    )
                }
            }
        }

        // 4. Debug State & Event Flows
        viewModelScope.launch {
            speechRecognizerManager.recognitionEvent.collect { event ->
                _uiState.update { state ->
                    state.copy(debugInfo = state.debugInfo.copy(recognitionEvent = event))
                }
            }
        }

        viewModelScope.launch {
            speechRecognizerManager.recognitionState.collect { recState ->
                _uiState.update { state ->
                    state.copy(debugInfo = state.debugInfo.copy(recognitionState = recState))
                }
            }
        }

        viewModelScope.launch {
            speechRecognizerManager.selectedCandidate.collect { candidate ->
                if (candidate.isNotBlank()) {
                    _uiState.update { state ->
                        state.copy(debugInfo = state.debugInfo.copy(selectedCandidate = candidate))
                    }
                }
            }
        }

        // 5. Error Flow
        viewModelScope.launch {
            speechRecognizerManager.error.collect { err ->
                if (err != null) {
                    _uiState.update { state ->
                        state.copy(
                            assistantState = AssistantState.ERROR,
                            errorMessage = err,
                            debugInfo = state.debugInfo.copy(
                                recognitionError = err,
                                lastError = err,
                                recognitionState = "ERROR"
                            )
                        )
                    }
                }
            }
        }
    }

    private fun handleSpeechRecognitionFinalResult(finalText: String) {
        val trimmed = finalText.trim()
        if (trimmed.isBlank()) {
            if (_uiState.value.settings.wakeListeningEnabled) {
                startWakeListening()
            } else {
                _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
            }
            return
        }

        // Check if in Follow-up Mode and user gave a cancellation phrase
        if (_uiState.value.isFollowUpActive) {
            if (followUpManager.isCancelCommand(trimmed)) {
                followUpManager.cancelFollowUp()
                speechRecognizerManager.cancelListening()
                voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.FOLLOW_UP_RECOGNIZER)
                _uiState.update {
                    it.copy(
                        isFollowUpActive = false,
                        followUpSecondsRemaining = 0,
                        statusMessage = null
                    )
                }
                if (_uiState.value.settings.wakeListeningEnabled) {
                    startWakeListening()
                } else {
                    assistantStateManager.transitionTo(AssistantState.IDLE)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                }
                return
            }
            // Valid follow-up command detected! Cancel timer and proceed
            followUpManager.cancelFollowUp()
            _uiState.update { it.copy(isFollowUpActive = false, followUpSecondsRemaining = 0) }
        }

        val now = System.currentTimeMillis()
        if (trimmed == lastSubmittedSpeech && (now - lastSubmittedTimestamp) < 2000L) {
            Log.w("DOST", "Prevented duplicate submission of speech: \"$trimmed\"")
            return
        }

        lastSubmittedSpeech = trimmed
        lastSubmittedTimestamp = now

        _uiState.update { state ->
            state.copy(
                currentSpeechTranscript = trimmed,
                debugInfo = state.debugInfo.copy(
                    finalText = trimmed,
                    recognizedSpeech = trimmed,
                    selectedCandidate = trimmed,
                    recognitionState = "COMPLETED"
                )
            )
        }

        sendMessage(trimmed)
    }

    fun startListening() {
        stopSpeaking()
        wakeWordEngine.pause()
        voiceSessionManager.requestMicOwnership(VoiceSessionManager.MicOwner.COMMAND_RECOGNIZER)
        _uiState.update {
            it.copy(
                assistantState = AssistantState.LISTENING,
                errorMessage = null,
                currentSpeechTranscript = "",
                statusMessage = null,
                debugInfo = it.debugInfo.copy(
                    partialText = "",
                    finalText = "",
                    recognitionError = null,
                    recognitionState = "LISTENING"
                )
            )
        }
        speechRecognizerManager.startListening(_uiState.value.settings.language)
    }

    fun stopListeningAndSend() {
        _uiState.update {
            it.copy(
                assistantState = AssistantState.THINKING,
                debugInfo = it.debugInfo.copy(recognitionState = "PROCESSING")
            )
        }
        speechRecognizerManager.stopListening()
    }

    fun cancelListening() {
        speechRecognizerManager.cancelListening()
        voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.COMMAND_RECOGNIZER)
        voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.FOLLOW_UP_RECOGNIZER)
        followUpManager.cancelFollowUp()
        _uiState.update {
            it.copy(
                assistantState = if (it.settings.wakeListeningEnabled) AssistantState.WAKE_LISTENING else AssistantState.IDLE,
                currentSpeechTranscript = "",
                isFollowUpActive = false,
                followUpSecondsRemaining = 0,
                statusMessage = null,
                debugInfo = it.debugInfo.copy(
                    recognitionState = "CANCELLED",
                    recognitionEvent = "Cancelled by user"
                )
            )
        }
        if (_uiState.value.settings.wakeListeningEnabled) {
            startWakeListening()
        }
    }

    fun stopSpeaking() {
        voiceEngine.stop()
        _uiState.update {
            it.copy(
                isSpeaking = false,
                assistantState = if (it.assistantState == AssistantState.SPEAKING) AssistantState.IDLE else it.assistantState
            )
        }
    }

    fun toggleDebugMode() {
        val current = _uiState.value.settings.debugModeEnabled
        val newSettings = _uiState.value.settings.copy(debugModeEnabled = !current)
        updateSettings(newSettings)
    }

    /**
     * Primary message entry point according to DOST Phase 2 architecture:
     * INPUT -> TEXT NORMALIZATION -> WAKE PHRASE REMOVAL -> COMMAND DETECTION (Priority order)
     *   1. OPEN_CAMERA -> Launch Camera
     *   2. OPEN_APP -> Discover & Launch App
     *   3. SEARCH_PLAY_STORE -> Play Store Search
     *   4. SEARCH_WEB -> Web Search
     *   5. Unsupported device actions -> Explanatory message
     *   6. NORMAL_CONVERSATION -> AI Conversation
     */
    fun sendMessage(rawText: String) {
        if (rawText.isBlank()) return

        stopSpeaking()
        activeAiJob?.cancel()
        activeCommandJob?.cancel()

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = rawText.trim()
        )

        lastUserMessage = rawText.trim()
        retryCount = 0

        val normalized = CommandNormalizer.normalize(rawText)
        val analysis: CommandAnalysis = IntentRouter.route(rawText)

        _uiState.update { state ->
            state.copy(
                messages = state.messages + userMessage,
                currentSpeechTranscript = "",
                errorMessage = null,
                canRetryLast = false,
                statusMessage = null,
                debugInfo = state.debugInfo.copy(
                    recognizedSpeech = rawText,
                    normalizedInput = normalized,
                    detectedIntent = analysis.intent.name,
                    assistantState = "THINKING",
                    aiRequestStatus = if (analysis.intent == CommandIntent.NORMAL_CONVERSATION) "Requesting AI..." else "Processing Command...",
                    lastError = null
                )
            )
        }

        when (analysis.intent) {
            CommandIntent.STOP -> {
                handleStopCommand()
            }
            CommandIntent.OPEN_CAMERA -> {
                handleCameraLaunch()
            }
            CommandIntent.OPEN_SETTINGS -> {
                executeRegisteredTool("OPEN_SETTINGS", analysis.parameters, "Settings open nahi ho saka.")
            }
            CommandIntent.SET_TIMER -> {
                executeRegisteredTool("SET_TIMER", analysis.parameters, "Timer set nahi ho saka.")
            }
            CommandIntent.CREATE_ALARM -> {
                executeRegisteredTool("CREATE_ALARM", analysis.parameters, "Alarm set nahi ho saka.")
            }
            CommandIntent.CREATE_REMINDER -> {
                executeRegisteredTool("CREATE_REMINDER", analysis.parameters, "Reminder schedule nahi ho saka.")
            }
            CommandIntent.CREATE_NOTE -> {
                executeRegisteredTool("CREATE_NOTE", analysis.parameters, "Note save nahi ho saka.")
            }
            CommandIntent.CALL_CONTACT -> {
                executeRegisteredTool("CALL_CONTACT", analysis.parameters, "Contact call initiate nahi ho saka.")
            }
            CommandIntent.SEND_MESSAGE -> {
                executeRegisteredTool("SEND_MESSAGE", analysis.parameters, "Message composer open nahi ho saka.")
            }
            CommandIntent.SCREEN_ANALYSIS -> {
                executeRegisteredTool("SCREEN_ANALYSIS", analysis.parameters, "Screen analysis initiate nahi ho saka.")
            }
            CommandIntent.MANAGE_MEMORY -> {
                executeRegisteredTool("MANAGE_MEMORY", analysis.parameters, "Memory update nahi ho saki.")
            }
            CommandIntent.OPEN_APP -> {
                handleOpenApp(analysis)
            }
            CommandIntent.SEARCH_PLAY_STORE -> {
                handleSearchPlayStore(analysis)
            }
            CommandIntent.SEARCH_WEB -> {
                handleSearchWeb(analysis)
            }
            CommandIntent.CODING_HELP,
            CommandIntent.GENERATE_PROJECT,
            CommandIntent.LEARNING_HELP,
            CommandIntent.NORMAL_CONVERSATION -> {
                dispatchToAi(rawText)
            }
        }
    }

    private fun handleStopCommand() {
        activeAiJob?.cancel()
        activeCommandJob?.cancel()
        stopSpeaking()
        speechRecognizerManager.stopListening()
        _uiState.update { state ->
            state.copy(
                assistantState = AssistantState.IDLE,
                isListening = false,
                isSpeaking = false,
                isThinking = false,
                statusMessage = null,
                messages = state.messages + ChatMessage(
                    sender = MessageSender.DOST,
                    text = "Theek hai, maine rok diya hai."
                )
            )
        }
    }

    private fun executeRegisteredTool(toolName: String, params: Map<String, Any?>, fallbackMessage: String = "") {
        activeCommandJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.PROCESSING,
                    isThinking = true,
                    statusMessage = "Executing $toolName..."
                )
            }

            val result = toolExecutor.executeTool(getApplication(), toolName, params)

            if (result.status == CommandStatus.SUCCESS) {
                _uiState.update { state ->
                    state.copy(
                        assistantState = AssistantState.SUCCESS,
                        isThinking = false,
                        statusMessage = null,
                        messages = state.messages + ChatMessage(
                            sender = MessageSender.DOST,
                            text = result.userFacingMessage
                        )
                    )
                }
                speakText(result.userFacingMessage)
            } else {
                val errorMsg = result.userFacingMessage.ifBlank { fallbackMessage }
                _uiState.update { state ->
                    state.copy(
                        assistantState = AssistantState.IDLE,
                        isThinking = false,
                        statusMessage = null,
                        messages = state.messages + ChatMessage(
                            sender = MessageSender.DOST,
                            text = errorMsg,
                            isError = true
                        )
                    )
                }
                speakText(errorMsg)
            }
        }
    }

    /**
     * Section 8, 9, 10, 22: App Discovery and Launch Pipeline
     */
    private fun handleOpenApp(analysis: CommandAnalysis) {
        val targetName = analysis.targetAppName ?: analysis.normalizedAppName ?: "App"

        activeCommandJob = viewModelScope.launch {
            // DOST Eye state: THINKING -> Finding status text
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.THINKING,
                    isThinking = true,
                    statusMessage = "Finding $targetName...",
                    debugInfo = state.debugInfo.copy(
                        assistantState = "THINKING",
                        aiRequestStatus = "Querying installed catalog..."
                    )
                )
            }

            val installedApps = installedAppRepository.getInstalledApps()
            _uiState.update { state ->
                state.copy(
                    debugInfo = state.debugInfo.copy(discoveredAppCount = installedApps.size)
                )
            }

            val matchResult = AppMatcher.match(targetName, installedApps)

            when (matchResult) {
                is AppMatchResult.Definite -> {
                    val app = matchResult.app
                    _uiState.update { state ->
                        state.copy(
                            assistantState = AssistantState.PROCESSING,
                            statusMessage = "Opening ${app.appLabel}...",
                            debugInfo = state.debugInfo.copy(
                                assistantState = "PROCESSING",
                                lastMatchedApp = "${app.appLabel} (${app.packageName}) [${matchResult.matchType}]",
                                lastCommandStatus = "LAUNCHING"
                            )
                        )
                    }

                    // Direct launch (Section 9: No unnecessary confirmation dialog)
                    val result = appLauncher.launchApp(app)

                    if (result.status == CommandStatus.SUCCESS) {
                        val responseMessage = ChatMessage(
                            sender = MessageSender.DOST,
                            text = "Opening ${app.appLabel}."
                        )
                        _uiState.update { state ->
                            state.copy(
                                messages = state.messages + responseMessage,
                                assistantState = AssistantState.SUCCESS,
                                isThinking = false,
                                statusMessage = "Opened ${app.appLabel}",
                                debugInfo = state.debugInfo.copy(
                                    assistantState = "SUCCESS",
                                    lastCommandStatus = "SUCCESS",
                                    aiRequestStatus = "Launched ${app.appLabel}"
                                )
                            )
                        }

                        speakResponse("Opening ${app.appLabel}.", onComplete = {
                            delay(400)
                            _uiState.update { it.copy(assistantState = AssistantState.IDLE, statusMessage = null) }
                        })
                    } else {
                        // Section 8: Never falsely claim success
                        val failMessage = ChatMessage(
                            sender = MessageSender.DOST,
                            text = result.message,
                            isError = true
                        )
                        _uiState.update { state ->
                            state.copy(
                                messages = state.messages + failMessage,
                                assistantState = AssistantState.ERROR,
                                isThinking = false,
                                statusMessage = null,
                                debugInfo = state.debugInfo.copy(
                                    assistantState = "ERROR",
                                    lastCommandStatus = "FAILED",
                                    lastError = result.error
                                )
                            )
                        }
                        speakResponse(result.message, onComplete = {
                            delay(600)
                            _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                        })
                    }
                }

                is AppMatchResult.Ambiguous -> {
                    // Section 6 & 10: Never randomly launch when ambiguous. Ask user for clarification.
                    val promptText = "Mujhe '${analysis.targetAppName}' ke liye kayi apps mili hain. Aap kaunsa app open karna chahte hain?"
                    val ambiguousMessage = ChatMessage(
                        sender = MessageSender.DOST,
                        text = promptText,
                        ambiguousCandidates = matchResult.candidates
                    )

                    _uiState.update { state ->
                        state.copy(
                            messages = state.messages + ambiguousMessage,
                            assistantState = AssistantState.IDLE,
                            isThinking = false,
                            statusMessage = null,
                            debugInfo = state.debugInfo.copy(
                                assistantState = "IDLE",
                                lastCommandStatus = "AMBIGUOUS (${matchResult.candidates.size} matches)",
                                aiRequestStatus = "Clarification needed"
                            )
                        )
                    }

                    speakResponse(promptText)
                }

                is AppMatchResult.NotFound -> {
                    // Section 10: App Not Installed handling
                    val appName = analysis.targetAppName ?: matchResult.query
                    val promptText = "Mujhe '$appName' installed nahi mila. Kya main ise Play Store par dhoondun ya web par search karoon?"
                    val notFoundMessage = ChatMessage(
                        sender = MessageSender.DOST,
                        text = promptText,
                        searchFallbackQuery = appName
                    )

                    _uiState.update { state ->
                        state.copy(
                            messages = state.messages + notFoundMessage,
                            assistantState = AssistantState.IDLE,
                            isThinking = false,
                            statusMessage = null,
                            lastSearchFallbackQuery = appName,
                            debugInfo = state.debugInfo.copy(
                                assistantState = "IDLE",
                                lastCommandStatus = "NOT_FOUND",
                                aiRequestStatus = "App not installed. Fallbacks offered."
                            )
                        )
                    }

                    speakResponse(promptText)
                }
            }
        }
    }

    /**
     * Section 11 & 13: Google Play Store Search
     */
    private fun handleSearchPlayStore(analysis: CommandAnalysis) {
        val query = analysis.searchQuery
            ?: analysis.targetAppName
            ?: _uiState.value.lastSearchFallbackQuery
            ?: ""

        if (query.isBlank()) {
            val prompt = "Aap Play Store par kaunsa app dhoondna chahte hain?"
            val msg = ChatMessage(sender = MessageSender.DOST, text = prompt)
            _uiState.update { it.copy(messages = it.messages + msg, assistantState = AssistantState.IDLE) }
            speakResponse(prompt)
            return
        }

        searchPlayStore(query)
    }

    fun searchPlayStore(query: String) {
        activeCommandJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.PROCESSING,
                    isThinking = true,
                    statusMessage = "Searching Play Store for \"$query\"...",
                    debugInfo = state.debugInfo.copy(
                        assistantState = "PROCESSING",
                        lastCommandStatus = "SEARCHING_PLAY_STORE"
                    )
                )
            }

            val result: CommandResult = storeSearchLauncher.searchPlayStore(query)

            if (result.status == CommandStatus.SUCCESS) {
                val responseMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + responseMessage,
                        assistantState = AssistantState.SUCCESS,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "SUCCESS",
                            lastCommandStatus = "SUCCESS"
                        )
                    )
                }

                speakResponse(result.message, onComplete = {
                    delay(400)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            } else {
                val failMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message,
                    isError = true
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + failMessage,
                        assistantState = AssistantState.ERROR,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "ERROR",
                            lastCommandStatus = "FAILED",
                            lastError = result.error
                        )
                    )
                }
                speakResponse(result.message, onComplete = {
                    delay(600)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            }
        }
    }

    /**
     * Section 12 & 13: Web Search
     */
    private fun handleSearchWeb(analysis: CommandAnalysis) {
        val query = analysis.searchQuery
            ?: analysis.targetAppName
            ?: _uiState.value.lastSearchFallbackQuery
            ?: ""

        if (query.isBlank()) {
            val prompt = "Aap web par kya search karna chahte hain?"
            val msg = ChatMessage(sender = MessageSender.DOST, text = prompt)
            _uiState.update { it.copy(messages = it.messages + msg, assistantState = AssistantState.IDLE) }
            speakResponse(prompt)
            return
        }

        searchWeb(query)
    }

    fun searchWeb(query: String) {
        activeCommandJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.PROCESSING,
                    isThinking = true,
                    statusMessage = "Searching web for \"$query\"...",
                    debugInfo = state.debugInfo.copy(
                        assistantState = "PROCESSING",
                        lastCommandStatus = "SEARCHING_WEB"
                    )
                )
            }

            val result: CommandResult = webSearchLauncher.searchWeb(query)

            if (result.status == CommandStatus.SUCCESS) {
                val responseMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + responseMessage,
                        assistantState = AssistantState.SUCCESS,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "SUCCESS",
                            lastCommandStatus = "SUCCESS"
                        )
                    )
                }

                speakResponse(result.message, onComplete = {
                    delay(400)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            } else {
                val failMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message,
                    isError = true
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + failMessage,
                        assistantState = AssistantState.ERROR,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "ERROR",
                            lastCommandStatus = "FAILED",
                            lastError = result.error
                        )
                    )
                }
                speakResponse(result.message, onComplete = {
                    delay(600)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            }
        }
    }

    /**
     * Section 16: Camera Launch
     */
    private fun handleCameraLaunch() {
        activeCommandJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.PROCESSING,
                    isThinking = true,
                    statusMessage = "Opening Camera...",
                    debugInfo = state.debugInfo.copy(
                        assistantState = "PROCESSING",
                        lastCommandStatus = "LAUNCHING_CAMERA"
                    )
                )
            }

            val result: CommandResult = appLauncher.launchCamera()

            if (result.status == CommandStatus.SUCCESS) {
                val responseMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = "Opening Camera."
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + responseMessage,
                        assistantState = AssistantState.SUCCESS,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "SUCCESS",
                            lastCommandStatus = "SUCCESS"
                        )
                    )
                }

                speakResponse("Opening Camera.", onComplete = {
                    delay(400)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            } else {
                val failMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message,
                    isError = true
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + failMessage,
                        assistantState = AssistantState.ERROR,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "ERROR",
                            lastCommandStatus = "FAILED",
                            lastError = result.error
                        )
                    )
                }
                speakResponse(result.message, onComplete = {
                    delay(600)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            }
        }
    }

    /**
     * User tapped one of the ambiguous app cards directly in the UI.
     */
    fun launchApp(app: InstalledApp) {
        stopSpeaking()
        activeCommandJob?.cancel()

        activeCommandJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.PROCESSING,
                    isThinking = true,
                    statusMessage = "Opening ${app.appLabel}...",
                    debugInfo = state.debugInfo.copy(
                        assistantState = "PROCESSING",
                        lastMatchedApp = "${app.appLabel} (${app.packageName})",
                        lastCommandStatus = "USER_PICKED_LAUNCH"
                    )
                )
            }

            val result = appLauncher.launchApp(app)

            if (result.status == CommandStatus.SUCCESS) {
                val responseMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = "Opening ${app.appLabel}."
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + responseMessage,
                        assistantState = AssistantState.SUCCESS,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "SUCCESS",
                            lastCommandStatus = "SUCCESS"
                        )
                    )
                }

                speakResponse("Opening ${app.appLabel}.", onComplete = {
                    delay(400)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            } else {
                val failMessage = ChatMessage(
                    sender = MessageSender.DOST,
                    text = result.message,
                    isError = true
                )
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages + failMessage,
                        assistantState = AssistantState.ERROR,
                        isThinking = false,
                        statusMessage = null,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "ERROR",
                            lastCommandStatus = "FAILED",
                            lastError = result.error
                        )
                    )
                }
                speakResponse(result.message, onComplete = {
                    delay(600)
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                })
            }
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            try {
                installedAppRepository.invalidateCache()
                val apps = installedAppRepository.getInstalledApps(forceRefresh = true)
                _uiState.update { state ->
                    state.copy(
                        debugInfo = state.debugInfo.copy(discoveredAppCount = apps.size)
                    )
                }
            } catch (e: Exception) {
                Log.e("DOST", "Failed to refresh installed apps: ${e.message}")
            }
        }
    }

    private fun handleUnsupportedDeviceAction(analysis: CommandAnalysis) {
        val replyText = IntentRouter.UNSUPPORTED_ACTION_MESSAGE
        val responseMessage = ChatMessage(
            sender = MessageSender.DOST,
            text = replyText
        )

        _uiState.update { state ->
            state.copy(
                messages = state.messages + responseMessage,
                assistantState = AssistantState.SPEAKING,
                isSpeaking = true,
                debugInfo = state.debugInfo.copy(
                    assistantState = "SPEAKING",
                    aiRequestStatus = "Device action unsupported in Phase 2"
                )
            )
        }

        speakResponse(replyText, onComplete = {
            _uiState.update { state ->
                state.copy(
                    isSpeaking = false,
                    assistantState = if (state.assistantState == AssistantState.SPEAKING) AssistantState.IDLE else state.assistantState
                )
            }
        })
    }

    private fun speakResponse(text: String, onComplete: (suspend () -> Unit)? = null) {
        if (_uiState.value.settings.voiceResponsesEnabled) {
            _uiState.update { state ->
                state.copy(
                    isSpeaking = true,
                    assistantState = if (state.assistantState == AssistantState.IDLE) AssistantState.SPEAKING else state.assistantState
                )
            }
            voiceEngine.speak(
                text = text,
                speechRate = _uiState.value.settings.speechRate,
                pitch = _uiState.value.settings.pitch,
                language = _uiState.value.settings.language,
                onComplete = {
                    viewModelScope.launch {
                        _uiState.update { state ->
                            state.copy(
                                isSpeaking = false,
                                assistantState = if (state.assistantState == AssistantState.SPEAKING) AssistantState.IDLE else state.assistantState
                            )
                        }
                        if (onComplete != null) {
                            onComplete.invoke()
                        } else {
                            handlePostInteractionTransition()
                        }
                    }
                }
            )
        } else {
            viewModelScope.launch {
                if (onComplete != null) {
                    onComplete.invoke()
                } else {
                    handlePostInteractionTransition()
                }
            }
        }
    }

    private fun dispatchToAi(userPrompt: String) {
        activeAiJob = viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    assistantState = AssistantState.THINKING,
                    isThinking = true,
                    statusMessage = null,
                    debugInfo = state.debugInfo.copy(
                        assistantState = "THINKING",
                        aiRequestStatus = "Connecting to Gemini 3.6 Flash..."
                    )
                )
            }

            try {
                val conversationHistory = _uiState.value.messages.takeLast(10)
                val response = aiProvider.generateResponse(userPrompt, conversationHistory)

                _uiState.update { state ->
                    state.copy(
                        isThinking = false,
                        messages = state.messages + ChatMessage(
                            sender = MessageSender.DOST,
                            text = response
                        ),
                        assistantState = AssistantState.SPEAKING,
                        isSpeaking = true,
                        debugInfo = state.debugInfo.copy(
                            assistantState = "SPEAKING",
                            aiRequestStatus = "Response received"
                        )
                    )
                }

                if (_uiState.value.settings.voiceResponsesEnabled) {
                    voiceEngine.speak(
                        text = response,
                        speechRate = _uiState.value.settings.speechRate,
                        pitch = _uiState.value.settings.pitch,
                        language = _uiState.value.settings.language,
                        onComplete = {
                            viewModelScope.launch {
                                _uiState.update { state ->
                                    state.copy(
                                        isSpeaking = false,
                                        assistantState = if (state.assistantState == AssistantState.SPEAKING) AssistantState.IDLE else state.assistantState
                                    )
                                }
                                handlePostInteractionTransition()
                            }
                        }
                    )
                } else {
                    _uiState.update { state ->
                        state.copy(
                            isSpeaking = false,
                            assistantState = AssistantState.IDLE
                        )
                    }
                    handlePostInteractionTransition()
                }

            } catch (e: Exception) {
                Log.e("DOST", "AI Generation error: ${e.message}")
                handleAiError(e)
            }
        }
    }

    private fun handleAiError(e: Exception) {
        val errorMessage = when {
            e.message?.contains("Unable to resolve host", ignoreCase = true) == true ||
            e.message?.contains("ConnectException", ignoreCase = true) == true ->
                "Network issue: Could not connect to DOST service. Please check your internet connection."
            e.message?.contains("timeout", ignoreCase = true) == true ->
                "Request timed out. Please tap retry to try again."
            else ->
                "DOST encountered an issue. Please try again."
        }

        if (retryCount < MAX_AUTO_RETRIES && lastUserMessage != null) {
            retryCount++
            _uiState.update { state ->
                state.copy(
                    debugInfo = state.debugInfo.copy(
                        aiRequestStatus = "Retrying ($retryCount/$MAX_AUTO_RETRIES)...",
                        lastError = e.message
                    )
                )
            }
            dispatchToAi(lastUserMessage!!)
            return
        }

        _uiState.update { state ->
            state.copy(
                isThinking = false,
                isSpeaking = false,
                assistantState = AssistantState.ERROR,
                errorMessage = errorMessage,
                canRetryLast = lastUserMessage != null,
                debugInfo = state.debugInfo.copy(
                    assistantState = "ERROR",
                    aiRequestStatus = "Failed",
                    lastError = e.message ?: errorMessage
                )
            )
        }
    }

    fun retryLastMessage() {
        val msg = lastUserMessage ?: return
        _uiState.update { it.copy(errorMessage = null, canRetryLast = false) }
        sendMessage(msg)
    }

    fun updateSettings(newSettings: DostSettings) {
        settingsRepository.saveSettings(newSettings)
        _uiState.update { it.copy(settings = newSettings) }
        voiceEngine.setPitch(newSettings.pitch)
        voiceEngine.setSpeechRate(newSettings.speechRate)
        voiceEngine.setVoice(newSettings.selectedVoiceId)
    }

    fun previewVoice(sampleType: String, onDone: () -> Unit = {}) {
        val sampleText = when (sampleType.lowercase()) {
            "hindi" -> "Namaste. Main DOST hoon. Main aapki madad ke liye taiyar hoon."
            "hinglish" -> "Dost, aaj hum ek interesting problem ko step by step solve karte hain."
            "english" -> "Hello, I am DOST. Let's solve this problem step by step."
            else -> "Namaste. Main DOST hoon. Main aapki madad ke liye taiyar hoon."
        }
        stopSpeaking()
        _uiState.update { it.copy(isSpeaking = true, assistantState = AssistantState.SPEAKING) }
        voiceEngine.speak(
            text = sampleText,
            speechRate = _uiState.value.settings.speechRate,
            pitch = _uiState.value.settings.pitch,
            language = if (sampleType.equals("hindi", ignoreCase = true)) "Hindi" else if (sampleType.equals("english", ignoreCase = true)) "English" else _uiState.value.settings.language,
            onDone = {
                _uiState.update { state ->
                    state.copy(
                        isSpeaking = false,
                        assistantState = if (state.assistantState == AssistantState.SPEAKING) AssistantState.IDLE else state.assistantState
                    )
                }
                onDone()
            }
        )
    }

    fun getAvailableVoices(): List<com.dost.ai.voice.TTSVoiceInfo> {
        return voiceEngine.getAvailableVoices()
    }

    fun isHindiVoiceAvailable(): Boolean {
        return voiceEngine.isHindiVoiceAvailable()
    }

    fun openSettings() {
        _uiState.update { it.copy(isSettingsOpen = true) }
    }

    fun closeSettings() {
        _uiState.update { it.copy(isSettingsOpen = false) }
    }

    fun dismissError() {
        _uiState.update {
            it.copy(
                errorMessage = null,
                assistantState = if (it.assistantState == AssistantState.ERROR) AssistantState.IDLE else it.assistantState
            )
        }
    }

    fun clearChat() {
        stopSpeaking()
        activeAiJob?.cancel()
        activeCommandJob?.cancel()
        _uiState.update { state ->
            state.copy(
                messages = listOf(
                    ChatMessage(
                        sender = MessageSender.DOST,
                        text = "Namaste! Main DOST hoon. Baat cheet naye sire se shuru karte hain. Kahiye, kya madad karoon?"
                    )
                ),
                assistantState = AssistantState.IDLE,
                errorMessage = null,
                canRetryLast = false,
                statusMessage = null,
                debugInfo = DebugInfo()
            )
        }
    }

    // ==========================================
    // PHASE 2: WAKE PHRASE & BACKGROUND ASSISTANT
    // ==========================================

    private fun observeFollowUpManager() {
        viewModelScope.launch {
            followUpManager.remainingSeconds.collect { sec ->
                _uiState.update { it.copy(followUpSecondsRemaining = sec) }
            }
        }
        viewModelScope.launch {
            followUpManager.isFollowUpActive.collect { active ->
                _uiState.update { it.copy(isFollowUpActive = active) }
            }
        }
    }

    fun refreshCapabilityReport() {
        val report = capabilityChecker.checkCapabilities()
        _uiState.update { it.copy(capabilityReport = report) }
    }

    private fun handlePostInteractionTransition() {
        val settings = _uiState.value.settings
        if (settings.followUpModeEnabled) {
            startFollowUpWindow()
        } else if (settings.wakeListeningEnabled) {
            startWakeListening()
        } else {
            assistantStateManager.transitionTo(AssistantState.IDLE)
            _uiState.update { it.copy(assistantState = AssistantState.IDLE, statusMessage = null) }
        }
    }

    private fun startFollowUpWindow() {
        val settings = _uiState.value.settings
        if (!settings.followUpModeEnabled) {
            if (settings.wakeListeningEnabled) startWakeListening()
            return
        }

        voiceSessionManager.requestMicOwnership(VoiceSessionManager.MicOwner.FOLLOW_UP_RECOGNIZER)
        assistantStateManager.transitionTo(AssistantState.FOLLOW_UP, "Listening for follow-up...")
        _uiState.update {
            it.copy(
                assistantState = AssistantState.FOLLOW_UP,
                isFollowUpActive = true,
                statusMessage = "Follow-up listening..."
            )
        }

        speechRecognizerManager.startListening(settings.language)

        followUpManager.startFollowUpWindow(
            durationSeconds = settings.followUpDurationSeconds,
            onTimeout = {
                viewModelScope.launch {
                    speechRecognizerManager.cancelListening()
                    voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.FOLLOW_UP_RECOGNIZER)
                    _uiState.update {
                        it.copy(
                            isFollowUpActive = false,
                            followUpSecondsRemaining = 0,
                            statusMessage = null
                        )
                    }
                    if (_uiState.value.settings.wakeListeningEnabled) {
                        startWakeListening()
                    } else {
                        assistantStateManager.transitionTo(AssistantState.IDLE)
                        _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                    }
                }
            }
        )
    }

    fun startWakeListening() {
        val settings = _uiState.value.settings
        if (!settings.wakeListeningEnabled) return

        val report = capabilityChecker.checkCapabilities()
        if (!report.isAudioPermissionGranted) {
            _uiState.update {
                it.copy(
                    errorMessage = "Microphone permission is required for wake listening.",
                    assistantState = AssistantState.IDLE
                )
            }
            return
        }

        voiceSessionManager.requestMicOwnership(VoiceSessionManager.MicOwner.WAKE_ENGINE)
        assistantStateManager.transitionTo(AssistantState.WAKE_LISTENING, "Wake Listening Active · Say 'Dost'")
        _uiState.update {
            it.copy(
                assistantState = AssistantState.WAKE_LISTENING,
                isWakeListening = true,
                statusMessage = "Say 'Dost'..."
            )
        }

        wakeWordEngine.initialize(
            context = getApplication(),
            onWakeDetected = { wakePhrase ->
                viewModelScope.launch {
                    handleWakePhraseDetected(wakePhrase)
                }
            },
            onError = { err ->
                viewModelScope.launch {
                    Log.w("DOST", "Wake detection error: $err")
                }
            }
        )
        wakeWordEngine.startListening()
    }

    fun stopWakeListening() {
        wakeWordEngine.stopListening()
        voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.WAKE_ENGINE)
        _uiState.update {
            it.copy(
                isWakeListening = false,
                assistantState = if (it.assistantState == AssistantState.WAKE_LISTENING) AssistantState.IDLE else it.assistantState,
                statusMessage = null
            )
        }
    }

    fun handleWakePhraseDetected(wakePhrase: String) {
        Log.i("DOST", "handleWakePhraseDetected: '$wakePhrase'")
        wakeWordEngine.stopListening()
        voiceSessionManager.releaseMicOwnership(VoiceSessionManager.MicOwner.WAKE_ENGINE)

        assistantStateManager.transitionTo(AssistantState.WAKE_DETECTED, "Wake phrase detected: $wakePhrase")
        _uiState.update {
            it.copy(
                assistantState = AssistantState.WAKE_DETECTED,
                statusMessage = "Ha, bolo..."
            )
        }

        val settings = _uiState.value.settings
        if (settings.wakeAcknowledgementEnabled && settings.wakeAcknowledgementPhrase.isNotBlank()) {
            speakResponse(settings.wakeAcknowledgementPhrase, onComplete = {
                beginCommandListening()
            })
        } else {
            beginCommandListening()
        }
    }

    private fun beginCommandListening() {
        voiceSessionManager.requestMicOwnership(VoiceSessionManager.MicOwner.COMMAND_RECOGNIZER)
        assistantStateManager.transitionTo(AssistantState.LISTENING_COMMAND, "Listening for your command...")
        _uiState.update {
            it.copy(
                assistantState = AssistantState.LISTENING_COMMAND,
                currentSpeechTranscript = "",
                statusMessage = "Listening for command..."
            )
        }
        speechRecognizerManager.startListening(_uiState.value.settings.language)
    }

    fun setWakeListening(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(wakeListeningEnabled = enabled)
        updateSettings(newSettings)
        if (enabled) {
            startWakeListening()
        } else {
            stopWakeListening()
        }
    }

    fun setBackgroundAssistant(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(backgroundAssistantEnabled = enabled)
        updateSettings(newSettings)
        if (enabled) {
            val success = backgroundAssistantManager.startBackgroundAssistant(enableWakeListening = newSettings.wakeListeningEnabled)
            _uiState.update { it.copy(isBackgroundAssistantActive = success) }
        } else {
            backgroundAssistantManager.stopBackgroundAssistant()
            _uiState.update { it.copy(isBackgroundAssistantActive = false) }
        }
    }

    fun setFollowUpMode(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(followUpModeEnabled = enabled)
        updateSettings(newSettings)
    }

    fun setFollowUpDuration(seconds: Int) {
        val newSettings = _uiState.value.settings.copy(followUpDurationSeconds = seconds)
        updateSettings(newSettings)
    }

    fun setWakeAcknowledgement(phrase: String) {
        val newSettings = _uiState.value.settings.copy(
            wakeAcknowledgementEnabled = phrase.isNotBlank(),
            wakeAcknowledgementPhrase = phrase
        )
        updateSettings(newSettings)
    }

    fun openBatterySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (err: Exception) {
                Log.e("DOST", "Failed to open battery settings", err)
            }
        }
    }

    fun stopDost() {
        activeAiJob?.cancel()
        activeCommandJob?.cancel()
        followUpManager.cancelFollowUp()
        stopSpeaking()
        speechRecognizerManager.cancelListening()
        wakeWordEngine.stopListening()
        voiceSessionManager.forceReleaseAll()
        backgroundAssistantManager.stopBackgroundAssistant()
        assistantStateManager.transitionTo(AssistantState.STOPPED, "DOST has stopped")
        val updatedSettings = _uiState.value.settings.copy(
            wakeListeningEnabled = false,
            backgroundAssistantEnabled = false
        )
        settingsRepository.saveSettings(updatedSettings)
        _uiState.update { state ->
            state.copy(
                assistantState = AssistantState.IDLE,
                isListening = false,
                isSpeaking = false,
                isThinking = false,
                isWakeListening = false,
                isBackgroundAssistantActive = false,
                isFollowUpActive = false,
                followUpSecondsRemaining = 0,
                statusMessage = "DOST stopped",
                settings = updatedSettings,
                messages = state.messages + ChatMessage(
                    sender = MessageSender.DOST,
                    text = "DOST ko rok diya gaya hai. Sabhi background aur microphone sessions band kar diye gaye hain."
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        activeAiJob?.cancel()
        activeCommandJob?.cancel()
        followUpManager.cancelFollowUp()
        wakeWordEngine.destroy()
        voiceSessionManager.forceReleaseAll()
        speechRecognizerManager.destroy()
        voiceEngine.shutdown()
    }
}
