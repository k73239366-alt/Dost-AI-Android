package com.dost.ai.commands

/**
 * Normalizes input text according to DOST 2.0 Phase 1 specifications:
 * 1. Convert to lowercase
 * 2. Remove unnecessary punctuation
 * 3. Normalize multiple whitespace sequences to single space
 * 4. Remove wake phrase "Dost" (and common variations like "hey dost", "dost ji") when it appears at the beginning
 * 5. Preserve the user's meaningful request across Hindi, Hinglish, and English.
 */
object CommandNormalizer {

    private val WAKE_PHRASES = listOf(
        "hey dost",
        "hi dost",
        "hello dost",
        "sun dost",
        "arre dost",
        "bhai dost",
        "dost ji",
        "dost please",
        "dost"
    )

    fun normalize(rawInput: String): String {
        if (rawInput.isBlank()) return ""

        // 1. Lowercase
        var text = rawInput.lowercase()

        // 2. Remove unnecessary punctuation (preserve letters, digits, spaces, Hindi unicode characters)
        // Keep standard unicode letters/marks (\p{L}, \p{M}) and digits (\p{N})
        text = text.replace(Regex("""[.,!?;:'"()[\]{}<>/\\_`~*#@$%^&=+|]"""), " ")

        // 3. Normalize spaces
        text = text.replace(Regex("""\s+"""), " ").trim()

        // 4. Remove wake phrase "Dost" when it appears at the beginning
        for (wake in WAKE_PHRASES) {
            if (text.startsWith("$wake ")) {
                text = text.substring(wake.length).trim()
                break
            } else if (text == wake) {
                text = ""
                break
            }
        }

        return text
    }
}
