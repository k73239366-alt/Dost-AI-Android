package com.dost.ai.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Robust Android SpeechRecognizerManager for DOST 2.0 Phase 1.
 * - Separates live partial preview from final recognized speech.
 * - Prevents premature stopping by letting the recognizer complete its decoding cycle after onEndOfSpeech.
 * - Implements a smart candidate selection strategy preferring complete, meaningful phrases over cut-off fragments.
 * - Configures speech input silence thresholds for natural Hindi, Hinglish, and English sentences.
 * - Provides duplicate submission protection and comprehensive debug state tracking.
 */
class SpeechRecognizerManager(
    private val context: Context
) : RecognitionListener {

    private var speechRecognizer: SpeechRecognizer? = null

    // Recognition session tracking
    private var isSessionActive = false
    private var hasEmittedFinalForSession = false

    // State flows
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _recognitionState = MutableStateFlow("IDLE")
    val recognitionState: StateFlow<String> = _recognitionState.asStateFlow()

    private val _recognitionEvent = MutableStateFlow("Idle")
    val recognitionEvent: StateFlow<String> = _recognitionEvent.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _finalTranscript = MutableStateFlow("")
    val finalTranscript: StateFlow<String> = _finalTranscript.asStateFlow()

    private val _selectedCandidate = MutableStateFlow("")
    val selectedCandidate: StateFlow<String> = _selectedCandidate.asStateFlow()

    // Live display transcript (shows partial while listening, final when completed)
    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // Callback listeners
    var onFinalResultListener: ((String) -> Unit)? = null
    var onPartialResultListener: ((String) -> Unit)? = null

    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Starts listening with optimized language and silence parameters.
     */
    fun startListening(languagePreference: String = "Auto") {
        try {
            cancelListening()

            _error.value = null
            _partialTranscript.value = ""
            _finalTranscript.value = ""
            _selectedCandidate.value = ""
            _transcript.value = ""
            hasEmittedFinalForSession = false
            isSessionActive = true

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _error.value = "Speech recognition is not available on this device."
                _recognitionState.value = "ERROR"
                _recognitionEvent.value = "Recognizer unavailable"
                _isListening.value = false
                isSessionActive = false
                return
            }

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@SpeechRecognizerManager)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)

                // Voice Activity and Silence Handling (Section 8)
                // Avoid overly aggressive silence cutoffs so sentences like "Open YouTube"
                // or "Dost mujhe Python ke loops samjhao" are not truncated after the first word.
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L)

                // Language handling (Section 7)
                // In India, en-IN is the device standard for mixed Hinglish and Indian accents.
                // hi-IN is used for pure Hindi.
                val targetLocale = when (languagePreference.lowercase()) {
                    "hindi" -> "hi-IN"
                    "english" -> "en-IN"
                    else -> {
                        // AUTO mode: Use device locale if Hindi, otherwise en-IN for optimal Hinglish/English support
                        val defaultTag = Locale.getDefault().toLanguageTag()
                        if (defaultTag.startsWith("hi", ignoreCase = true)) "hi-IN" else "en-IN"
                    }
                }
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, targetLocale)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, targetLocale)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                // Additional languages hint for multilingual recognition
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN", "en-US"))
            }

            _recognitionState.value = "INITIALIZING"
            _recognitionEvent.value = "Starting recognizer ($languagePreference)..."
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            Log.e("DOST", "Error starting speech recognition: ${e.message}")
            _error.value = "Could not start voice recognition. Please check microphone permission."
            _recognitionState.value = "ERROR"
            _recognitionEvent.value = "Failed to start: ${e.message}"
            _isListening.value = false
            isSessionActive = false
        }
    }

    /**
     * Tells the recognizer that the user stopped speaking and requests final results.
     * Note: Does NOT immediately cancel or discard; allows the recognizer to process the audio.
     */
    fun stopListening() {
        try {
            _recognitionState.value = "PROCESSING"
            _recognitionEvent.value = "Finalizing speech..."
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w("DOST", "Error in stopListening: ${e.message}")
            _isListening.value = false
        }
    }

    /**
     * Cancels the recognition session immediately and destroys recognizer resources.
     */
    fun cancelListening() {
        isSessionActive = false
        hasEmittedFinalForSession = true
        _isListening.value = false
        _recognitionState.value = "IDLE"
        _recognitionEvent.value = "Cancelled"
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            // Ignore safe cleanup
        }
    }

    fun clearError() {
        _error.value = null
    }

    // =========================================================================
    // RecognitionListener Callbacks
    // =========================================================================

    override fun onReadyForSpeech(params: Bundle?) {
        _isListening.value = true
        _recognitionState.value = "LISTENING"
        _recognitionEvent.value = "Ready for speech"
    }

    override fun onBeginningOfSpeech() {
        _isListening.value = true
        _recognitionState.value = "LISTENING"
        _recognitionEvent.value = "Speech started"
    }

    override fun onRmsChanged(rmsdB: Float) {
        // Audio volume level change
    }

    override fun onBufferReceived(buffer: ByteArray?) {
        // Audio buffer received
    }

    /**
     * Triggered when the user finishes speaking sound.
     * CRITICAL: Do NOT set _isListening = false or destroy recognizer here!
     * The recognizer is actively decoding the recorded audio and will call onResults.
     */
    override fun onEndOfSpeech() {
        _recognitionState.value = "PROCESSING"
        _recognitionEvent.value = "End of speech, decoding..."
    }

    override fun onError(errorCode: Int) {
        _isListening.value = false
        _recognitionState.value = "ERROR"
        isSessionActive = false

        val userFriendlyMessage = when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Please check your microphone."
            SpeechRecognizer.ERROR_CLIENT -> "Speech recognition client error. Please try again."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required for voice input."
            SpeechRecognizer.ERROR_NETWORK -> "Network error occurred while recognizing speech. Please check your connection."
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition network timeout. Please check your connection."
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech was detected. Please try speaking again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer is busy. Please try again."
            SpeechRecognizer.ERROR_SERVER -> "Voice recognition server error. Please try again."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap microphone to speak."
            else -> "Speech recognition encountered an issue ($errorCode). Please try again."
        }

        _error.value = userFriendlyMessage
        _recognitionEvent.value = "Error $errorCode: $userFriendlyMessage"

        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            // Ignore
        }
    }

    /**
     * FINAL RESULTS: Only final recognized speech is submitted as the user command.
     */
    override fun onResults(results: Bundle?) {
        _isListening.value = false
        _recognitionState.value = "COMPLETED"

        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)

        val bestCandidate = selectBestCandidate(matches, scores)

        _finalTranscript.value = bestCandidate
        _selectedCandidate.value = bestCandidate
        _transcript.value = bestCandidate
        _recognitionEvent.value = "Final result: $bestCandidate"

        if (bestCandidate.isNotBlank()) {
            if (isSessionActive && !hasEmittedFinalForSession) {
                hasEmittedFinalForSession = true
                isSessionActive = false
                Log.d("DOST", "Speech recognition complete. Selected candidate: \"$bestCandidate\"")
                onFinalResultListener?.invoke(bestCandidate)
            }
        } else {
            _error.value = "No speech was detected. Please try speaking again."
            isSessionActive = false
        }
    }

    /**
     * PARTIAL RESULTS: Only for live UI preview. NEVER trigger command detection or AI requests here!
     */
    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partial = matches?.firstOrNull { it.isNotBlank() } ?: ""

        if (partial.isNotBlank()) {
            _partialTranscript.value = partial
            _transcript.value = partial
            _recognitionEvent.value = "Partial: $partial"
            onPartialResultListener?.invoke(partial)
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {
        // Recognition event
    }

    /**
     * Selects the best candidate among multiple recognition hypotheses.
     * Strategy:
     * 1. Prefer high-confidence candidate when confidence data is available.
     * 2. Prefer candidate containing more complete meaningful words.
     * 3. Penalize candidates that are merely truncated prefixes of longer valid candidates (e.g. "open" vs "Open YouTube").
     * 4. Never invent or artificially modify words.
     */
    fun selectBestCandidate(
        candidates: List<String>,
        confidenceScores: FloatArray?
    ): String {
        val valid = candidates.map { it.trim() }.filter { it.isNotBlank() }
        if (valid.isEmpty()) return ""
        if (valid.size == 1) return valid[0]

        var bestCandidate = valid[0]
        var highestScore = Float.NEGATIVE_INFINITY

        for (i in valid.indices) {
            val candidate = valid[i]
            val words = candidate.split("\\s+".toRegex()).filter { it.isNotBlank() }
            val wordCount = words.size
            val charCount = candidate.length

            val rawConf = confidenceScores?.getOrNull(i) ?: -1f
            val baseConfidence = if (rawConf > 0.0f) rawConf.coerceIn(0.0f, 1.0f) else 0.5f

            // Completeness bonus: each additional word adds 0.10 score (capped at 10 words)
            val completenessBonus = (wordCount.coerceAtMost(10) - 1) * 0.10f

            // Prefix penalty: if this candidate is a strict prefix/fragment of another longer candidate
            // (e.g. "open" vs "Open YouTube", or "Dost mujhe" vs "Dost mujhe Python ke loops samjhao"),
            // penalize it heavily so the complete spoken utterance is preferred.
            val isStrictPrefix = valid.any { other ->
                other.length > candidate.length && other.startsWith(candidate, ignoreCase = true)
            }
            val prefixPenalty = if (isStrictPrefix) 0.40f else 0.0f

            val totalScore = baseConfidence + completenessBonus - prefixPenalty

            if (totalScore > highestScore) {
                highestScore = totalScore
                bestCandidate = candidate
            } else if (totalScore == highestScore) {
                // Tie-breaker: prefer candidate with more words and length
                val bestWordCount = bestCandidate.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
                if (wordCount > bestWordCount || (wordCount == bestWordCount && charCount > bestCandidate.length)) {
                    bestCandidate = candidate
                }
            }
        }

        return bestCandidate
    }

    fun destroy() {
        cancelListening()
    }
}
