package com.dost.ai.speech

import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages Follow-up Mode lifecycle after a command execution completes.
 *
 * Configurable durations: 5, 10, 20, 30 seconds.
 * Allows the user to continue speaking commands without repeating "Dost".
 * Ensures strict timeout and cancellation semantics to avoid microphone loops.
 */
class FollowUpManager {

    private val handler = Handler(Looper.getMainLooper())

    private val _isFollowUpActive = MutableStateFlow(false)
    val isFollowUpActive: StateFlow<Boolean> = _isFollowUpActive.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(0)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private var onTimeoutCallback: (() -> Unit)? = null
    private var countdownRunnable: Runnable? = null

    val cancelKeywords = listOf("ruko", "stop", "cancel", "chup", "quiet", "bas", "band karo", "done", "bye")

    /**
     * Checks whether user utterance explicitly requests ending the follow-up window.
     */
    fun isCancelCommand(text: String): Boolean {
        val lower = text.trim().lowercase()
        return cancelKeywords.any { lower == it || lower.startsWith("$it ") || lower.endsWith(" $it") }
    }

    fun startFollowUpWindow(
        durationSeconds: Int = 5,
        onTimeout: () -> Unit
    ) {
        cancelFollowUp()

        this.onTimeoutCallback = onTimeout
        val validSeconds = durationSeconds.coerceIn(5, 30)
        _remainingSeconds.value = validSeconds
        _isFollowUpActive.value = true

        Log.d(TAG, "Started follow-up window for ${validSeconds}s")

        scheduleCountdown(validSeconds)
    }

    private fun scheduleCountdown(secondsLeft: Int) {
        countdownRunnable = Runnable {
            val next = secondsLeft - 1
            if (next > 0 && _isFollowUpActive.value) {
                _remainingSeconds.value = next
                scheduleCountdown(next)
            } else if (_isFollowUpActive.value) {
                Log.d(TAG, "Follow-up window expired.")
                cancelFollowUp()
                onTimeoutCallback?.invoke()
            }
        }
        handler.postDelayed(countdownRunnable!!, 1000L)
    }

    fun cancelFollowUp() {
        countdownRunnable?.let { handler.removeCallbacks(it) }
        countdownRunnable = null
        _isFollowUpActive.value = false
        _remainingSeconds.value = 0
    }

    companion object {
        private const val TAG = "FollowUpManager"
    }
}
