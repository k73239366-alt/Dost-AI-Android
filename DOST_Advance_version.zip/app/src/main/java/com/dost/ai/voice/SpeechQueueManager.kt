package com.dost.ai.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Manages speech output queue to prevent overlapping speech,
 * ensuring clean interruption when user stops or speaks.
 */
class SpeechQueueManager {
    private val speechQueue = ConcurrentLinkedQueue<String>()
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    fun enqueue(text: String) {
        speechQueue.add(text)
    }

    fun poll(): String? = speechQueue.poll()

    fun clearQueue() {
        speechQueue.clear()
        _isSpeaking.value = false
    }

    fun setSpeakingState(speaking: Boolean) {
        _isSpeaking.value = speaking
    }
}
