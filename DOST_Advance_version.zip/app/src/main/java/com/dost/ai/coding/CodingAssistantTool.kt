package com.dost.ai.coding

import android.content.Context
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Coding Assistant Tool for DOST:
 * Handles code explanation, debugging, review, and generation.
 */
class CodingAssistantTool : BaseTool {
    override val name: String = "CODING_HELP"
    override val description: String = "Explains, debugs, and generates clean code in Kotlin, Python, JS, C++, and more."

    override fun validateParams(params: Map<String, Any?>): String? {
        val prompt = params["prompt"] as? String
        if (prompt.isNullOrBlank()) return "Coding prompt or code snippet is required."
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val prompt = (params["prompt"] as? String) ?: ""
        val language = (params["language"] as? String) ?: "generic"

        return ToolResult.success(
            name,
            "Coding assistance processed for language: $language",
            mapOf("prompt" to prompt, "language" to language)
        )
    }
}
