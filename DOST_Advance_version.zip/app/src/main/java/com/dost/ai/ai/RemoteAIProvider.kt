package com.dost.ai.ai

import com.dost.ai.data.model.ChatMessage
import com.dost.ai.data.model.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class RemoteAIProvider(
    private val getBaseUrl: () -> String
) : AIProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private var activeCall: Call? = null

    override suspend fun sendMessage(
        userMessage: String,
        sessionHistory: List<ChatMessage>,
        languageStyle: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("userMessage", userMessage)
                put("languageStyle", languageStyle)

                val historyArray = JSONArray()
                // Send last 8 session messages for context memory
                sessionHistory.takeLast(8).forEach { msg ->
                    val obj = JSONObject().apply {
                        put("sender", if (msg.sender == MessageSender.USER) "user" else "model")
                        put("text", msg.text)
                    }
                    historyArray.put(obj)
                }
                put("messages", historyArray)
            }

            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("${getBaseUrl().trimEnd('/')}/api/chat")
                .post(body)
                .build()

            val call = client.newCall(request)
            activeCall = call
            val response = call.execute()

            if (response.isSuccessful) {
                val respBody = response.body?.string() ?: ""
                val json = JSONObject(respBody)
                val replyText = json.optString("text", "")
                if (replyText.isNotBlank()) {
                    return@withContext Result.success(replyText)
                }
            }
            return@withContext Result.failure(Exception("DOST is having trouble reaching the AI service."))
        } catch (e: IOException) {
            return@withContext Result.failure(Exception("No internet connection or server unreachable."))
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        } finally {
            activeCall = null
        }
    }

    override suspend fun cancelResponse() {
        withContext(Dispatchers.IO) {
            activeCall?.cancel()
            activeCall = null
        }
    }
}
