package com.dost.ai.background

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.dost.ai.service.DostAssistantService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Controller to start, pause, resume, and stop the DostAssistantService.
 *
 * Enforces explicit user action prerequisites before launching foreground services:
 * - Verifies RECORD_AUDIO permission
 * - Verifies POST_NOTIFICATIONS on Android 13+
 * - Prevents duplicate service runs
 */
class BackgroundAssistantManager(
    private val context: Context,
    private val capabilityChecker: BackgroundCapabilityChecker
) {
    private val _isServiceActive = MutableStateFlow(false)
    val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

    private val _serviceError = MutableStateFlow<String?>(null)
    val serviceError: StateFlow<String?> = _serviceError.asStateFlow()

    fun startBackgroundAssistant(enableWakeListening: Boolean = true): Boolean {
        val report = capabilityChecker.checkCapabilities()
        if (!report.isAudioPermissionGranted) {
            _serviceError.value = "Cannot start background assistant: Microphone permission not granted."
            return false
        }

        try {
            val intent = Intent(context, DostAssistantService::class.java).apply {
                action = if (enableWakeListening) {
                    DostAssistantService.ACTION_START_WAKE_LISTENING
                } else {
                    null
                }
            }

            ContextCompat.startForegroundService(context, intent)
            _isServiceActive.value = true
            _serviceError.value = null
            Log.i(TAG, "Background assistant foreground service started.")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start foreground service", e)
            _serviceError.value = "Failed to start background assistant: ${e.message}"
            _isServiceActive.value = false
            return false
        }
    }

    fun stopBackgroundAssistant() {
        try {
            val intent = Intent(context, DostAssistantService::class.java).apply {
                action = DostAssistantService.ACTION_STOP_SERVICE
            }
            context.startService(intent)
            _isServiceActive.value = false
            _serviceError.value = null
            Log.i(TAG, "Background assistant foreground service stopped.")
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping foreground service", e)
        }
    }

    fun pauseWakeListening() {
        try {
            val intent = Intent(context, DostAssistantService::class.java).apply {
                action = DostAssistantService.ACTION_PAUSE
            }
            context.startService(intent)
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing wake listening", e)
        }
    }

    fun resumeWakeListening() {
        try {
            val intent = Intent(context, DostAssistantService::class.java).apply {
                action = DostAssistantService.ACTION_RESUME
            }
            context.startService(intent)
        } catch (e: Exception) {
            Log.w(TAG, "Error resuming wake listening", e)
        }
    }

    companion object {
        private const val TAG = "BackgroundAssistantMgr"
    }
}
