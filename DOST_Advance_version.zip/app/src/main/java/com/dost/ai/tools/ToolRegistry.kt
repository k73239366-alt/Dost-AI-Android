package com.dost.ai.tools

import android.content.Context
import com.dost.ai.commands.CommandStatus
import java.util.concurrent.ConcurrentHashMap

/**
 * Central Tool Registry for DOST.
 * Contains all executable native tools.
 */
class ToolRegistry {
    private val tools = ConcurrentHashMap<String, BaseTool>()

    fun register(tool: BaseTool) {
        tools[tool.name.uppercase()] = tool
    }

    fun getTool(name: String): BaseTool? {
        return tools[name.uppercase()]
    }

    fun getAllTools(): List<BaseTool> {
        return tools.values.toList()
    }

    fun isRegistered(name: String): Boolean {
        return tools.containsKey(name.uppercase())
    }
}

/**
 * Routes tool execution requests to the correct registered tool implementation.
 */
class ToolRouter(private val registry: ToolRegistry) {
    fun route(toolName: String): BaseTool? {
        return registry.getTool(toolName)
    }
}

/**
 * Safe executor for native tools.
 * Handles validation, permissions, and timing.
 */
class ToolExecutor(
    private val registry: ToolRegistry
) {
    suspend fun executeTool(
        context: Context,
        toolName: String,
        params: Map<String, Any?>
    ): ToolResult {
        val tool = registry.getTool(toolName)
            ?: return ToolResult.failure(toolName, "Unknown tool: $toolName")

        // 1. Parameter Validation
        val validationError = tool.validateParams(params)
        if (validationError != null) {
            return ToolResult.failure(toolName, "Invalid parameters: $validationError", validationError)
        }

        // 2. Permission Check
        if (!tool.hasRequiredPermission(context)) {
            val perm = tool.requiredPermission ?: "REQUIRED_PERMISSION"
            return ToolResult.permissionRequired(
                toolName,
                perm,
                "$toolName requires permission: $perm"
            )
        }

        // 3. Execution with Duration Timing
        val startTime = System.currentTimeMillis()
        return try {
            val result = tool.execute(context, params)
            val duration = System.currentTimeMillis() - startTime
            result.copy(executionDurationMs = duration)
        } catch (e: Exception) {
            ToolResult.failure(toolName, "Execution error: ${e.message}", e.message)
        }
    }
}
