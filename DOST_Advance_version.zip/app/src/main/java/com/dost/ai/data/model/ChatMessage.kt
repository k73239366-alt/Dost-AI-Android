package com.dost.ai.data.model

import com.dost.ai.apps.InstalledApp
import java.util.UUID

enum class MessageSender {
    USER,
    DOST,
    SYSTEM
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val detectedIntentName: String? = null,
    val isError: Boolean = false,
    val ambiguousCandidates: List<InstalledApp> = emptyList(),
    val searchFallbackQuery: String? = null
)
