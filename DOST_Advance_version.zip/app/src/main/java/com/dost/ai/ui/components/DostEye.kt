package com.dost.ai.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dost.ai.data.model.AssistantState

/**
 * Animated DOST Eye centerpiece composable.
 * Abstract original circular AI eye with central glowing core, kinetic rings, and state-driven animations.
 */
@Composable
fun DostEye(
    state: AssistantState,
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    onClick: () -> Unit = {}
) {
    DostEyeCore(
        state = state,
        modifier = modifier,
        size = size,
        onClick = onClick
    )
}
