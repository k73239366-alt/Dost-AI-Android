package com.dost.ai.tools

import com.dost.ai.commands.CommandStatus

/**
 * Typed execution result returned by all DOST tools.
 *
 * Strict Rule: Never fake execution. A device action is only successful
 * when the native tool actually executes and returns SUCCESS.
 */
data class ToolResult(
    val toolName: String,
    val status: CommandStatus,
    val userFacingMessage: String,
    val data: Map<String, Any?> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    val missingPermission: String? = null,
    val executionDurationMs: Long = 0L,
    val error: String? = null
) {
    companion object {
        fun success(toolName: String, message: String, data: Map<String, Any?> = emptyMap(), durationMs: Long = 0L): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.SUCCESS,
                userFacingMessage = message,
                data = data,
                executionDurationMs = durationMs
            )
        }

        fun failure(toolName: String, message: String, error: String? = null): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.FAILED,
                userFacingMessage = message,
                error = error
            )
        }

        fun notFound(toolName: String, message: String, fallbackQuery: String? = null): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.NOT_FOUND,
                userFacingMessage = message,
                data = if (fallbackQuery != null) mapOf("fallbackQuery" to fallbackQuery) else emptyMap()
            )
        }

        fun ambiguous(toolName: String, message: String, candidates: List<Any>): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.AMBIGUOUS,
                userFacingMessage = message,
                data = mapOf("candidates" to candidates)
            )
        }

        fun permissionRequired(toolName: String, permission: String, rationale: String): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.PERMISSION_REQUIRED,
                userFacingMessage = rationale,
                missingPermission = permission
            )
        }

        fun confirmationRequired(toolName: String, prompt: String, pendingData: Map<String, Any?>): ToolResult {
            return ToolResult(
                toolName = toolName,
                status = CommandStatus.CONFIRMATION_REQUIRED,
                userFacingMessage = prompt,
                data = pendingData,
                requiresConfirmation = true
            )
        }
    }
}
