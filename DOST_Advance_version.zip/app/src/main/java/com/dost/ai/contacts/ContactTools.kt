package com.dost.ai.contacts

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

data class ContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String? = null
)

/**
 * Accesses local contacts when READ_CONTACTS permission is granted.
 */
class ContactRepository(private val context: Context) {
    fun searchContacts(query: String): List<ContactItem> {
        val results = mutableListOf<ContactItem>()
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return results
        }

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$query%")

        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )
            cursor?.use {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val idIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)

                while (it.moveToNext()) {
                    val name = if (nameIndex >= 0) it.getString(nameIndex) else "Unknown"
                    val number = if (numberIndex >= 0) it.getString(numberIndex) else null
                    val id = if (idIndex >= 0) it.getString(idIndex) else name
                    results.add(ContactItem(id = id, name = name, phoneNumber = number))
                }
            }
        } catch (e: Exception) {
            // Handled gracefully
        }
        return results.distinctBy { it.name }
    }
}

/**
 * Resolves contacts with ambiguity handling.
 */
class ContactResolver(private val repository: ContactRepository) {
    fun resolve(query: String): ContactResolution {
        val matches = repository.searchContacts(query)
        return when {
            matches.isEmpty() -> ContactResolution.NotFound(query)
            matches.size == 1 -> ContactResolution.SingleMatch(matches.first())
            else -> ContactResolution.Ambiguous(query, matches)
        }
    }
}

sealed class ContactResolution {
    data class SingleMatch(val contact: ContactItem) : ContactResolution()
    data class Ambiguous(val query: String, val candidates: List<ContactItem>) : ContactResolution()
    data class NotFound(val query: String) : ContactResolution()
}

/**
 * Tool for calling contacts. Never initiates a call silently; opens dialer or requests confirmation.
 */
class CallTool(
    private val contactResolver: ContactResolver
) : BaseTool {
    override val name: String = "CALL_CONTACT"
    override val description: String = "Dials or initiates phone call with recipient confirmation."
    override val requiredPermission: String = Manifest.permission.READ_CONTACTS
    override val requiresConfirmation: Boolean = true

    override fun validateParams(params: Map<String, Any?>): String? {
        val target = params["target"] as? String
        val number = params["phoneNumber"] as? String
        if (target.isNullOrBlank() && number.isNullOrBlank()) {
            return "Contact name or phone number is required."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val directNumber = params["phoneNumber"] as? String
        if (!directNumber.isNullOrBlank()) {
            return launchDialer(context, directNumber, directNumber)
        }

        val target = (params["target"] as? String)?.trim() ?: ""
        return when (val resolution = contactResolver.resolve(target)) {
            is ContactResolution.NotFound -> {
                ToolResult.notFound(name, "\"$target\" naam ka koi contact nahi mila.")
            }
            is ContactResolution.Ambiguous -> {
                val names = resolution.candidates.joinToString(" ya ") { it.name }
                ToolResult.ambiguous(
                    name,
                    "Aap kisko call karna chahte hain? $names?",
                    resolution.candidates
                )
            }
            is ContactResolution.SingleMatch -> {
                val contact = resolution.contact
                if (contact.phoneNumber.isNullOrBlank()) {
                    ToolResult.failure(name, "${contact.name} ka koi phone number nahi mila.")
                } else {
                    launchDialer(context, contact.phoneNumber, contact.name)
                }
            }
        }
    }

    private fun launchDialer(context: Context, number: String, label: String): ToolResult {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ToolResult.success(
                name,
                "$label ke liye dialer open kiya jaa raha hai.",
                mapOf("phoneNumber" to number, "recipient" to label)
            )
        } catch (e: Exception) {
            ToolResult.failure(name, "Dialer open nahi ho saka: ${e.message}")
        }
    }
}

/**
 * Messaging Tool drafting messages and launching composer with confirmation.
 */
class MessagingTool(
    private val contactResolver: ContactResolver
) : BaseTool {
    override val name: String = "SEND_MESSAGE"
    override val description: String = "Drafts SMS or chat message with explicit recipient and text confirmation."
    override val requiresConfirmation: Boolean = true

    override fun validateParams(params: Map<String, Any?>): String? {
        val text = params["messageText"] as? String
        if (text.isNullOrBlank()) return "Message body cannot be empty."
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val target = (params["target"] as? String)?.trim() ?: ""
        val messageText = (params["messageText"] as? String)?.trim() ?: ""
        val confirmed = (params["confirmed"] as? Boolean) ?: false

        if (!confirmed) {
            return ToolResult.confirmationRequired(
                name,
                "Kya aap $target ko yeh message bhejna chahte hain?\n\"$messageText\"",
                mapOf("target" to target, "messageText" to messageText)
            )
        }

        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:")
                putExtra("sms_body", messageText)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ToolResult.success(
                name,
                "$target ke liye message composer ready hai.",
                mapOf("target" to target, "messageText" to messageText)
            )
        } catch (e: Exception) {
            ToolResult.failure(name, "Message composer open nahi ho saka: ${e.message}")
        }
    }
}
