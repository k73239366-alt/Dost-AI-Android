package com.dost.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.apps.InstalledApp
import com.dost.ai.data.model.ChatMessage
import com.dost.ai.ui.theme.DostPrimary
import com.dost.ai.ui.theme.DostTextSecondary

@Composable
fun ConversationList(
    messages: List<ChatMessage>,
    isThinking: Boolean,
    listState: LazyListState,
    onCopyText: (String) -> Unit,
    onLaunchApp: (InstalledApp) -> Unit,
    onSearchPlayStore: (String) -> Unit,
    onSearchWeb: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        items(messages, key = { it.id }) { message ->
            ChatMessageItem(
                message = message,
                onCopyText = onCopyText,
                onLaunchApp = onLaunchApp,
                onSearchPlayStore = onSearchPlayStore,
                onSearchWeb = onSearchWeb
            )
        }

        if (isThinking) {
            item(key = "thinking_indicator") {
                ThinkingIndicator()
            }
        }
    }
}

@Composable
private fun ThinkingIndicator() {
    val transition = rememberInfiniteTransition(label = "ThinkingPulse")
    val dot1Scale by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Dot1"
    )
    val dot2Scale by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, delayMillis = 150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Dot2"
    )
    val dot3Scale by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, delayMillis = 300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Dot3"
    )

    Row(
        modifier = Modifier.padding(start = 6.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .scale(dot1Scale)
                .clip(CircleShape)
                .background(DostPrimary)
        )
        Box(
            modifier = Modifier
                .size(7.dp)
                .scale(dot2Scale)
                .clip(CircleShape)
                .background(DostPrimary.copy(alpha = 0.8f))
        )
        Box(
            modifier = Modifier
                .size(7.dp)
                .scale(dot3Scale)
                .clip(CircleShape)
                .background(DostPrimary.copy(alpha = 0.6f))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "DOST is thinking...",
            fontSize = 12.sp,
            color = DostTextSecondary
        )
    }
}
