package com.dost.ai.core

/**
 * Architectural status classification for every capability in DOST.
 *
 * Mandatory rule from DOST specification:
 * "For every feature distinguish:
 *  - IMPLEMENTED
 *  - PARTIALLY_IMPLEMENTED
 *  - ARCHITECTURE_READY
 *  - REQUIRES_PROVIDER
 *  - REQUIRES_USER_PERMISSION
 *  - REQUIRES_FUTURE_PHASE"
 */
enum class FeatureStatus {
    IMPLEMENTED,
    PARTIALLY_IMPLEMENTED,
    ARCHITECTURE_READY,
    REQUIRES_PROVIDER,
    REQUIRES_USER_PERMISSION,
    REQUIRES_FUTURE_PHASE
}

/**
 * Capability descriptor mapping each DOST subsystem to its readiness state.
 */
data class SystemCapability(
    val name: String,
    val category: String,
    val status: FeatureStatus,
    val description: String,
    val permissionRequired: String? = null
)
