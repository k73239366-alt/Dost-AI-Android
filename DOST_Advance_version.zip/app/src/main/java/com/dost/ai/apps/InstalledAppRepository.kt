package com.dost.ai.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Repository responsible for discovering launchable installed applications on the device.
 *
 * Implements Section 4 & Section 24:
 * - Uses legitimate Android launcher and package manager APIs.
 * - Thread-safe in-memory cache to avoid repeated full-system scans.
 * - Discovers launchable activities compliant with Android 11+ package visibility rules.
 */
class InstalledAppRepository(private val context: Context) {

    private val mutex = Mutex()
    private var cachedApps: List<InstalledApp>? = null
    private var lastScanTimestamp: Long = 0L

    companion object {
        private const val TAG = "InstalledAppRepository"
        // Cache expiry threshold (5 minutes), but forced refresh can be called whenever needed
        private const val CACHE_EXPIRY_MS = 5 * 60 * 1000L
    }

    /**
     * Retrieves the list of launchable installed applications.
     * Uses cache unless [forceRefresh] is true or cache is expired.
     */
    suspend fun getInstalledApps(forceRefresh: Boolean = false): List<InstalledApp> {
        return withContext(Dispatchers.IO) {
            mutex.withLock {
                val currentTime = System.currentTimeMillis()
                if (!forceRefresh && cachedApps != null && (currentTime - lastScanTimestamp < CACHE_EXPIRY_MS)) {
                    return@withLock cachedApps!!
                }

                val discovered = scanInstalledApps()
                cachedApps = discovered
                lastScanTimestamp = currentTime
                discovered
            }
        }
    }

    /**
     * Checks if the app cache is populated without initiating a new scan.
     */
    fun hasCachedApps(): Boolean = cachedApps != null

    /**
     * Returns the currently cached apps if available, or empty list.
     */
    fun getCachedAppsSync(): List<InstalledApp> = cachedApps ?: emptyList()

    /**
     * Scans the package manager for launchable activities using Intent.ACTION_MAIN + Intent.CATEGORY_LAUNCHER.
     */
    private fun scanInstalledApps(): List<InstalledApp> {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resultList = mutableListOf<InstalledApp>()
        val seenPackages = mutableSetOf<String>()

        try {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PackageManager.ResolveInfoFlags.of(0L)
            } else {
                0
            }

            val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.queryIntentActivities(launcherIntent, flags as PackageManager.ResolveInfoFlags)
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(launcherIntent, flags as Int)
            }

            for (resolveInfo in resolveInfos) {
                val activityInfo = resolveInfo.activityInfo ?: continue
                val pkgName = activityInfo.packageName ?: continue

                // Avoid duplicate package entries from multiple launch activities
                if (seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val label = try {
                    resolveInfo.loadLabel(packageManager)?.toString()?.trim() ?: pkgName
                } catch (e: Exception) {
                    pkgName
                }

                val isSystem = try {
                    (activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                } catch (e: Exception) {
                    false
                }

                val icon = try {
                    resolveInfo.loadIcon(packageManager)
                } catch (e: Exception) {
                    null
                }

                resultList.add(
                    InstalledApp(
                        appLabel = label,
                        packageName = pkgName,
                        className = activityInfo.name,
                        isLaunchable = true,
                        isSystemApp = isSystem,
                        iconDrawable = icon
                    )
                )
            }

            // Sort alphabetically by app label
            resultList.sortBy { it.appLabel.lowercase() }
            Log.d(TAG, "Successfully scanned and discovered ${resultList.size} launchable installed apps.")
        } catch (e: Exception) {
            Log.e(TAG, "Error querying installed launcher applications: ${e.message}", e)
        }

        return resultList
    }

    /**
     * Invalidates the current cache, forcing the next lookup to query the system.
     */
    suspend fun invalidateCache() {
        mutex.withLock {
            cachedApps = null
            lastScanTimestamp = 0L
        }
    }
}
