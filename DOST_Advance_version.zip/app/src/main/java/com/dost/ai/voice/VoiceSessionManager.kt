package com.dost.ai.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single source of truth for Microphone & Audio Focus Ownership.
 *
 * Guarantees that only ONE component owns the microphone at any given moment:
 * - Wake Word Engine
 * - Active Command Speech Recognizer
 * - Follow-up Speech Recognizer
 *
 * Prevents overlapping AudioRecord instances, microphone lockouts, or concurrent STT sessions.
 */
class VoiceSessionManager(
    private val context: Context
) {
    enum class MicOwner {
        NONE,
        WAKE_ENGINE,
        COMMAND_RECOGNIZER,
        FOLLOW_UP_RECOGNIZER
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _currentOwner = MutableStateFlow(MicOwner.NONE)
    val currentOwner: StateFlow<MicOwner> = _currentOwner.asStateFlow()

    private val _isMicrophoneActive = MutableStateFlow(false)
    val isMicrophoneActive: StateFlow<Boolean> = _isMicrophoneActive.asStateFlow()

    @Synchronized
    fun requestMicOwnership(requestedOwner: MicOwner): Boolean {
        if (_currentOwner.value == requestedOwner) {
            return true
        }

        Log.d(TAG, "Requesting mic ownership for $requestedOwner (current: ${_currentOwner.value})")

        // Release existing owner if any
        if (_currentOwner.value != MicOwner.NONE) {
            Log.d(TAG, "Preempting previous owner: ${_currentOwner.value}")
        }

        // Request audio focus
        requestAudioFocus()

        _currentOwner.value = requestedOwner
        _isMicrophoneActive.value = true
        return true
    }

    @Synchronized
    fun releaseMicOwnership(owner: MicOwner) {
        if (_currentOwner.value == owner) {
            Log.d(TAG, "Releasing mic ownership from $owner")
            _currentOwner.value = MicOwner.NONE
            _isMicrophoneActive.value = false
            abandonAudioFocus()
        }
    }

    @Synchronized
    fun forceReleaseAll() {
        Log.d(TAG, "Force releasing all microphone sessions and audio focus")
        _currentOwner.value = MicOwner.NONE
        _isMicrophoneActive.value = false
        abandonAudioFocus()
    }

    private fun requestAudioFocus() {
        try {
            audioManager?.let { am ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val playbackAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()

                    val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(playbackAttributes)
                        .setAcceptsDelayedFocusGain(false)
                        .setOnAudioFocusChangeListener { focusChange ->
                            Log.d(TAG, "AudioFocus changed: $focusChange")
                        }
                        .build()

                    audioFocusRequest = focusRequest
                    am.requestAudioFocus(focusRequest)
                } else {
                    @Suppress("DEPRECATION")
                    am.requestAudioFocus(
                        null,
                        AudioManager.STREAM_MUSIC,
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire AudioFocus", e)
        }
    }

    private fun abandonAudioFocus() {
        try {
            audioManager?.let { am ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                    audioFocusRequest = null
                } else {
                    @Suppress("DEPRECATION")
                    am.abandonAudioFocus(null)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not abandon AudioFocus", e)
        }
    }

    companion object {
        private const val TAG = "VoiceSessionManager"
    }
}
