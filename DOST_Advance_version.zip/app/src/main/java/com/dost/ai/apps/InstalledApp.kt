package com.dost.ai.apps

import android.graphics.drawable.Drawable

/**
 * Represents an installed Android application discovered on the user's device.
 *
 * @param appLabel The human-readable application name (e.g., "YouTube", "WhatsApp", "Chrome").
 * @param packageName The unique Android package name (e.g., "com.google.android.youtube").
 * @param className Optional launch activity class name.
 * @param isLaunchable Whether the application has a valid launcher activity that can be started.
 * @param isSystemApp Whether this application is an Android pre-installed system application.
 * @param iconDrawable Optional icon drawable for display in clarification cards / app pickers.
 */
data class InstalledApp(
    val appLabel: String,
    val packageName: String,
    val className: String? = null,
    val isLaunchable: Boolean = true,
    val isSystemApp: Boolean = false,
    val iconDrawable: Drawable? = null
)
