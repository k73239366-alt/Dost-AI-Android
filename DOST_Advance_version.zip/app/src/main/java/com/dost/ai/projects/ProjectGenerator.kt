package com.dost.ai.projects

import android.content.Context
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

data class ProjectFile(
    val filename: String,
    val content: String,
    val language: String
)

data class GeneratedProject(
    val title: String,
    val type: String, // "website", "game", "script"
    val description: String,
    val files: List<ProjectFile>,
    val instructions: String
)

/**
 * Base Project Generator:
 * Creates multi-file structures, READMEs, and runnable templates.
 */
open class ProjectGenerator : BaseTool {
    override val name: String = "GENERATE_CODE_PROJECT"
    override val description: String = "Generates multi-file websites, interactive games, or script projects."

    override fun validateParams(params: Map<String, Any?>): String? {
        val title = params["title"] as? String
        if (title.isNullOrBlank()) return "Project title is required."
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val title = (params["title"] as? String) ?: "New Project"
        val type = (params["type"] as? String) ?: "website"

        return ToolResult.success(
            name,
            "Project \"$title\" ($type) generate kar diya gaya hai.",
            mapOf("title" to title, "type" to type)
        )
    }
}

/**
 * Generates clean HTML, CSS, JavaScript websites (Portfolio, Landing Page, Calculator, Quiz, Todo).
 */
class WebProjectGenerator : ProjectGenerator() {
    override val name: String = "GENERATE_WEB_PROJECT"
    override val description: String = "Generates full web applications with HTML, CSS, and modern JavaScript."

    fun generateStarterTemplate(projectType: String): GeneratedProject {
        return when (projectType.lowercase()) {
            "calculator" -> GeneratedProject(
                title = "Clean Modern Calculator",
                type = "website",
                description = "Modern glassmorphism calculator with keyboard and touch support.",
                files = listOf(
                    ProjectFile("index.html", "<!DOCTYPE html>\n<html>\n<head><title>Calculator</title><link rel='stylesheet' href='style.css'></head>\n<body><div id='calc'><input id='display' readonly><div class='keys'>...</div></div><script src='app.js'></script></body></html>", "html"),
                    ProjectFile("style.css", "body { font-family: sans-serif; background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }", "css"),
                    ProjectFile("app.js", "let display = document.getElementById('display'); function append(val) { display.value += val; } function calculate() { try { display.value = eval(display.value); } catch(e) { display.value = 'Error'; } }", "javascript")
                ),
                instructions = "Open index.html in any modern browser to run."
            )
            else -> GeneratedProject(
                title = "Responsive Portfolio",
                type = "website",
                description = "Clean modern personal portfolio with dark mode.",
                files = listOf(
                    ProjectFile("index.html", "<!DOCTYPE html>\n<html><head><title>My Portfolio</title><link rel='stylesheet' href='style.css'></head><body><h1>Welcome to My Portfolio</h1><p>Created with DOST</p></body></html>", "html"),
                    ProjectFile("style.css", "body { font-family: system-ui; background: #121212; color: #f0f0f0; margin: 0; padding: 2rem; }", "css"),
                    ProjectFile("app.js", "console.log('Portfolio loaded');", "javascript")
                ),
                instructions = "Edit index.html to customize your personal links and bio."
            )
        }
    }
}

/**
 * Generates playable browser/canvas games (Tic Tac Toe, Snake, Memory, Pong).
 */
class GameProjectGenerator : ProjectGenerator() {
    override val name: String = "GENERATE_GAME_PROJECT"
    override val description: String = "Generates playable web games with responsive controls."
}
