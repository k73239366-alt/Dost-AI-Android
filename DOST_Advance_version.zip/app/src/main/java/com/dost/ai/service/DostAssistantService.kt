package com.dost.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.dost.ai.MainActivity
import com.dost.ai.R
import com.dost.ai.wake.SystemSpeechWakeWordEngine
import com.dost.ai.wake.WakeWordEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground Service for DOST 2.0 Background Assistant & Wake Listening.
 *
 * Fully compliant with Android Foreground Service rules:
 * - Requires explicit user enablement via Settings
 * - Displays a non-dismissible persistent notification with status and clear controls
 * - Discloses microphone usage under Android 14+ (FOREGROUND_SERVICE_TYPE_MICROPHONE)
 * - Exposes actions: "Pause", "Stop DOST", "Open DOST"
 * - Automatically halts and releases microphone upon stopping
 */
class DostAssistantService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): DostAssistantService = this@DostAssistantService
    }

    private val binder = LocalBinder()
    private var wakeWordEngine: WakeWordEngine? = null

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _isWakeListening = MutableStateFlow(false)
    val isWakeListening: StateFlow<Boolean> = _isWakeListening.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    var onWakeWordDetectedListener: ((String) -> Unit)? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "DostAssistantService onCreate")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        Log.d(TAG, "onStartCommand action: $action")

        when (action) {
            ACTION_STOP_SERVICE -> {
                stopAssistant()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                pauseWakeListening()
            }
            ACTION_RESUME -> {
                resumeWakeListening()
            }
            ACTION_START_WAKE_LISTENING -> {
                startForegroundWithNotification("DOST is ready", "Wake Listening Active · Say 'Dost'")
                startWakeEngine()
            }
            else -> {
                // Default start foreground
                startForegroundWithNotification("DOST is ready", "Background Assistant Active")
                startWakeEngine()
            }
        }

        return START_STICKY
    }

    private fun startForegroundWithNotification(title: String, text: String) {
        val notification = buildNotification(title, text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        _isServiceRunning.value = true
    }

    private fun startWakeEngine() {
        if (wakeWordEngine == null) {
            wakeWordEngine = SystemSpeechWakeWordEngine().apply {
                initialize(
                    context = applicationContext,
                    onWakeDetected = { phrase ->
                        Log.i(TAG, "Wake word detected in background service: $phrase")
                        updateNotification("DOST Wake Detected", "Listening for command...")
                        onWakeWordDetectedListener?.invoke(phrase)
                        broadcastWakeDetected(phrase)
                    },
                    onError = { error ->
                        Log.w(TAG, "Wake word error in background service: $error")
                        updateNotification("DOST Assistant", error)
                    }
                )
            }
        }
        wakeWordEngine?.startListening()
        _isWakeListening.value = true
        _isPaused.value = false
    }

    private fun pauseWakeListening() {
        _isPaused.value = true
        _isWakeListening.value = false
        wakeWordEngine?.pause()
        updateNotification("DOST is paused", "Wake listening temporarily paused")
    }

    private fun resumeWakeListening() {
        _isPaused.value = false
        _isWakeListening.value = true
        wakeWordEngine?.resume()
        updateNotification("DOST is ready", "Wake Listening Active · Say 'Dost'")
    }

    fun stopAssistant() {
        _isWakeListening.value = false
        _isPaused.value = false
        _isServiceRunning.value = false
        wakeWordEngine?.stopListening()
        wakeWordEngine?.release()
        wakeWordEngine = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun broadcastWakeDetected(phrase: String) {
        val intent = Intent(ACTION_WAKE_DETECTED_BROADCAST).apply {
            putExtra(EXTRA_WAKE_PHRASE, phrase)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun buildNotification(title: String, contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, DostAssistantService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeIntent = Intent(this, DostAssistantService::class.java).apply {
            action = if (_isPaused.value) ACTION_RESUME else ACTION_PAUSE
        }
        val pauseResumePendingIntent = PendingIntent.getService(
            this,
            2,
            pauseResumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeActionText = if (_isPaused.value) "Resume" else "Pause"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Open", openAppPendingIntent)
            .addAction(0, pauseResumeActionText, pauseResumePendingIntent)
            .addAction(0, "Stop", stopPendingIntent)
            .build()
    }

    private fun updateNotification(title: String, contentText: String) {
        val notification = buildNotification(title, contentText)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DOST Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status and control actions for DOST background wake listening"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "DostAssistantService onDestroy")
        stopAssistant()
    }

    companion object {
        const val TAG = "DostAssistantService"
        const val CHANNEL_ID = "dost_assistant_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_WAKE_LISTENING = "com.dost.ai.action.START_WAKE_LISTENING"
        const val ACTION_STOP_SERVICE = "com.dost.ai.action.STOP_SERVICE"
        const val ACTION_PAUSE = "com.dost.ai.action.PAUSE"
        const val ACTION_RESUME = "com.dost.ai.action.RESUME"

        const val ACTION_WAKE_DETECTED_BROADCAST = "com.dost.ai.action.WAKE_DETECTED"
        const val EXTRA_WAKE_PHRASE = "extra_wake_phrase"
    }
}
