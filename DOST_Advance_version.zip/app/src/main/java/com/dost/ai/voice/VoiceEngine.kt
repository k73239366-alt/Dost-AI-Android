package com.dost.ai.voice

import kotlinx.coroutines.flow.StateFlow

/**
 * Abstraction for Text-To-Speech output engines.
 * Keeps architecture decoupled for future high-fidelity TTS models.
 */
interface VoiceEngine {

    val isSpeaking: Boolean

    val voiceDebugState: StateFlow<VoiceDebugState>

    fun speak(
        text: String,
        speechRate: Float = 1.0f,
        pitch: Float = 1.0f,
        language: String = "Auto",
        onDone: () -> Unit = {},
        onComplete: () -> Unit = onDone
    )

    fun stop()

    fun shutdown()

    fun setPitch(pitch: Float)

    fun setSpeechRate(rate: Float)

    fun setVoice(voiceId: String?)

    fun getAvailableVoices(): List<TTSVoiceInfo>

    fun isHindiVoiceAvailable(): Boolean
}
