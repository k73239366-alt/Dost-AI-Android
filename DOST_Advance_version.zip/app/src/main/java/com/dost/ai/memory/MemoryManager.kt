package com.dost.ai.memory

import android.content.Context
import android.content.SharedPreferences
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class MemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String, // "preference", "project", "personal_fact", "style"
    val fact: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * DOST Memory Manager:
 * Distinguishes transient conversation context from user-controlled persistent memory.
 *
 * User controls:
 * - "Remember this: I love robotics."
 * - "What do you remember about me?"
 * - "Forget this / Clear memory."
 */
class MemoryManager(private val context: Context) : BaseTool {
    override val name: String = "MANAGE_MEMORY"
    override val description: String = "Stores, retrieves, and clears user-authorized persistent facts and preferences."

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_memory_prefs", Context.MODE_PRIVATE)

    override fun validateParams(params: Map<String, Any?>): String? {
        val action = (params["action"] as? String)?.lowercase() ?: "retrieve"
        if (action == "store" && (params["fact"] as? String).isNullOrBlank()) {
            return "Memory fact cannot be empty."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val action = (params["action"] as? String)?.lowercase() ?: "retrieve"
        return when (action) {
            "store" -> {
                val fact = (params["fact"] as? String)?.trim() ?: ""
                val category = (params["category"] as? String)?.trim() ?: "preference"
                val item = MemoryItem(category = category, fact = fact)
                val all = getAllMemories().toMutableList()
                all.add(item)
                saveAll(all)
                ToolResult.success(name, "Maine yeh yaad rakh liya hai: \"$fact\"", mapOf("memoryId" to item.id))
            }
            "retrieve", "list" -> {
                val all = getAllMemories()
                if (all.isEmpty()) {
                    ToolResult.success(name, "Mujhe abhi tak aapke baare me koi vishesh memory save nahi hai.", mapOf("count" to 0))
                } else {
                    val summary = all.joinToString("\n• ") { it.fact }
                    ToolResult.success(name, "Mujhe yaad hai:\n• $summary", mapOf("count" to all.size))
                }
            }
            "clear" -> {
                prefs.edit().remove("memories_json").apply()
                ToolResult.success(name, "Aapki saari saved memories poori tarah clear kar di gayi hain.", mapOf("cleared" to true))
            }
            "forget" -> {
                val query = (params["query"] as? String)?.lowercase() ?: ""
                val all = getAllMemories().filter { !it.fact.lowercase().contains(query) }
                saveAll(all)
                ToolResult.success(name, "Relevant memory remove kar di gayi hai.")
            }
            else -> ToolResult.failure(name, "Unknown memory action: $action")
        }
    }

    fun getAllMemories(): List<MemoryItem> {
        val raw = prefs.getString("memories_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<MemoryItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                MemoryItem(
                    id = obj.getString("id"),
                    category = obj.getString("category"),
                    fact = obj.getString("fact"),
                    timestamp = obj.getLong("timestamp")
                )
            )
        }
        return list
    }

    private fun saveAll(list: List<MemoryItem>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("category", m.category)
                    put("fact", m.fact)
                    put("timestamp", m.timestamp)
                }
            )
        }
        prefs.edit().putString("memories_json", arr.toString()).apply()
    }
}
