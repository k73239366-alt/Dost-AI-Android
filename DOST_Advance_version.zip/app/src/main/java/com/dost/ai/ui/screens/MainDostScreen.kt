package com.dost.ai.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.data.model.AssistantState
import com.dost.ai.ui.components.*
import com.dost.ai.ui.theme.DostBorder
import com.dost.ai.ui.theme.DostDarkBackground
import com.dost.ai.ui.theme.DostTextSecondary
import com.dost.ai.viewmodel.MainViewModel

/**
 * DOST 2.0 Redesigned Main Assistant Screen.
 *
 * Integrated visual hierarchy:
 * 1. TOP APP BAR (Identity, live status, settings)
 * 2. AI IDENTITY & ANIMATED EYE (Centerpiece)
 * 3. CURRENT STATUS (Clean single message)
 * 4. QUICK ACTIONS (Minimal suggestion chips)
 * 5. CONVERSATION AREA (Distinguished bubbles, smooth scrolling)
 * 6. MESSAGE INPUT AREA (Fixed bottom, expandable multiline, mic, send, stop)
 */
@Composable
fun DostAppScreen(
    viewModel: MainViewModel,
    onRequestRecordAudioPermission: () -> Unit
) {
    MainDostScreen(viewModel, onRequestRecordAudioPermission)
}

@Composable
fun MainDostScreen(
    viewModel: MainViewModel,
    onRequestRecordAudioPermission: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }

    // Synchronize live recognized transcript into input field so user can view/edit
    LaunchedEffect(uiState.currentSpeechTranscript, uiState.assistantState) {
        if (uiState.assistantState == AssistantState.LISTENING) {
            inputText = uiState.currentSpeechTranscript
        } else if (uiState.currentSpeechTranscript.isBlank() && uiState.assistantState != AssistantState.LISTENING) {
            if (inputText.isNotBlank() && uiState.messages.lastOrNull()?.text == inputText) {
                inputText = ""
            }
        }
    }

    // Automatically scroll conversation to latest message
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    // Full screen Settings View
    if (uiState.isSettingsOpen) {
        SettingsScreen(
            currentSettings = uiState.settings,
            availableVoices = viewModel.getAvailableVoices(),
            isHindiAvailable = viewModel.isHindiVoiceAvailable(),
            isVoiceSpeaking = uiState.isSpeaking,
            capabilityReport = uiState.capabilityReport,
            onPreviewVoice = { sampleType -> viewModel.previewVoice(sampleType) },
            onStopVoice = { viewModel.stopSpeaking() },
            onSaveSettings = { viewModel.updateSettings(it) },
            onToggleWakeListening = { viewModel.setWakeListening(it) },
            onToggleBackgroundAssistant = { viewModel.setBackgroundAssistant(it) },
            onOpenBatterySettings = { viewModel.openBatterySettings(context) },
            onStopDost = {
                viewModel.stopDost()
                viewModel.closeSettings()
            },
            onBack = { viewModel.closeSettings() }
        )
        return
    }

    Scaffold(
        containerColor = DostDarkBackground,
        topBar = {
            DostTopBar(
                assistantState = uiState.assistantState,
                isDebugModeEnabled = uiState.settings.debugModeEnabled,
                onToggleDebugMode = { viewModel.toggleDebugMode() },
                onOpenSettings = { viewModel.openSettings() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = paddingValues.calculateTopPadding())
                .background(DostDarkBackground)
        ) {
            // Optional Debug Monitor Overlay (Only visible when explicitly enabled in Settings)
            AnimatedVisibility(visible = uiState.settings.debugModeEnabled) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DEBUG MONITOR (STT, AI & APPS)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF10B981)
                            )
                            TextButton(
                                onClick = { viewModel.refreshInstalledApps() },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("Rescan Apps", fontSize = 10.sp, color = Color(0xFF38BDF8))
                            }
                        }
                        Text(
                            text = "State: ${uiState.assistantState} | Recog: ${uiState.debugInfo.recognitionState}",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "Speech: ${uiState.currentSpeechTranscript.ifBlank { uiState.debugInfo.finalText.ifBlank { "(idle)" } }}",
                            fontSize = 10.sp,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            text = "Intent: ${uiState.debugInfo.detectedIntent} | Apps: ${uiState.debugInfo.discoveredAppCount}",
                            fontSize = 10.sp,
                            color = Color(0xFFA78BFA)
                        )
                    }
                }
            }

            // Central AI Identity Area: DOST Animated Eye + Clean Status Message
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                horizontalAlignment = Alignment.CenterVertically
            ) {
                // Visual Centerpiece: Animated DOST Eye
                DostEye(
                    state = uiState.assistantState,
                    size = 118.dp,
                    onClick = {
                        if (uiState.assistantState == AssistantState.SPEAKING) {
                            viewModel.stopSpeaking()
                        } else if (uiState.assistantState == AssistantState.IDLE) {
                            onRequestRecordAudioPermission()
                            viewModel.startListening()
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // One clean status message below the eye
                DostStatus(
                    state = uiState.assistantState,
                    statusMessage = uiState.statusMessage
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Horizontal Quick Action Chips (3-4 small useful actions that do not dominate)
                QuickActionChips(
                    onActionSelected = { query ->
                        inputText = query
                    }
                )
            }

            // Error banner if any error occurred, with optional Retry button
            if (uiState.errorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B1216)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = uiState.errorMessage ?: "",
                            color = Color(0xFFFCA5A5),
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (uiState.canRetryLast) {
                            TextButton(onClick = { viewModel.retryLastMessage() }) {
                                Text("Retry", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Conversation Chat Area (Weights available vertical space, smooth scroll)
            ConversationList(
                messages = uiState.messages,
                isThinking = uiState.isThinking,
                listState = listState,
                onCopyText = { text ->
                    clipboardManager.setText(AnnotatedString(text))
                    Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                onLaunchApp = { app -> viewModel.launchApp(app) },
                onSearchPlayStore = { query -> viewModel.searchPlayStore(query) },
                onSearchWeb = { query -> viewModel.searchWeb(query) },
                modifier = Modifier.weight(1f)
            )

            // Fixed Bottom Input Area: [ Mic ] [ Expandable Multiline Input ] [ Send / Stop ]
            DostInputBar(
                inputText = inputText,
                onInputTextChange = { inputText = it },
                onSendMessage = {
                    val textToSend = inputText
                    inputText = ""
                    viewModel.sendMessage(textToSend)
                },
                onToggleMic = {
                    if (uiState.assistantState == AssistantState.LISTENING ||
                        uiState.assistantState == AssistantState.LISTENING_COMMAND ||
                        uiState.assistantState == AssistantState.FOLLOW_UP) {
                        viewModel.stopListeningAndSend()
                    } else {
                        onRequestRecordAudioPermission()
                        viewModel.startListening()
                    }
                },
                onStopActiveAction = {
                    if (uiState.assistantState == AssistantState.LISTENING ||
                        uiState.assistantState == AssistantState.LISTENING_COMMAND ||
                        uiState.assistantState == AssistantState.FOLLOW_UP) {
                        viewModel.cancelListening()
                    } else {
                        viewModel.stopSpeaking()
                    }
                },
                assistantState = uiState.assistantState
            )
        }
    }
}
