package com.dost.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.dost.ai.ui.screens.MainDostScreen
import com.dost.ai.ui.theme.DostTheme
import com.dost.ai.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Microphone enabled for DOST voice interaction", Toast.LENGTH_SHORT).show()
            viewModel.refreshCapabilityReport()
            if (viewModel.uiState.value.settings.wakeListeningEnabled) {
                viewModel.startWakeListening()
            }
        } else {
            Toast.makeText(this, "Microphone permission is required for speech recognition", Toast.LENGTH_LONG).show()
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        viewModel.refreshCapabilityReport()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check and request permissions if needed
        checkPermissions()

        setContent {
            DostTheme {
                MainDostScreen(
                    viewModel = viewModel,
                    onRequestRecordAudioPermission = { checkMicrophonePermission() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshCapabilityReport()
    }

    private fun checkPermissions() {
        checkMicrophonePermission()
        checkNotificationPermission()
    }

    private fun checkMicrophonePermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                // Permission already granted
            }
            else -> {
                requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
