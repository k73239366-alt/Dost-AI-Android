package com.dost.ai.settings

data class DostSettings(
    val voiceResponsesEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val language: String = "Auto", // "Auto", "Hindi", "English"
    val selectedVoiceId: String? = null, // null or empty for Auto
    val speedPreset: String = "Normal", // "Slow" (0.85x), "Normal" (1.0x), "Fast" (1.15x)
    val pitchPreset: String = "Normal", // "Low" (0.9x), "Normal" (1.0x), "High" (1.1x)
    val debugModeEnabled: Boolean = false,
    val theme: String = "Dark", // "Dark", "System"
    val serverBaseUrl: String = "https://ais-dev-iov64pbpvf7fnwhjxokl5q-852504415192.asia-east1.run.app",
    // Phase 2: Wake Listening and Background Assistant
    val wakeListeningEnabled: Boolean = false,
    val backgroundAssistantEnabled: Boolean = false,
    val followUpModeEnabled: Boolean = true,
    val followUpDurationSeconds: Int = 5, // 5, 10, 20, 30
    val wakeAcknowledgementEnabled: Boolean = true,
    val wakeAcknowledgementPhrase: String = "Ha, bolo." // "Ha, bolo.", "Yes?", "I'm listening."
)
