package com.dost.ai.wake

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * System-supported Wake Word Engine using Android SpeechRecognizer.
 *
 * Listens specifically for DOST wake phrases ("dost", "hey dost", "hello dost").
 * When detected, immediately halts recognition, releases audio resources, and notifies callbacks.
 *
 * Safety features:
 * - Exponential backoff on transient errors (no rapid restart loops)
 * - Maximum retry ceiling before entering PAUSED state
 * - Clean teardown and release on pause/stop
 */
class SystemSpeechWakeWordEngine : WakeWordEngine, RecognitionListener {

    override val engineName: String = "System Speech Wake Engine"
    override var isListening: Boolean = false
        private set

    override val implementationStatus: WakeEngineStatus = WakeEngineStatus.IMPLEMENTED

    private var context: Context? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onWakeDetectedCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private var consecutiveErrors = 0
    private val maxConsecutiveErrors = 5
    private var isPaused = false

    private val wakePhrases = listOf("dost", "hey dost", "hello dost", "arey dost", "oye dost")

    override fun initialize(
        context: Context,
        onWakeDetected: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        this.context = context
        this.onWakeDetectedCallback = onWakeDetected
        this.onErrorCallback = onError
    }

    override fun startListening() {
        if (isListening || isPaused) return
        val ctx = context ?: return

        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onErrorCallback?.invoke("System SpeechRecognizer is not available for wake detection.")
            return
        }

        handler.post {
            try {
                releaseRecognizer()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
                    setRecognitionListener(this@SystemSpeechWakeWordEngine)
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                }

                speechRecognizer?.startListening(intent)
                isListening = true
                Log.d(TAG, "SystemSpeechWakeWordEngine: started wake listening.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start wake listening", e)
                isListening = false
                handleRestart(true)
            }
        }
    }

    override fun stopListening() {
        isListening = false
        handler.removeCallbacksAndMessages(null)
        handler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping recognizer", e)
            } finally {
                releaseRecognizer()
            }
        }
    }

    override fun pause() {
        isPaused = true
        stopListening()
    }

    override fun resume() {
        isPaused = false
        consecutiveErrors = 0
        startListening()
    }

    override fun release() {
        stopListening()
        context = null
        onWakeDetectedCallback = null
        onErrorCallback = null
    }

    private fun releaseRecognizer() {
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying recognizer", e)
        }
        speechRecognizer = null
    }

    private fun handleRestart(isError: Boolean) {
        if (!isListening || isPaused) return

        if (isError) {
            consecutiveErrors++
            if (consecutiveErrors >= maxConsecutiveErrors) {
                Log.w(TAG, "Max consecutive wake errors reached ($maxConsecutiveErrors). Pausing wake listening.")
                isListening = false
                onErrorCallback?.invoke("Wake listening paused after repeated errors. Tap to resume.")
                return
            }
        } else {
            consecutiveErrors = 0
        }

        // Backoff delay before reconnecting (e.g. 800ms)
        val delayMs = if (isError) (consecutiveErrors * 1000L).coerceAtMost(5000L) else 400L
        handler.postDelayed({
            if (isListening && !isPaused) {
                try {
                    val ctx = context ?: return@postDelayed
                    releaseRecognizer()
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
                        setRecognitionListener(this@SystemSpeechWakeWordEngine)
                    }
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    }
                    speechRecognizer?.startListening(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Error restarting wake listening loop", e)
                }
            }
        }, delayMs)
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}

    override fun onError(errorCode: Int) {
        // Error codes 6 (Speech timeout) and 7 (No match) are normal in continuous wake listening
        val isBenign = errorCode == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || errorCode == SpeechRecognizer.ERROR_NO_MATCH
        Log.d(TAG, "SystemSpeechWakeWordEngine onError: $errorCode (benign=$isBenign)")
        handleRestart(!isBenign)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        if (checkMatchesForWake(matches)) {
            return
        }
        handleRestart(false)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        checkMatchesForWake(matches)
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun checkMatchesForWake(matches: List<String>): Boolean {
        for (match in matches) {
            val text = match.trim().lowercase()
            for (phrase in wakePhrases) {
                if (text.startsWith(phrase) || text.contains(phrase)) {
                    Log.i(TAG, "Wake phrase detected: '$phrase' in '$text'")
                    // Stop listening immediately to release microphone
                    stopListening()
                    onWakeDetectedCallback?.invoke(phrase)
                    return true
                }
            }
        }
        return false
    }

    companion object {
        private const val TAG = "SystemSpeechWakeEngine"
    }
}
