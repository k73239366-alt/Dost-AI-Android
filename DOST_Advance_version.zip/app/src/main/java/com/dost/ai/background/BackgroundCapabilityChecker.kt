package com.dost.ai.background

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Diagnostic utility to evaluate whether the host device and OS version
 * can legitimately support background microphone and wake listening operations.
 */
class BackgroundCapabilityChecker(
    private val context: Context
) {
    enum class CapabilityLevel {
        SUPPORTED,
        PARTIALLY_SUPPORTED,
        RESTRICTED,
        UNSUPPORTED
    }

    data class DeviceCapabilityReport(
        val level: CapabilityLevel,
        val summary: String,
        val details: List<String>,
        val isBatteryOptimizationIgnored: Boolean,
        val isAudioPermissionGranted: Boolean,
        val isForegroundServiceAllowed: Boolean,
        val manufacturerNotice: String?
    )

    fun checkCapabilities(): DeviceCapabilityReport {
        val details = mutableListOf<String>()

        // 1. Microphone Permission
        val hasAudioPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudioPermission) {
            details.add("Microphone permission: GRANTED")
        } else {
            details.add("Microphone permission: NOT GRANTED (Required for wake detection)")
        }

        // 2. Battery Optimization
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isBatteryOptimized = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        } else {
            true
        }

        if (isBatteryOptimized) {
            details.add("Battery optimization: EXEMPT (DOST can maintain active foreground service)")
        } else {
            details.add("Battery optimization: ACTIVE (Android system may pause background microphone after screen off)")
        }

        // 3. Android Version Foreground Service Policy
        val isForegroundServicePermitted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // Android 14+ requires FOREGROUND_SERVICE_MICROPHONE
            val hasMicrophoneFgs = ContextCompat.checkSelfPermission(
                context,
                "android.permission.FOREGROUND_SERVICE_MICROPHONE"
            ) == PackageManager.PERMISSION_GRANTED
            details.add("Android 14+ Microphone FGS Permission: ${if (hasMicrophoneFgs) "GRANTED" else "PENDING"}")
            hasMicrophoneFgs
        } else {
            true
        }

        // 4. Manufacturer aggressive battery-killer detection
        val manufacturer = Build.MANUFACTURER.lowercase()
        val manufacturerNotice = when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") ->
                "Xiaomi/MIUI aggressive background task management detected. You may need to enable 'Autostart' and set Battery Saver to 'No restrictions' in device App info."
            manufacturer.contains("huawei") || manufacturer.contains("honor") ->
                "Huawei EMUI battery saver detected. Add DOST to 'Protected Apps' to prevent OS from killing wake listening."
            manufacturer.contains("samsung") ->
                "Samsung One UI detected. Ensure DOST is added to 'Never sleeping apps' in Device Care settings."
            manufacturer.contains("oppo") || manufacturer.contains("realme") || manufacturer.contains("vivo") ->
                "ColorOS/FuntouchOS aggressive killer detected. Enable 'Allow background activity' in Battery settings."
            else -> null
        }

        if (manufacturerNotice != null) {
            details.add(manufacturerNotice)
        }

        // 5. Evaluate overall Capability Level
        val level: CapabilityLevel
        val summary: String

        if (!hasAudioPermission) {
            level = CapabilityLevel.RESTRICTED
            summary = "Microphone permission is required before wake listening can operate."
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && !isBatteryOptimized) {
            level = CapabilityLevel.PARTIALLY_SUPPORTED
            summary = "Foreground service supported while active; screen-off listening may be interrupted by Android battery saver without battery optimization exemption."
        } else if (manufacturerNotice != null && !isBatteryOptimized) {
            level = CapabilityLevel.RESTRICTED
            summary = "Manufacturer OEM policy restricts screen-off microphone capture unless explicitly exempted by user in system settings."
        } else {
            level = CapabilityLevel.SUPPORTED
            summary = "Foreground service and wake word listening are fully supported under legitimate Android rules."
        }

        return DeviceCapabilityReport(
            level = level,
            summary = summary,
            details = details,
            isBatteryOptimizationIgnored = isBatteryOptimized,
            isAudioPermissionGranted = hasAudioPermission,
            isForegroundServiceAllowed = isForegroundServicePermitted,
            manufacturerNotice = manufacturerNotice
        )
    }
}
