package com.dost.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dost.ai.data.model.AssistantState
import kotlin.math.cos
import kotlin.math.sin

/**
 * Original DOST AI Eye Core.
 *
 * Visual Identity:
 * - Dark circular center (deep obsidian core)
 * - Original red geometric patterns (concentric tech rings, triangular aperture nodes, precision tick marks)
 * - Subtle crimson glow
 * - Slow rotation and state-reactive kinetic behaviors:
 *   - IDLE: Calm, slow rotation and subtle breathing glow
 *   - LISTENING: Expanded sensory aperture with responsive ring oscillation
 *   - THINKING: Smooth counter-rotating dual rings and processing node orbits
 *   - SPEAKING: Gentle rhythmic pulsing synchronized with speech cadence
 *   - ERROR: Deep ruby warning glow returning safely to calm
 */
@Composable
fun DostEyeCore(
    state: AssistantState,
    modifier: Modifier = Modifier,
    size: Dp = 160.dp,
    onClick: () -> Unit = {}
) {
    val transition = rememberInfiniteTransition(label = "DostEyeTransition")

    // Slow rotation animation
    val primaryRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.THINKING, AssistantState.PROCESSING, AssistantState.EXECUTING -> 3500
                    AssistantState.SUCCESS, AssistantState.WAKE_DETECTED -> 2000
                    AssistantState.LISTENING, AssistantState.LISTENING_COMMAND, AssistantState.FOLLOW_UP -> 6000
                    AssistantState.SPEAKING -> 8000
                    AssistantState.WAKE_LISTENING, AssistantState.BACKGROUND_READY -> 16000
                    AssistantState.PAUSED, AssistantState.STOPPED -> 24000
                    else -> 14000 // Slow and calm in IDLE
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "PrimaryRotation"
    )

    // Counter rotation for inner geometric pattern
    val secondaryRotation by transition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.THINKING, AssistantState.PROCESSING, AssistantState.EXECUTING -> 4500
                    AssistantState.SUCCESS, AssistantState.WAKE_DETECTED -> 2500
                    AssistantState.LISTENING, AssistantState.LISTENING_COMMAND, AssistantState.FOLLOW_UP -> 7000
                    AssistantState.SPEAKING -> 9000
                    AssistantState.WAKE_LISTENING, AssistantState.BACKGROUND_READY -> 20000
                    AssistantState.PAUSED, AssistantState.STOPPED -> 30000
                    else -> 18000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "SecondaryRotation"
    )

    // Breathing / Pulsing animation
    val pulseScale by transition.animateFloat(
        initialValue = 0.94f,
        targetValue = when (state) {
            AssistantState.SPEAKING -> 1.14f
            AssistantState.LISTENING, AssistantState.LISTENING_COMMAND -> 1.10f
            AssistantState.FOLLOW_UP, AssistantState.WAKE_DETECTED -> 1.11f
            AssistantState.THINKING -> 1.05f
            AssistantState.PROCESSING, AssistantState.EXECUTING -> 1.08f
            AssistantState.SUCCESS -> 1.12f
            AssistantState.ERROR -> 1.08f
            AssistantState.WAKE_LISTENING, AssistantState.BACKGROUND_READY -> 1.03f
            AssistantState.PAUSED, AssistantState.STOPPED -> 0.98f
            AssistantState.IDLE -> 1.02f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.SPEAKING -> 750
                    AssistantState.LISTENING, AssistantState.LISTENING_COMMAND -> 1200
                    AssistantState.FOLLOW_UP -> 1100
                    AssistantState.WAKE_DETECTED -> 500
                    AssistantState.THINKING -> 1000
                    AssistantState.PROCESSING, AssistantState.EXECUTING -> 600
                    AssistantState.SUCCESS -> 500
                    AssistantState.ERROR -> 900
                    AssistantState.WAKE_LISTENING, AssistantState.BACKGROUND_READY -> 3000
                    AssistantState.PAUSED, AssistantState.STOPPED -> 4000
                    AssistantState.IDLE -> 2600
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // Core Colors: Original Red Geometric Identity
    val crimsonRed = Color(0xFFEF4444)
    val brightRuby = Color(0xFFFF2E56)
    val deepDarkRed = Color(0xFF881337)
    val coreObsidian = Color(0xFF070506)

    Box(
        modifier = modifier
            .size(size)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2.5f) * pulseScale

            // 1. Subtle Atmospheric Red Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        crimsonRed.copy(alpha = if (state == AssistantState.SPEAKING || state == AssistantState.LISTENING) 0.35f else 0.20f),
                        deepDarkRed.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.6f
                ),
                radius = baseRadius * 1.6f,
                center = center
            )

            // 2. Outer Segmented Geometric Optical Ring
            rotate(primaryRotation, pivot = center) {
                drawCircle(
                    color = crimsonRed.copy(alpha = 0.45f),
                    radius = baseRadius * 1.22f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 22f, 32f, 22f), 0f)
                    )
                )

                // 4 Cardinal Precision Tick Markers
                for (i in 0 until 4) {
                    val angle = (i * 90.0) * (Math.PI / 180.0)
                    val innerX = center.x + (baseRadius * 1.15f) * cos(angle).toFloat()
                    val innerY = center.y + (baseRadius * 1.15f) * sin(angle).toFloat()
                    val outerX = center.x + (baseRadius * 1.28f) * cos(angle).toFloat()
                    val outerY = center.y + (baseRadius * 1.28f) * sin(angle).toFloat()

                    drawLine(
                        color = brightRuby.copy(alpha = 0.8f),
                        start = Offset(innerX, innerY),
                        end = Offset(outerX, outerY),
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Dark Circular Iris Center Base
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1F1115),
                        coreObsidian,
                        Color(0xFF030203)
                    ),
                    center = center,
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // 4. Inner Original Red Geometric Patterns
            // Concentric red boundary ring
            drawCircle(
                color = brightRuby.copy(alpha = 0.75f),
                radius = baseRadius * 0.82f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Counter-rotating triangular geometric aperture nodes
            rotate(secondaryRotation, pivot = center) {
                // Draw 3 geometric diamond/chevron sectors
                for (i in 0 until 3) {
                    val angleDeg = i * 120f
                    val angleRad = angleDeg * (Math.PI / 180.0)
                    val nodeRadius = baseRadius * 0.58f
                    val nodeCenter = Offset(
                        center.x + nodeRadius * cos(angleRad).toFloat(),
                        center.y + nodeRadius * sin(angleRad).toFloat()
                    )

                    // Small precision circular node
                    drawCircle(
                        color = brightRuby,
                        radius = 3.dp.toPx(),
                        center = nodeCenter
                    )

                    // Connecting geometric arc
                    val arcPath = Path().apply {
                        moveTo(nodeCenter.x, nodeCenter.y)
                        val nextAngle = (angleDeg + 60f) * (Math.PI / 180.0)
                        val controlPoint = Offset(
                            center.x + (baseRadius * 0.75f) * cos(nextAngle).toFloat(),
                            center.y + (baseRadius * 0.75f) * sin(nextAngle).toFloat()
                        )
                        lineTo(controlPoint.x, controlPoint.y)
                    }
                    drawPath(
                        path = arcPath,
                        color = crimsonRed.copy(alpha = 0.6f),
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                }

                // Inner geometric hexagonal tick circle
                drawCircle(
                    color = deepDarkRed.copy(alpha = 0.7f),
                    radius = baseRadius * 0.42f,
                    center = center,
                    style = Stroke(
                        width = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )
            }

            // 5. Central Deep Obsidian Pupil with Crimson Specular Glint
            val pupilRadius = baseRadius * 0.28f
            drawCircle(
                color = coreObsidian,
                radius = pupilRadius,
                center = center
            )
            drawCircle(
                color = brightRuby.copy(alpha = 0.9f),
                radius = pupilRadius * 0.35f,
                center = center
            )
            // Tiny white core specular point
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = 1.5.dp.toPx(),
                center = Offset(center.x - pupilRadius * 0.25f, center.y - pupilRadius * 0.25f)
            )
        }
    }
}
