package com.dost.ai.screen

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Screen Understanding Manager:
 *
 * Requirements:
 * - Explain what is on screen
 * - Extract text / explain error dialogs
 * - Privacy: Explicit user authorization required
 * - Visible screen-sharing state (activeStateFlow)
 * - User can terminate at any time
 * - No secret monitoring
 */
class ScreenUnderstandingManager(private val context: Context) : BaseTool {
    override val name: String = "SCREEN_ANALYSIS"
    override val description: String = "Analyzes active screen content with explicit user authorization."
    override val requiresConfirmation: Boolean = true

    private val _isScreenSharingActive = MutableStateFlow(false)
    val isScreenSharingActive: StateFlow<Boolean> = _isScreenSharingActive.asStateFlow()

    override fun validateParams(params: Map<String, Any?>): String? = null

    /**
     * Creates intent for requesting screen capture permission via MediaProjectionManager.
     */
    fun createScreenCaptureIntent(): Intent? {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        return manager?.createScreenCaptureIntent()
    }

    fun onScreenCaptureGranted(data: Intent) {
        _isScreenSharingActive.value = true
    }

    fun stopScreenSharing() {
        _isScreenSharingActive.value = false
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val authorized = (params["userAuthorized"] as? Boolean) ?: false
        if (!authorized && !_isScreenSharingActive.value) {
            return ToolResult.confirmationRequired(
                name,
                "DOST ko screen content analyze karne ke liye aapki permission ki zaroorat hai. Kya aap allow karna chahte hain?",
                mapOf("requiresMediaProjection" to true)
            )
        }

        return ToolResult.success(
            name,
            "Screen capture analysis active hai. DOST screen par dikh rahe content ko samajh raha hai.",
            mapOf("active" to true)
        )
    }
}

/**
 * Controller for user-authorized screen interactions.
 * Strictly checks accessibility permissions and does not perform secret gestures.
 */
class ScreenInteractionController(private val context: Context) {
    fun isAccessibilityEnabled(): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
        return am?.isEnabled == true
    }

    fun promptEnableAccessibility(): Intent {
        return Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }
}
