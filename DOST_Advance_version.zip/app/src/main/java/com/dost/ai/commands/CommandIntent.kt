package com.dost.ai.commands

/**
 * Command Intent Types for DOST.
 *
 * Implements full Priority Hierarchy:
 * 1. STOP or CANCEL
 * 2. Emergency cancellation of active assistant operation
 * 3. Explicit device action (Camera, Settings)
 * 4. App command (Launch, Play Store Search)
 * 5. Communication command (Call, Message)
 * 6. Reminder and timer (Timer, Alarm, Reminder, Notes)
 * 7. Screen request (Screen Understanding)
 * 8. Web request (Web Search)
 * 9. Coding, Project, and Learning request
 * 10. Normal conversation
 */
enum class CommandIntent {
    STOP,
    OPEN_CAMERA,
    OPEN_SETTINGS,
    OPEN_APP,
    SEARCH_PLAY_STORE,
    SEARCH_WEB,
    SCREEN_ANALYSIS,
    SET_TIMER,
    CREATE_ALARM,
    CREATE_REMINDER,
    CREATE_NOTE,
    CALL_CONTACT,
    SEND_MESSAGE,
    CODING_HELP,
    GENERATE_PROJECT,
    LEARNING_HELP,
    MANAGE_MEMORY,
    NORMAL_CONVERSATION
}

/**
 * Detailed analysis result for a normalized user input.
 */
data class CommandAnalysis(
    val originalText: String,
    val normalizedText: String,
    val intent: CommandIntent,
    val targetAppName: String? = null,
    val normalizedAppName: String? = null,
    val originalUserRequest: String = originalText,
    val confidence: Float = 1.0f,
    val searchQuery: String? = null,
    val target: String? = targetAppName,
    val parameters: Map<String, Any?> = emptyMap(),
    val isSupportedInPhase1: Boolean = true
)
