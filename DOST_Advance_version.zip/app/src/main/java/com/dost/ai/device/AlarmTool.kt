package com.dost.ai.device

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult

/**
 * Standard Android alarm tool using AlarmClock.ACTION_SET_ALARM.
 */
class AlarmTool : BaseTool {
    override val name: String = "CREATE_ALARM"
    override val description: String = "Creates an Android system alarm at a specified hour and minute."

    override fun validateParams(params: Map<String, Any?>): String? {
        val hour = (params["hour"] as? Number)?.toInt()
        val minute = (params["minute"] as? Number)?.toInt() ?: 0
        if (hour == null || hour !in 0..23 || minute !in 0..59) {
            return "Valid hour (0-23) and minute (0-59) are required."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val hour = (params["hour"] as? Number)?.toInt() ?: 7
        val minute = (params["minute"] as? Number)?.toInt() ?: 0
        val message = (params["message"] as? String) ?: "DOST Alarm"

        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                val formattedTime = String.format("%02d:%02d", hour, minute)
                ToolResult.success(
                    name,
                    "$formattedTime baje ka alarm set kar diya gaya hai.",
                    mapOf("hour" to hour, "minute" to minute, "message" to message)
                )
            } else {
                ToolResult.failure(name, "Device clock app is not available.")
            }
        } catch (e: Exception) {
            ToolResult.failure(name, "Alarm set nahi ho saka: ${e.message}", e.message)
        }
    }
}
