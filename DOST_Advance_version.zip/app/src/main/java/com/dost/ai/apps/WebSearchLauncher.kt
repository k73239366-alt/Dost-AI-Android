package com.dost.ai.apps

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.dost.ai.commands.CommandResult
import com.dost.ai.commands.CommandStatus

/**
 * WebSearchLauncher: Safely opens standard web search for applications or queries.
 *
 * Adheres strictly to Section 12:
 * - Uses legitimate Android Intent.ACTION_WEB_SEARCH or browser fallback.
 * - Does NOT automatically download or side-load applications.
 * - Never claims success if intent dispatch fails.
 */
class WebSearchLauncher(private val context: Context) {

    companion object {
        private const val TAG = "WebSearchLauncher"
    }

    fun searchWeb(queryText: String): CommandResult {
        val query = queryText.trim()
        if (query.isBlank()) {
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Search query cannot be empty.",
                error = "Empty query"
            )
        }

        try {
            // Primary intent: Standard Android WEB_SEARCH
            val webSearchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (webSearchIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(webSearchIntent)
                Log.d(TAG, "Launched ACTION_WEB_SEARCH for: $query")
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Searching web for \"$query\".",
                    targetApp = query,
                    fallbackQuery = query
                )
            }

            // Fallback: ACTION_VIEW to Google Search in web browser
            val encodedQuery = Uri.encode(query)
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=$encodedQuery")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (browserIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(browserIntent)
                Log.d(TAG, "Launched browser search for: $query")
                return CommandResult(
                    status = CommandStatus.SUCCESS,
                    message = "Searching web for \"$query\".",
                    targetApp = query,
                    fallbackQuery = query
                )
            }

            return CommandResult(
                status = CommandStatus.FAILED,
                message = "No web browser is available to perform search.",
                targetApp = query,
                error = "Browser unavailable"
            )
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "ActivityNotFoundException during web search: ${e.message}")
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "No browser application found on this device.",
                targetApp = query,
                error = e.localizedMessage
            )
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error performing web search: ${e.message}", e)
            return CommandResult(
                status = CommandStatus.FAILED,
                message = "Could not perform web search: ${e.localizedMessage}",
                targetApp = query,
                error = e.localizedMessage
            )
        }
    }
}
