package com.dost.ai.voice

import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

/**
 * VoiceSelector: Selects the most natural, clear, and high-quality TTS voice
 * available on the Android device for Hindi, Hinglish, and English speech.
 */
object VoiceSelector {

    val LOCALE_HINDI_INDIA = Locale("hi", "IN")
    val LOCALE_ENGLISH_INDIA = Locale("en", "IN")
    val LOCALE_ENGLISH_US = Locale.US

    data class SelectionResult(
        val voice: Voice?,
        val fallbackLocale: Locale,
        val displayName: String,
        val isNativeHindi: Boolean,
        val isFallback: Boolean,
        val warningMessage: String? = null
    )

    /**
     * Finds and ranks the best available voice from the engine based on language intent.
     */
    fun selectVoice(
        targetLanguage: DetectedLanguage,
        tts: TextToSpeech?,
        userVoiceId: String? = null
    ): SelectionResult {
        if (tts == null) {
            return SelectionResult(
                voice = null,
                fallbackLocale = LOCALE_HINDI_INDIA,
                displayName = "Default Engine Voice",
                isNativeHindi = false,
                isFallback = true,
                warningMessage = "TTS engine not yet ready"
            )
        }

        val allVoices: Set<Voice>? = try {
            tts.voices
        } catch (e: Exception) {
            Log.w("DOST_VOICE", "Could not query TTS voices: ${e.message}")
            null
        }

        // 1. If user explicitly picked a specific voice ID in Settings, check if it is available
        if (!userVoiceId.isNullOrBlank() && userVoiceId != "auto" && allVoices != null) {
            val explicitMatch = allVoices.firstOrNull { it.name == userVoiceId }
            if (explicitMatch != null && isInstalled(explicitMatch)) {
                val isHindi = explicitMatch.locale.language.equals("hi", ignoreCase = true)
                return SelectionResult(
                    voice = explicitMatch,
                    fallbackLocale = explicitMatch.locale,
                    displayName = formatVoiceDisplayName(explicitMatch),
                    isNativeHindi = isHindi,
                    isFallback = false
                )
            }
        }

        // 2. Select best voice for target language
        return when (targetLanguage) {
            DetectedLanguage.HINDI, DetectedLanguage.HINGLISH -> {
                selectBestHindiVoice(tts, allVoices)
            }
            DetectedLanguage.ENGLISH -> {
                selectBestEnglishVoice(tts, allVoices)
            }
        }
    }

    private fun selectBestHindiVoice(
        tts: TextToSpeech,
        allVoices: Set<Voice>?
    ): SelectionResult {
        // A. If voices set is available, find best Hindi voice
        if (!allVoices.isNullOrEmpty()) {
            val installedHindiVoices = allVoices.filter { voice ->
                voice.locale.language.equals("hi", ignoreCase = true) && isInstalled(voice)
            }

            if (installedHindiVoices.isNotEmpty()) {
                // Rank voices: highest quality first, then prefer standard hi-IN, prefer lower latency
                val bestVoice = installedHindiVoices.maxWithOrNull(
                    compareBy<Voice> { it.quality }
                        .thenBy { if (it.locale.country.equals("IN", ignoreCase = true)) 1 else 0 }
                        .thenByDescending { it.latency } // Lower latency constant is better in Android Voice
                )

                if (bestVoice != null) {
                    return SelectionResult(
                        voice = bestVoice,
                        fallbackLocale = bestVoice.locale,
                        displayName = formatVoiceDisplayName(bestVoice),
                        isNativeHindi = true,
                        isFallback = false
                    )
                }
            }
        }

        // B. If no specific Voice object found, check if engine supports Hindi Locale directly
        val langStatus = try {
            tts.isLanguageAvailable(LOCALE_HINDI_INDIA)
        } catch (e: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        if (langStatus >= TextToSpeech.LANG_AVAILABLE) {
            return SelectionResult(
                voice = null,
                fallbackLocale = LOCALE_HINDI_INDIA,
                displayName = "Android Hindi (India)",
                isNativeHindi = true,
                isFallback = false
            )
        }

        // C. Hindi voice is completely missing on this device's speech engine!
        // Fall back gracefully to Indian English (en-IN) so pronunciation of Indian terms is as close as possible
        val enInStatus = try {
            tts.isLanguageAvailable(LOCALE_ENGLISH_INDIA)
        } catch (e: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        val fallbackLocale = if (enInStatus >= TextToSpeech.LANG_AVAILABLE) {
            LOCALE_ENGLISH_INDIA
        } else {
            Locale.getDefault()
        }

        return SelectionResult(
            voice = null,
            fallbackLocale = fallbackLocale,
            displayName = "Fallback: ${fallbackLocale.displayName}",
            isNativeHindi = false,
            isFallback = true,
            warningMessage = "Hindi voice is not installed in your device's TTS engine. For natural Hindi speech, install Hindi voice data in Android Settings."
        )
    }

    private fun selectBestEnglishVoice(
        tts: TextToSpeech,
        allVoices: Set<Voice>?
    ): SelectionResult {
        if (!allVoices.isNullOrEmpty()) {
            val installedEnglishVoices = allVoices.filter { voice ->
                voice.locale.language.equals("en", ignoreCase = true) && isInstalled(voice)
            }

            if (installedEnglishVoices.isNotEmpty()) {
                // Prefer Indian English (en-IN) for natural conversational cadence, or high quality US
                val bestVoice = installedEnglishVoices.maxWithOrNull(
                    compareBy<Voice> { if (it.locale.country.equals("IN", ignoreCase = true)) 2 else 1 }
                        .thenBy { it.quality }
                )

                if (bestVoice != null) {
                    return SelectionResult(
                        voice = bestVoice,
                        fallbackLocale = bestVoice.locale,
                        displayName = formatVoiceDisplayName(bestVoice),
                        isNativeHindi = false,
                        isFallback = false
                    )
                }
            }
        }

        val enInStatus = try {
            tts.isLanguageAvailable(LOCALE_ENGLISH_INDIA)
        } catch (e: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        val fallback = if (enInStatus >= TextToSpeech.LANG_AVAILABLE) LOCALE_ENGLISH_INDIA else LOCALE_ENGLISH_US

        return SelectionResult(
            voice = null,
            fallbackLocale = fallback,
            displayName = "English (${fallback.country})",
            isNativeHindi = false,
            isFallback = false
        )
    }

    /**
     * Converts raw Android Voice objects to our TTSVoiceInfo list for the UI.
     */
    fun extractVoiceInfos(tts: TextToSpeech?): List<TTSVoiceInfo> {
        if (tts == null) return emptyList()
        val allVoices = try {
            tts.voices
        } catch (e: Exception) {
            null
        } ?: return emptyList()

        return allVoices
            .filter { voice ->
                val lang = voice.locale.language.lowercase()
                (lang == "hi" || lang == "en") && isInstalled(voice)
            }
            .map { voice ->
                TTSVoiceInfo(
                    id = voice.name,
                    displayName = formatVoiceDisplayName(voice),
                    locale = voice.locale,
                    quality = voice.quality,
                    isNetworkRequired = voice.isNetworkConnectionRequired,
                    isInstalled = isInstalled(voice),
                    latency = voice.latency
                )
            }
            .sortedWith(
                compareBy<TTSVoiceInfo> { if (it.locale.language == "hi") 0 else 1 }
                    .thenByDescending { it.quality }
                    .thenBy { it.displayName }
            )
    }

    fun isHindiAvailableOnDevice(tts: TextToSpeech?): Boolean {
        if (tts == null) return false
        try {
            val status = tts.isLanguageAvailable(LOCALE_HINDI_INDIA)
            if (status >= TextToSpeech.LANG_AVAILABLE) return true

            val voices = tts.voices
            if (!voices.isNullOrEmpty()) {
                return voices.any { it.locale.language.equals("hi", ignoreCase = true) && isInstalled(it) }
            }
        } catch (e: Exception) {
            Log.w("DOST_VOICE", "Error checking Hindi availability: ${e.message}")
        }
        return false
    }

    private fun isInstalled(voice: Voice): Boolean {
        val features = voice.features ?: return true
        return !features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
    }

    private fun formatVoiceDisplayName(voice: Voice): String {
        val langName = when (voice.locale.language.lowercase()) {
            "hi" -> "Hindi"
            "en" -> if (voice.locale.country.equals("IN", ignoreCase = true)) "English (India)" else "English (${voice.locale.country})"
            else -> voice.locale.displayLanguage
        }

        // Clean internal system voice names like "hi-in-x-hie-local" to clean labels
        val variant = voice.name
            .substringAfterLast("x-", "")
            .replace("-local", " (Local)")
            .replace("-network", " (High Res)")
            .ifBlank { voice.name.takeLast(6) }

        val qualityLabel = when (voice.quality) {
            Voice.QUALITY_VERY_HIGH -> " • Very High"
            Voice.QUALITY_HIGH -> " • High"
            else -> ""
        }

        return "$langName - $variant$qualityLabel"
    }
}
