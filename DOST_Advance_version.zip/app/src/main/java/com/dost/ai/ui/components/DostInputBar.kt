package com.dost.ai.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.data.model.AssistantState
import com.dost.ai.ui.theme.*

@Composable
fun DostInputBar(
    inputText: String,
    onInputTextChange: (String) -> Unit,
    onSendMessage: () -> Unit,
    onToggleMic: () -> Unit,
    onStopActiveAction: () -> Unit,
    assistantState: AssistantState,
    modifier: Modifier = Modifier
) {
    val isListening = assistantState == AssistantState.LISTENING ||
            assistantState == AssistantState.LISTENING_COMMAND ||
            assistantState == AssistantState.FOLLOW_UP
    val isActivelyBusy = isListening ||
            assistantState == AssistantState.THINKING ||
            assistantState == AssistantState.PROCESSING ||
            assistantState == AssistantState.EXECUTING ||
            assistantState == AssistantState.SPEAKING

    Surface(
        color = DostDarkSurface,
        modifier = modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding(),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Main Input Controls Row: [ Mic ] [ Expandable Multiline Input ] [ Send / Stop ]
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Microphone button
                IconButton(
                    onClick = onToggleMic,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isListening) DostPrimary else Color(0xFF1F232D))
                        .border(
                            1.dp,
                            if (isListening) DostPrimaryBright else DostBorderSubtle,
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop listening" else "Start listening",
                        tint = if (isListening) Color.White else DostPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Expandable Multiline Text Input Field:
                // - Wraps text to next line automatically
                // - Grows vertically up to maxLines (5)
                // - Enables internal vertical scrolling beyond maxLines
                TextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = {
                        Text(
                            text = "Message DOST...",
                            color = DostTextTertiary,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 44.dp, max = 120.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(DostDarkBackground)
                        .border(1.dp, DostBorderSubtle, RoundedCornerShape(22.dp)),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = DostDarkBackground,
                        unfocusedContainerColor = DostDarkBackground,
                        focusedTextColor = DostTextPrimary,
                        unfocusedTextColor = DostTextPrimary,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    ),
                    singleLine = false,
                    maxLines = 5,
                    minLines = 1
                )

                // Dynamic Stop button: shown ONLY when DOST is actively listening, thinking, speaking, or executing
                AnimatedVisibility(
                    visible = isActivelyBusy && inputText.isBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    IconButton(
                        onClick = onStopActiveAction,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2C1417))
                            .border(1.dp, DostPrimary.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop",
                            tint = DostPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Send Button: shown when user has typed text
                AnimatedVisibility(
                    visible = inputText.isNotBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    IconButton(
                        onClick = onSendMessage,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(DostPrimary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
