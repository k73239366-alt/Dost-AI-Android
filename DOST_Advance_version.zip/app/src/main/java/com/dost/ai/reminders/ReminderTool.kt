package com.dost.ai.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import com.dost.ai.MainActivity
import com.dost.ai.tools.BaseTool
import com.dost.ai.tools.ToolResult
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ScheduledReminder(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val targetTimeMillis: Long,
    val isCompleted: Boolean = false
)

/**
 * Legitimate Android Reminder Tool using AlarmManager and local persistence.
 *
 * Requirements:
 * - "Kal 6 baje revision yaad dilana."
 * - "Remind me in 10 minutes."
 * - Show actual scheduled time.
 * - List and cancel reminders.
 */
class ReminderTool(private val context: Context) : BaseTool {
    override val name: String = "CREATE_REMINDER"
    override val description: String = "Schedules real reminders using Android AlarmManager."

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_reminders_prefs", Context.MODE_PRIVATE)

    override fun validateParams(params: Map<String, Any?>): String? {
        val action = (params["action"] as? String)?.lowercase() ?: "create"
        if (action == "create") {
            val text = (params["text"] as? String)?.trim()
            if (text.isNullOrBlank()) return "Reminder text is required."
        }
        return null
    }

    override suspend fun execute(context: Context, params: Map<String, Any?>): ToolResult {
        val action = (params["action"] as? String)?.lowercase() ?: "create"
        return when (action) {
            "create" -> {
                val text = (params["text"] as? String)?.trim() ?: "Reminder"
                val delayMinutes = (params["delayMinutes"] as? Number)?.toLong() ?: 10L
                val targetMillis = (params["targetTimeMillis"] as? Number)?.toLong()
                    ?: (System.currentTimeMillis() + delayMinutes * 60 * 1000)

                val reminder = ScheduledReminder(
                    text = text,
                    targetTimeMillis = targetMillis
                )

                scheduleAlarm(reminder)
                saveReminder(reminder)

                val sdf = SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault())
                val formattedTime = sdf.format(Date(targetMillis))

                ToolResult.success(
                    name,
                    "Maine yaad dilaane ke liye reminder schedule kar diya hai: \"$text\" ($formattedTime par).",
                    mapOf("reminderId" to reminder.id, "time" to formattedTime, "targetTimeMillis" to targetMillis)
                )
            }
            "list" -> {
                val active = getActiveReminders()
                if (active.isEmpty()) {
                    ToolResult.success(name, "Aapka koi active reminder nahi hai.", mapOf("count" to 0))
                } else {
                    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
                    val listStr = active.joinToString("\n• ") {
                        "${it.text} (${sdf.format(Date(it.targetTimeMillis))})"
                    }
                    ToolResult.success(name, "Active Reminders:\n• $listStr", mapOf("count" to active.size))
                }
            }
            "cancel" -> {
                val reminderId = params["reminderId"] as? String
                if (reminderId != null) {
                    cancelReminder(reminderId)
                    ToolResult.success(name, "Reminder cancel kar diya gaya hai.", mapOf("cancelledId" to reminderId))
                } else {
                    ToolResult.failure(name, "Reminder ID is required to cancel.")
                }
            }
            else -> ToolResult.failure(name, "Unknown action: $action")
        }
    }

    private fun scheduleAlarm(reminder: ScheduledReminder) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("reminder_text", reminder.text)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            reminder.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                reminder.targetTimeMillis,
                pendingIntent
            )
        } catch (e: SecurityException) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                reminder.targetTimeMillis,
                pendingIntent
            )
        }
    }

    private fun cancelReminder(reminderId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            reminderId.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }

        val all = getAllReminders().filter { it.id != reminderId }
        saveAll(all)
    }

    fun getActiveReminders(): List<ScheduledReminder> {
        val now = System.currentTimeMillis()
        return getAllReminders().filter { it.targetTimeMillis > now && !it.isCompleted }
    }

    private fun getAllReminders(): List<ScheduledReminder> {
        val raw = prefs.getString("reminders_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<ScheduledReminder>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                ScheduledReminder(
                    id = obj.getString("id"),
                    text = obj.getString("text"),
                    targetTimeMillis = obj.getLong("targetTimeMillis"),
                    isCompleted = obj.optBoolean("isCompleted", false)
                )
            )
        }
        return list
    }

    private fun saveReminder(r: ScheduledReminder) {
        val list = getAllReminders().toMutableList()
        list.add(r)
        saveAll(list)
    }

    private fun saveAll(list: List<ScheduledReminder>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("text", r.text)
                    put("targetTimeMillis", r.targetTimeMillis)
                    put("isCompleted", r.isCompleted)
                }
            )
        }
        prefs.edit().putString("reminders_json", arr.toString()).apply()
    }
}
