package com.dost.ai.commands

import com.dost.ai.apps.AppAliases

/**
 * Routes normalized text into command intents according to the DOST specification.
 *
 * Command priority:
 * 1. STOP or CANCEL
 * 2. Explicit device action (Camera, Settings)
 * 3. App command (Launch, Store Search)
 * 4. Communication command (Call, Message)
 * 5. Reminder and timer (Timer, Alarm, Reminder, Notes)
 * 6. Screen request (Screen Understanding)
 * 7. Web request (Web Search)
 * 8. Coding, Project, and Learning request
 * 9. Memory management
 * 10. Normal conversation
 */
object IntentRouter {

    private val STOP_PATTERNS = listOf(
        "stop", "ruko", "cancel", "chup", "quiet", "bas", "band karo", "shant ho jao", "hold on"
    )

    private val CAMERA_PATTERNS = listOf(
        "open camera", "camera open karo", "camera kholo", "camera khol do",
        "camera chalu karo", "photo khicho", "take a photo", "take a picture",
        "take picture", "take selfie", "open the camera", "camera"
    )

    private val SETTINGS_PATTERNS = listOf(
        "open settings", "settings kholo", "settings open karo", "system settings",
        "wifi settings", "bluetooth settings", "open wifi", "open bluetooth"
    )

    private val SCREEN_PATTERNS = listOf(
        "analyze screen", "analyze my screen", "screen analysis", "screen dekho",
        "screen scan karo", "what is on my screen", "read my screen",
        "meri screen par kya hai", "screen par kya ho raha hai", "screen samjhao"
    )

    fun route(rawInput: String): CommandAnalysis {
        val normalized = CommandNormalizer.normalize(rawInput)

        if (normalized.isBlank()) {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.NORMAL_CONVERSATION
            )
        }

        // 1. STOP / CANCEL (Highest priority)
        if (STOP_PATTERNS.any { normalized == it || normalized.startsWith("$it ") }) {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.STOP,
                confidence = 1.0f
            )
        }

        // 2. CAMERA
        if (CAMERA_PATTERNS.any { normalized == it || normalized.startsWith("$it ") }) {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.OPEN_CAMERA,
                targetAppName = "Camera",
                normalizedAppName = "camera",
                confidence = 1.0f,
                target = "camera"
            )
        }

        // 3. SETTINGS
        if (SETTINGS_PATTERNS.any { normalized == it || normalized.startsWith("$it ") }) {
            val target = when {
                normalized.contains("wifi") -> "wifi"
                normalized.contains("bluetooth") -> "bluetooth"
                normalized.contains("display") -> "display"
                normalized.contains("sound") -> "sound"
                else -> "general"
            }
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.OPEN_SETTINGS,
                target = target,
                parameters = mapOf("target" to target),
                confidence = 0.98f
            )
        }

        // 4. TIMERS: e.g. "10 minute ka timer lagao", "5 minute timer", "set a timer for 10 minutes"
        val timerAnalysis = checkTimer(rawInput, normalized)
        if (timerAnalysis != null) return timerAnalysis

        // 5. ALARMS: e.g. "7 baje ka alarm lagao", "set alarm for 6 am"
        val alarmAnalysis = checkAlarm(rawInput, normalized)
        if (alarmAnalysis != null) return alarmAnalysis

        // 6. REMINDERS: e.g. "kal 6 baje revision yaad dilana", "remind me in 10 minutes", "yaad dilao"
        val reminderAnalysis = checkReminder(rawInput, normalized)
        if (reminderAnalysis != null) return reminderAnalysis

        // 7. NOTES: e.g. "ek note banao", "create a note", "remember note"
        val noteAnalysis = checkNote(rawInput, normalized)
        if (noteAnalysis != null) return noteAnalysis

        // 8. CALLS: e.g. "call Rahul", "Rahul ko phone lagao", "call 9876543210"
        val callAnalysis = checkCall(rawInput, normalized)
        if (callAnalysis != null) return callAnalysis

        // 9. MESSAGES: e.g. "Rahul ko message bhejo", "send message to Priya"
        val messageAnalysis = checkMessage(rawInput, normalized)
        if (messageAnalysis != null) return messageAnalysis

        // 10. SCREEN UNDERSTANDING
        if (SCREEN_PATTERNS.any { normalized.contains(it) }) {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.SCREEN_ANALYSIS,
                confidence = 0.95f
            )
        }

        // 11. PLAY STORE SEARCH
        val storeAnalysis = checkPlayStoreSearch(rawInput, normalized)
        if (storeAnalysis != null) return storeAnalysis

        // 12. WEB SEARCH
        val webAnalysis = checkWebSearch(rawInput, normalized)
        if (webAnalysis != null) return webAnalysis

        // 13. APP LAUNCH
        val appLaunchAnalysis = checkAppLaunch(rawInput, normalized)
        if (appLaunchAnalysis != null) return appLaunchAnalysis

        // 14. MEMORY MANAGEMENT
        val memoryAnalysis = checkMemory(rawInput, normalized)
        if (memoryAnalysis != null) return memoryAnalysis

        // 15. PROJECT GENERATION
        val projectAnalysis = checkProject(rawInput, normalized)
        if (projectAnalysis != null) return projectAnalysis

        // 16. CODING ASSISTANCE (when explicit coding/debug request)
        val codingAnalysis = checkCoding(rawInput, normalized)
        if (codingAnalysis != null) return codingAnalysis

        // 17. Default to NORMAL_CONVERSATION
        return CommandAnalysis(
            originalText = rawInput,
            normalizedText = normalized,
            intent = CommandIntent.NORMAL_CONVERSATION
        )
    }

    private fun checkTimer(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.contains("timer")) {
            val numMatch = Regex("(\\d+)\\s*(minute|min|sec|second|ghanta|hour)").find(normalized)
            var seconds = 300 // default 5 mins
            if (numMatch != null) {
                val value = numMatch.groupValues[1].toIntOrNull() ?: 5
                val unit = numMatch.groupValues[2]
                seconds = when {
                    unit.startsWith("sec") -> value
                    unit.startsWith("min") -> value * 60
                    unit.startsWith("hour") || unit.startsWith("ghanta") -> value * 3600
                    else -> value * 60
                }
            }
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.SET_TIMER,
                parameters = mapOf("seconds" to seconds, "message" to "DOST Timer"),
                confidence = 0.95f
            )
        }
        return null
    }

    private fun checkAlarm(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.contains("alarm")) {
            val numMatch = Regex("(\\d{1,2})(:(\\d{2}))?\\s*(baje|am|pm)?").find(normalized)
            val hour = numMatch?.groupValues?.get(1)?.toIntOrNull() ?: 7
            val minute = numMatch?.groupValues?.get(3)?.toIntOrNull() ?: 0
            val isPm = normalized.contains("pm") || normalized.contains("shaam") || normalized.contains("raat")
            val adjustedHour = if (isPm && hour < 12) hour + 12 else hour

            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.CREATE_ALARM,
                parameters = mapOf("hour" to adjustedHour, "minute" to minute, "message" to "DOST Alarm"),
                confidence = 0.92f
            )
        }
        return null
    }

    private fun checkReminder(rawInput: String, normalized: String): CommandAnalysis? {
        val isReminder = normalized.contains("remind") ||
                         normalized.contains("yaad dilana") ||
                         normalized.contains("yaad dilao") ||
                         normalized.contains("yaad dila do")
        if (isReminder) {
            val text = normalized
                .replace("remind me to", "")
                .replace("remind me", "")
                .replace("yaad dilana", "")
                .replace("yaad dilao", "")
                .replace("yaad dila do", "")
                .trim()
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.CREATE_REMINDER,
                parameters = mapOf("text" to text.ifBlank { "Reminder" }, "delayMinutes" to 10),
                confidence = 0.92f
            )
        }
        return null
    }

    private fun checkNote(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.startsWith("note ") || normalized.contains("ek note banao") || normalized.contains("create a note")) {
            val content = normalized
                .removePrefix("note ")
                .removePrefix("ek note banao ")
                .removePrefix("create a note ")
                .trim()
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.CREATE_NOTE,
                parameters = mapOf("content" to content.ifBlank { "Quick Note" }),
                confidence = 0.90f
            )
        }
        return null
    }

    private fun checkCall(rawInput: String, normalized: String): CommandAnalysis? {
        if (isGeneralQuestion(normalized)) return null
        if (normalized.startsWith("call ") ||
            normalized.endsWith(" ko call karo") ||
            normalized.endsWith(" ko call lagao") ||
            normalized.startsWith("phone lagao ")
        ) {
            val target = normalized
                .removePrefix("call ")
                .removePrefix("phone lagao ")
                .removeSuffix(" ko call karo")
                .removeSuffix(" ko call lagao")
                .trim()
            if (target.isNotBlank() && target.split(" ").size <= 4) {
                return CommandAnalysis(
                    originalText = rawInput,
                    normalizedText = normalized,
                    intent = CommandIntent.CALL_CONTACT,
                    target = target,
                    parameters = mapOf("target" to target),
                    confidence = 0.92f
                )
            }
        }
        return null
    }

    private fun checkMessage(rawInput: String, normalized: String): CommandAnalysis? {
        if (isGeneralQuestion(normalized)) return null
        if (normalized.startsWith("send message to ") ||
            normalized.startsWith("message ") ||
            normalized.endsWith(" ko message bhejo") ||
            normalized.endsWith(" ko message karo")
        ) {
            val target = normalized
                .removePrefix("send message to ")
                .removePrefix("message ")
                .removeSuffix(" ko message bhejo")
                .removeSuffix(" ko message karo")
                .trim()
            if (target.isNotBlank() && target.split(" ").size <= 4) {
                return CommandAnalysis(
                    originalText = rawInput,
                    normalizedText = normalized,
                    intent = CommandIntent.SEND_MESSAGE,
                    target = target,
                    parameters = mapOf("target" to target, "messageText" to "Hello"),
                    confidence = 0.90f
                )
            }
        }
        return null
    }

    private fun checkMemory(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.startsWith("remember this") || normalized.startsWith("yaad rakho")) {
            val fact = normalized.removePrefix("remember this").removePrefix("yaad rakho").trim()
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.MANAGE_MEMORY,
                parameters = mapOf("action" to "store", "fact" to fact),
                confidence = 0.95f
            )
        }
        if (normalized == "what do you remember" || normalized == "kya yaad hai" || normalized == "memories dikhao") {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.MANAGE_MEMORY,
                parameters = mapOf("action" to "list"),
                confidence = 0.95f
            )
        }
        if (normalized == "clear memory" || normalized == "saari memory clear karo") {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.MANAGE_MEMORY,
                parameters = mapOf("action" to "clear"),
                confidence = 0.95f
            )
        }
        return null
    }

    private fun checkProject(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.contains("create website") || normalized.contains("website banao") ||
            normalized.contains("make a website") || normalized.contains("game banao") ||
            normalized.contains("create game") || normalized.contains("create a project")
        ) {
            val type = if (normalized.contains("game")) "game" else "website"
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.GENERATE_PROJECT,
                parameters = mapOf("type" to type, "prompt" to rawInput),
                confidence = 0.92f
            )
        }
        return null
    }

    private fun checkCoding(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.startsWith("debug ") ||
            normalized.startsWith("fix error ") ||
            normalized.contains("code explain karo") ||
            normalized.contains("code likho")
        ) {
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.CODING_HELP,
                parameters = mapOf("prompt" to rawInput),
                confidence = 0.90f
            )
        }
        return null
    }

    private fun checkPlayStoreSearch(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.contains("play store") || normalized.contains("playstore")) {
            val query = normalized
                .replace("play store me", "")
                .replace("play store par", "")
                .replace("play store pe", "")
                .replace("play store", "")
                .replace("playstore", "")
                .replace("search karo", "")
                .replace("dhoondo", "")
                .replace("search", "")
                .replace("find", "")
                .trim()
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.SEARCH_PLAY_STORE,
                targetAppName = if (query.isNotBlank()) capitalizeWords(query) else null,
                normalizedAppName = query.ifBlank { null },
                searchQuery = query.ifBlank { null },
                confidence = 0.95f
            )
        }
        return null
    }

    private fun checkWebSearch(rawInput: String, normalized: String): CommandAnalysis? {
        if (normalized.startsWith("web par ") || normalized.startsWith("web search ") || normalized.startsWith("google ")) {
            val query = normalized
                .removePrefix("web par ")
                .removePrefix("web search ")
                .removePrefix("google ")
                .removeSuffix(" search karo")
                .trim()
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.SEARCH_WEB,
                searchQuery = query,
                confidence = 0.95f
            )
        }
        return null
    }

    private fun checkAppLaunch(rawInput: String, normalized: String): CommandAnalysis? {
        if (isGeneralQuestion(normalized)) return null

        val openPrefixes = listOf(
            "open app ", "open the ", "open ", "launch app ", "launch ",
            "start app ", "start ", "kholo ", "khol do ", "chalu karo "
        )

        val openSuffixes = listOf(
            " open karo", " open kar do", " open kijiye", " open",
            " kholo", " khol do", " chalu karo", " start karo", " launch karo"
        )

        var candidate = ""
        var matched = false

        for (prefix in openPrefixes) {
            if (normalized.startsWith(prefix)) {
                candidate = normalized.removePrefix(prefix).trim()
                matched = true
                break
            }
        }

        if (!matched) {
            for (suffix in openSuffixes) {
                if (normalized.endsWith(suffix)) {
                    candidate = normalized.removeSuffix(suffix).trim()
                    matched = true
                    break
                }
            }
        }

        if (matched) {
            candidate = candidate.removePrefix("the ").removePrefix("app ").removeSuffix(" app").trim()
            if (candidate.isNotBlank() && candidate.split(" ").size <= 3) {
                val resolvedAlias = AppAliases.resolveAlias(candidate)
                val friendlyLabel = capitalizeWords(resolvedAlias)
                return CommandAnalysis(
                    originalText = rawInput,
                    normalizedText = normalized,
                    intent = CommandIntent.OPEN_APP,
                    targetAppName = friendlyLabel,
                    normalizedAppName = candidate,
                    confidence = 0.95f,
                    target = friendlyLabel
                )
            }
        }

        val resolved = AppAliases.resolveAlias(normalized)
        if (resolved != normalized) {
            val friendlyLabel = capitalizeWords(resolved)
            return CommandAnalysis(
                originalText = rawInput,
                normalizedText = normalized,
                intent = CommandIntent.OPEN_APP,
                targetAppName = friendlyLabel,
                normalizedAppName = normalized,
                confidence = 0.90f,
                target = friendlyLabel
            )
        }

        return null
    }

    private fun isGeneralQuestion(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("how ") || lower.contains("what ") || lower.contains("why ") ||
               lower.contains("kya ") || lower.contains("kyun ") || lower.contains("kaise ") ||
               lower.contains("samjhao") || lower.contains("batao") || lower.contains("explain")
    }

    private fun capitalizeWords(input: String): String {
        return input.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }
}
