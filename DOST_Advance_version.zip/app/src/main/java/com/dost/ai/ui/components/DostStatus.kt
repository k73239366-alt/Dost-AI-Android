package com.dost.ai.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dost.ai.data.model.AssistantState
import com.dost.ai.ui.theme.DostPrimary
import com.dost.ai.ui.theme.DostTextSecondary

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun DostStatus(
    state: AssistantState,
    statusMessage: String? = null,
    modifier: Modifier = Modifier
) {
    // Derive single, clean human-facing status
    val displayStatus = when {
        !statusMessage.isNullOrBlank() -> statusMessage
        state == AssistantState.IDLE -> "Ready to help"
        state == AssistantState.BACKGROUND_READY -> "Background Assistant Active"
        state == AssistantState.WAKE_LISTENING -> "Wake Listening Active · Say 'Dost'"
        state == AssistantState.WAKE_DETECTED -> "Wake phrase detected!"
        state == AssistantState.LISTENING -> "Listening..."
        state == AssistantState.LISTENING_COMMAND -> "Listening for command..."
        state == AssistantState.THINKING -> "Thinking..."
        state == AssistantState.PROCESSING || state == AssistantState.EXECUTING -> "Executing action..."
        state == AssistantState.SPEAKING -> "Speaking..."
        state == AssistantState.FOLLOW_UP -> "Listening for follow-up..."
        state == AssistantState.PAUSED -> "DOST is paused"
        state == AssistantState.STOPPED -> "DOST stopped"
        state == AssistantState.SUCCESS -> "Done"
        state == AssistantState.ERROR -> "Something went wrong"
        else -> "Ready"
    }

    val statusColor = when (state) {
        AssistantState.IDLE -> DostTextSecondary
        AssistantState.BACKGROUND_READY -> Color(0xFF60A5FA)
        AssistantState.WAKE_LISTENING -> Color(0xFF818CF8)
        AssistantState.WAKE_DETECTED -> Color(0xFFF43F5E)
        AssistantState.LISTENING, AssistantState.LISTENING_COMMAND -> Color(0xFF38BDF8)
        AssistantState.FOLLOW_UP -> Color(0xFF34D399)
        AssistantState.THINKING -> Color(0xFFFACC15)
        AssistantState.PROCESSING, AssistantState.EXECUTING -> Color(0xFFFB923C)
        AssistantState.SPEAKING -> DostPrimary
        AssistantState.SUCCESS -> Color(0xFF10B981)
        AssistantState.PAUSED, AssistantState.STOPPED -> Color(0xFF94A3B8)
        AssistantState.ERROR -> Color(0xFFEF4444)
        else -> DostTextSecondary
    }

    AnimatedContent(
        targetState = displayStatus,
        transitionSpec = {
            fadeIn() with fadeOut()
        },
        label = "StatusTextTransition",
        modifier = modifier.padding(horizontal = 24.dp)
    ) { text ->
        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = statusColor,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
