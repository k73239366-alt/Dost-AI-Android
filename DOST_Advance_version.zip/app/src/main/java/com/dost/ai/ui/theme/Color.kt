package com.dost.ai.ui.theme

import androidx.compose.ui.graphics.Color

val DostDarkBackground = Color(0xFF0C0D12)
val DostDarkSurface = Color(0xFF14161E)
val DostDarkSurfaceVariant = Color(0xFF1B1E28)
val DostPrimary = Color(0xFFE53935)
val DostPrimaryBright = Color(0xFFFF385C)
val DostPrimarySubtle = Color(0x26E53935)
val DostSecondary = Color(0xFF10B981)
val DostAccent = Color(0xFFF43F5E)
val DostError = Color(0xFFEF4444)
val DostTextPrimary = Color(0xFFF8FAFC)
val DostTextSecondary = Color(0xFF94A3B8)
val DostTextTertiary = Color(0xFF64748B)
val DostBorder = Color(0xFF222632)
val DostBorderSubtle = Color(0x14FFFFFF)
