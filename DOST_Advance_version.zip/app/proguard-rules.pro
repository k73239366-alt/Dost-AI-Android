# Add project specific ProGuard rules here.
-keep class com.dost.ai.data.model.** { *; }
